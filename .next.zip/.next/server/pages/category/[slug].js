"use strict";
(() => {
var exports = {};
exports.id = 8024;
exports.ids = [8024];
exports.modules = {

/***/ 2061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ getLayout),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_layout_header_header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1395);
/* harmony import */ var _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9308);
/* harmony import */ var _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6725);
/* harmony import */ var _components_common_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6203);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const SiteLayout = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: "flex flex-col min-h-screen",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_header_header__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("main", {
      className: "relative flex-grow",
      style: {
        minHeight: "-webkit-fill-available",
        WebkitOverflowScrolling: "touch"
      },
      children: children
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {})]
  });
};

const getLayout = page => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(SiteLayout, {
  children: page
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SiteLayout);

/***/ }),

/***/ 4200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Category),
  "getStaticPaths": () => (/* reexport */ getStaticPaths),
  "getStaticProps": () => (/* reexport */ getStaticProps)
});

// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ./src/components/layout/layout.tsx
var layout = __webpack_require__(2061);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/framework/rest/category/categories.query.ts
var categories_query = __webpack_require__(4362);
// EXTERNAL MODULE: ./src/lib/placeholders.tsx + 6 modules
var placeholders = __webpack_require__(9742);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/containers/category-banner.tsx







const CategoryBanner = ({
  className = "mb-7"
}) => {
  var _data$banner_image;

  const {
    query: {
      slug
    }
  } = (0,router_.useRouter)();
  const {
    data
  } = (0,categories_query/* useCategoryQuery */.Im)(slug);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `bg-gray-200 rounded-md relative flex flex-row ${className}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "hidden md:flex",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: (data === null || data === void 0 ? void 0 : (_data$banner_image = data.banner_image) === null || _data$banner_image === void 0 ? void 0 : _data$banner_image.original) || placeholders/* categoryBannerPlaceholder */.rc,
        alt: "Category Banner",
        width: 1800,
        height: 270,
        className: "rounded-md"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "relative md:absolute top-0 ltr:left-0 rtl:right-0 h-auto md:h-full w-full md:w-2/5 flex items-center py-2 sm:py-3.5",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
        className: "capitalize text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-heading p-7 text-center w-full",
        children: ["#", data === null || data === void 0 ? void 0 : data.name]
      })
    })]
  });
};

/* harmony default export */ const category_banner = (CategoryBanner);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: ./src/components/product/product-infinite-grid.tsx
var product_infinite_grid = __webpack_require__(5944);
;// CONCATENATED MODULE: ./src/components/category/category-products-grid.tsx





const CategoryProductsGrid = ({
  classname = "",
  categorySlug
}) => {
  const {
    isLoading,
    isFetchingNextPage: loadingMore,
    fetchNextPage,
    hasNextPage,
    data,
    error
  } = (0,products_query/* useProductsInfiniteQuery */.Ue)({
    category: categorySlug && categorySlug
  });
  if (error) return /*#__PURE__*/jsx_runtime_.jsx("p", {
    children: error.message
  });
  return /*#__PURE__*/jsx_runtime_.jsx(product_infinite_grid/* default */.Z, {
    className: classname,
    loading: isLoading,
    data: data,
    hasNextPage: hasNextPage,
    loadingMore: loadingMore,
    fetchNextPage: fetchNextPage
  });
};

/* harmony default export */ const category_products_grid = (CategoryProductsGrid);
// EXTERNAL MODULE: ./src/framework/rest/settings/settings.query.ts
var settings_query = __webpack_require__(659);
// EXTERNAL MODULE: ./src/framework/rest/utils/endpoints.ts
var endpoints = __webpack_require__(874);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(3295);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(2585);
// EXTERNAL MODULE: external "react-query/hydration"
var hydration_ = __webpack_require__(9475);
;// CONCATENATED MODULE: ./src/framework/rest/ssr/category.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







 // This function gets called at build time

async function getStaticPaths({
  locales
}) {
  var _categories$data;

  const categories = await (0,categories_query/* fetchCategories */.pE)({
    queryKey: [endpoints/* API_ENDPOINTS.CATEGORIES */.P.CATEGORIES, {
      limit: 100,
      parent: null
    }]
  });
  const paths = categories === null || categories === void 0 ? void 0 : (_categories$data = categories.data) === null || _categories$data === void 0 ? void 0 : _categories$data.flatMap(category => locales === null || locales === void 0 ? void 0 : locales.map(locale => ({
    params: {
      slug: category.slug
    },
    locale
  })));
  return {
    paths,
    fallback: "blocking"
  };
}
const getStaticProps = async ({
  params,
  locale
}) => {
  const slug = params === null || params === void 0 ? void 0 : params.slug;
  const queryClient = new external_react_query_.QueryClient({
    defaultOptions: {
      queries: {
        staleTime: Infinity
      }
    }
  });

  try {
    await Promise.all([await queryClient.prefetchQuery(endpoints/* API_ENDPOINTS.SETTINGS */.P.SETTINGS, settings_query/* fetchSettings */.w), await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.CATEGORIES */.P.CATEGORIES, slug], () => (0,categories_query/* fetchCategory */.jn)(slug)), await queryClient.prefetchInfiniteQuery([endpoints/* API_ENDPOINTS.PRODUCTS */.P.PRODUCTS, {
      category: slug
    }], products_query/* fetchInfiniteProducts */.GU)]);
    return {
      props: _objectSpread(_objectSpread({}, await (0,serverSideTranslations_.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
        dehydratedState: JSON.parse(JSON.stringify((0,hydration_.dehydrate)(queryClient)))
      }),
      revalidate: Number(process.env.REVALIDATE_DURATION) || 120
    };
  } catch (error) {
    // If we get here means something went wrong in promise fetching
    return {
      notFound: true
    };
  }
};
;// CONCATENATED MODULE: ./src/pages/category/[slug].tsx








function Category() {
  const {
    query
  } = (0,router_.useRouter)();
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "border-t-2 border-borderBottom",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(container/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(category_banner, {
        className: "my-4"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "pb-16 lg:pb-20",
        children: /*#__PURE__*/jsx_runtime_.jsx(category_products_grid, {
          classname: "3xl:grid-cols-6",
          categorySlug: query === null || query === void 0 ? void 0 : query.slug
        })
      })]
    })
  });
}
Category.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 2731:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/fa/FaChevronDown");

/***/ }),

/***/ 4603:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowDown");

/***/ }),

/***/ 7379:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowForward");

/***/ }),

/***/ 491:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoClose");

/***/ }),

/***/ 6545:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoCloseOutline");

/***/ }),

/***/ 9199:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoFacebook");

/***/ }),

/***/ 4341:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoInstagram");

/***/ }),

/***/ 2243:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoTwitter");

/***/ }),

/***/ 3391:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoYoutube");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9892,2123,8218,8147,3170,135,7790,4362,9742,5944], () => (__webpack_exec__(4200)));
module.exports = __webpack_exports__;

})();