"use strict";
(() => {
var exports = {};
exports.id = 7504;
exports.ids = [7504];
exports.modules = {

/***/ 2061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ getLayout),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_layout_header_header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1395);
/* harmony import */ var _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9308);
/* harmony import */ var _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6725);
/* harmony import */ var _components_common_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6203);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const SiteLayout = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: "flex flex-col min-h-screen",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_header_header__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("main", {
      className: "relative flex-grow",
      style: {
        minHeight: "-webkit-fill-available",
        WebkitOverflowScrolling: "touch"
      },
      children: children
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {})]
  });
};

const getLayout = page => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(SiteLayout, {
  children: page
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SiteLayout);

/***/ }),

/***/ 7426:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Collections),
  "getStaticPaths": () => (/* reexport */ getStaticPaths),
  "getStaticProps": () => (/* reexport */ getStaticProps)
});

// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ./src/components/layout/layout.tsx
var layout = __webpack_require__(2061);
// EXTERNAL MODULE: external "react-sticky-box"
var external_react_sticky_box_ = __webpack_require__(9058);
var external_react_sticky_box_default = /*#__PURE__*/__webpack_require__.n(external_react_sticky_box_);
// EXTERNAL MODULE: ./src/components/ui/active-link.tsx
var active_link = __webpack_require__(585);
// EXTERNAL MODULE: ./src/components/common/breadcrumb.tsx + 1 modules
var breadcrumb = __webpack_require__(1045);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/framework/rest/utils/core-api.ts
var core_api = __webpack_require__(3036);
// EXTERNAL MODULE: ./src/framework/rest/utils/endpoints.ts
var endpoints = __webpack_require__(874);
// EXTERNAL MODULE: ./src/framework/rest/utils/data-mappers.ts
var data_mappers = __webpack_require__(9517);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(2585);
;// CONCATENATED MODULE: ./src/framework/rest/tags/tags.query.ts
const _excluded = ["data"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const TagService = new core_api/* CoreApi */.z(endpoints/* API_ENDPOINTS.TAGS */.P.TAGS);

const fetchTags = async ({
  queryKey,
  pageParam
}) => {
  const params = queryKey[1];
  let fetchedData = {};

  if (pageParam) {
    const response = await TagService.fetchUrl(pageParam);
    fetchedData = response.data;
  } else {
    const response = await TagService.find(params);
    fetchedData = response.data;
  }

  const {
    data
  } = fetchedData,
        rest = _objectWithoutProperties(fetchedData, _excluded);

  return {
    data,
    paginatorInfo: (0,data_mappers/* mapPaginatorData */.Q)(_objectSpread({}, rest))
  };
};

const useTagsQuery = (params, options) => {
  return (0,external_react_query_.useInfiniteQuery)([endpoints/* API_ENDPOINTS.TAGS */.P.TAGS, params], fetchTags, _objectSpread(_objectSpread({}, options), {}, {
    getNextPageParam: ({
      paginatorInfo
    }) => paginatorInfo.nextPageUrl
  }));
};


const fetchTag = async slug => {
  const {
    data
  } = await TagService.findOne(slug);
  return data;
};
const useTagQuery = slug => {
  return useQuery([API_ENDPOINTS.TAGS, slug], () => fetchTag(slug));
};
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/collection/collection-filters.tsx










const CollectionFilters = () => {
  var _data$pages, _data$pages$;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    closeFilter
  } = (0,ui_context/* useUI */.l8)();
  const {
    data,
    isLoading: loading
  } = useTagsQuery({});
  const {
    query: {
      tags
    }
  } = (0,router_.useRouter)();
  if (loading) return null;
  const items = data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : (_data$pages$ = _data$pages[0]) === null || _data$pages$ === void 0 ? void 0 : _data$pages$.data;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "pt-1",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "block border-b border-gray-300 pb-3 xl:pb-5 mb-7",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex items-center justify-between mb-2.5",
        children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "font-semibold text-heading text-base md:text-xl lg:text-2xl",
          children: t("text-collection-list")
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "block pb-7",
      children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
        className: "mt-2 flex flex-col space-y-5",
        children: items === null || items === void 0 ? void 0 : items.map(item => /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: "text-sm lg:text-[15px] cursor-pointer",
          onClick: closeFilter,
          children: /*#__PURE__*/jsx_runtime_.jsx(active_link/* default */.Z, {
            href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${item.slug}`,
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: external_classnames_default()("block transition duration-300 ease-in-out text-heading hover:font-semibold py-0.5", tags === (item === null || item === void 0 ? void 0 : item.slug) && "font-semibold"),
              children: item.name
            })
          })
        }, item.id))
      })
    })]
  });
};
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: ./src/components/product/product-infinite-grid.tsx
var product_infinite_grid = __webpack_require__(5944);
// EXTERNAL MODULE: ./src/components/common/drawer/drawer.tsx
var drawer = __webpack_require__(5536);
;// CONCATENATED MODULE: external "@react-icons/all-files/md/MdCollectionsBookmark"
const MdCollectionsBookmark_namespaceObject = require("@react-icons/all-files/md/MdCollectionsBookmark");
// EXTERNAL MODULE: ./src/components/ui/text.tsx
var ui_text = __webpack_require__(4068);
// EXTERNAL MODULE: ./src/utils/get-direction.ts
var get_direction = __webpack_require__(1727);
// EXTERNAL MODULE: ./src/components/common/scrollbar.tsx
var scrollbar = __webpack_require__(7654);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoArrowBack"
var IoArrowBack_ = __webpack_require__(5256);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoArrowForward"
var IoArrowForward_ = __webpack_require__(2713);
;// CONCATENATED MODULE: ./src/components/collection/collection-filter-sidebar.tsx











const CollectionFilterSidebar = () => {
  const {
    closeFilter
  } = (0,ui_context/* useUI */.l8)();
  const router = (0,router_.useRouter)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const dir = (0,get_direction/* getDirection */.M)(router.locale);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-col justify-between w-full h-full",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full border-b border-gray-100 flex justify-between items-center relative ltr:pr-5 ltr:md:pr-7 rtl:pl-5 rtl:md:pl-7 flex-shrink-0 py-0.5",
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "flex text-2xl items-center justify-center text-gray-500 px-4 md:px-5 py-6 lg:py-8 focus:outline-none transition-opacity hover:opacity-60",
        onClick: closeFilter,
        "aria-label": "close",
        children: dir === "rtl" ? /*#__PURE__*/jsx_runtime_.jsx(IoArrowForward_.IoArrowForward, {
          className: "text-black"
        }) : /*#__PURE__*/jsx_runtime_.jsx(IoArrowBack_.IoArrowBack, {
          className: "text-black"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "font-bold text-xl md:text-2xl m-0 text-heading w-full text-center ltr:pr-6 rtl:pl-6",
        children: t("text-collections")
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(scrollbar/* default */.Z, {
      className: "menu-scrollbar flex-grow mb-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex flex-col py-7 px-5 md:px-7 text-heading",
        children: /*#__PURE__*/jsx_runtime_.jsx(CollectionFilters, {})
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "text-sm md:text-base leading-4 flex items-center justify-center px-7 flex-shrink-0 h-14 bg-heading text-white",
      children: ["9,608 ", t("text-items")]
    })]
  });
};

/* harmony default export */ const collection_filter_sidebar = (CollectionFilterSidebar);
;// CONCATENATED MODULE: ./src/components/collection/collection-top-bar.tsx












const CollectionTopBar = ({
  collectionTitle,
  searchResultCount
}) => {
  const {
    openFilter,
    displayFilter,
    closeFilter
  } = (0,ui_context/* useUI */.l8)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    locale
  } = (0,router_.useRouter)();
  const dir = (0,get_direction/* getDirection */.M)(locale);
  const contentWrapperCSS = dir === "ltr" ? {
    left: 0
  } : {
    right: 0
  };
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex justify-between items-center mb-7",
    children: [/*#__PURE__*/jsx_runtime_.jsx(ui_text/* default */.Z, {
      variant: "pageHeading",
      className: "hidden lg:inline-flex pb-1 capitalize",
      children: collectionTitle
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
      className: "lg:hidden text-heading text-sm px-4 py-2 font-semibold border border-gray-300 rounded-md flex items-center transition duration-200 ease-in-out focus:outline-none hover:bg-gray-200",
      onClick: openFilter,
      children: [/*#__PURE__*/jsx_runtime_.jsx(MdCollectionsBookmark_namespaceObject.MdCollectionsBookmark, {
        className: "text-lg"
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "ltr:pl-2 rtl:pr-2",
        children: t("text-filters")
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex items-center justify-end",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex-shrink-0 text-body text-xs md:text-sm leading-4",
        children: [searchResultCount !== null && searchResultCount !== void 0 ? searchResultCount : 0, " ", t("text-items")]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(drawer/* Drawer */.d, {
      placement: dir === "rtl" ? "right" : "left",
      open: displayFilter,
      onClose: closeFilter,
      handler: false,
      showMask: true,
      level: null,
      contentWrapperStyle: contentWrapperCSS,
      children: /*#__PURE__*/jsx_runtime_.jsx(collection_filter_sidebar, {})
    })]
  });
};

/* harmony default export */ const collection_top_bar = (CollectionTopBar);
;// CONCATENATED MODULE: ./src/components/collection/collection-products-block.tsx








const CollectionProductsBlock = ({
  classname = "",
  tagSlug
}) => {
  var _data$pages, _data$pages$, _data$pages$$paginato;

  const {
    isLoading,
    isFetchingNextPage: loadingMore,
    fetchNextPage,
    hasNextPage,
    data,
    error
  } = (0,products_query/* useProductsInfiniteQuery */.Ue)({
    tags: tagSlug && tagSlug
  });
  const collectionTitle = tagSlug === null || tagSlug === void 0 ? void 0 : tagSlug.toString().split("-").join(" ");
  if (error) return /*#__PURE__*/jsx_runtime_.jsx("p", {
    children: error.message
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(collection_top_bar, {
      collectionTitle: collectionTitle,
      searchResultCount: data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : (_data$pages$ = _data$pages[0]) === null || _data$pages$ === void 0 ? void 0 : (_data$pages$$paginato = _data$pages$.paginatorInfo) === null || _data$pages$$paginato === void 0 ? void 0 : _data$pages$$paginato.total
    }), /*#__PURE__*/jsx_runtime_.jsx(product_infinite_grid/* default */.Z, {
      className: classname,
      loading: isLoading,
      data: data,
      hasNextPage: hasNextPage,
      loadingMore: loadingMore,
      fetchNextPage: fetchNextPage
    })]
  });
};

/* harmony default export */ const collection_products_block = (CollectionProductsBlock);
// EXTERNAL MODULE: ./src/framework/rest/settings/settings.query.ts
var settings_query = __webpack_require__(659);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(3295);
// EXTERNAL MODULE: external "react-query/hydration"
var hydration_ = __webpack_require__(9475);
;// CONCATENATED MODULE: ./src/framework/rest/ssr/tags.ts
function tags_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function tags_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { tags_ownKeys(Object(source), true).forEach(function (key) { tags_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { tags_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function tags_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







 // This function gets called at build time

async function getStaticPaths({
  locales
}) {
  var _tags$data;

  const tags = await fetchTags({
    queryKey: [endpoints/* API_ENDPOINTS.TAGS */.P.TAGS, {
      limit: 100
    }]
  });
  const paths = tags === null || tags === void 0 ? void 0 : (_tags$data = tags.data) === null || _tags$data === void 0 ? void 0 : _tags$data.flatMap(tag => locales === null || locales === void 0 ? void 0 : locales.map(locale => ({
    params: {
      tags: tag.slug
    },
    locale
  })));
  return {
    paths,
    fallback: "blocking"
  };
}
const getStaticProps = async ({
  locale,
  params
}) => {
  const queryClient = new external_react_query_.QueryClient({
    defaultOptions: {
      queries: {
        staleTime: Infinity
      }
    }
  });

  try {
    const tags = params === null || params === void 0 ? void 0 : params.tags;
    await Promise.all([await queryClient.prefetchQuery(endpoints/* API_ENDPOINTS.SETTINGS */.P.SETTINGS, settings_query/* fetchSettings */.w), // Fetch all tags name
    await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.TAGS */.P.TAGS, {}], fetchTags), await queryClient.prefetchInfiniteQuery([endpoints/* API_ENDPOINTS.PRODUCTS */.P.PRODUCTS, {
      tags
    }], products_query/* fetchInfiniteProducts */.GU)]);
    return {
      props: tags_objectSpread(tags_objectSpread({}, await (0,serverSideTranslations_.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
        dehydratedState: JSON.parse(JSON.stringify((0,hydration_.dehydrate)(queryClient)))
      }),
      revalidate: Number(process.env.REVALIDATE_DURATION) || 120
    };
  } catch (error) {
    // If we get here means something went wrong in promise fetching
    return {
      notFound: true
    };
  }
};
;// CONCATENATED MODULE: ./src/pages/collections/[tags].tsx













function Collections() {
  const {
    query
  } = (0,router_.useRouter)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "border-t-2 border-borderBottom",
    children: /*#__PURE__*/jsx_runtime_.jsx(container/* default */.Z, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `flex pt-8 pb-10 lg:pb-16 xl:pb-20`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex-shrink-0 ltr:pr-8 rtl:pl-8 ltr:xl:pr-12 ltr:2xl:pr-24 rtl:xl:pl-12 rtl:2xl:pl-24 hidden lg:block w-72 xl:w-80 2xl:w-96",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_sticky_box_default()), {
            offsetTop: 50,
            offsetBottom: 20,
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "pb-5 xl:pb-7 pt-1",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(breadcrumb/* BreadcrumbItems */.x, {
                separator: "/",
                children: [/*#__PURE__*/jsx_runtime_.jsx(active_link/* default */.Z, {
                  href: '/',
                  activeClassName: "font-semibold text-heading",
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    children: t('breadcrumb-home')
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(active_link/* default */.Z, {
                  href: routes/* ROUTES.SEARCH */.Z.SEARCH,
                  activeClassName: "font-semibold text-heading",
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    className: "capitalize",
                    children: t('breadcrumb-collection')
                  })
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(CollectionFilters, {})]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-full ltr:xl:-ml-4 ltr:2xl:-ml-9 rtl:xl:-mr-4 rtl:2xl:-mr-9",
          children: /*#__PURE__*/jsx_runtime_.jsx(collection_products_block, {
            tagSlug: query === null || query === void 0 ? void 0 : query.tags
          })
        })]
      })
    })
  });
}
Collections.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 2731:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/fa/FaChevronDown");

/***/ }),

/***/ 4603:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowDown");

/***/ }),

/***/ 7379:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowForward");

/***/ }),

/***/ 5256:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoArrowBack");

/***/ }),

/***/ 2713:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoArrowForward");

/***/ }),

/***/ 491:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoClose");

/***/ }),

/***/ 6545:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoCloseOutline");

/***/ }),

/***/ 9199:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoFacebook");

/***/ }),

/***/ 4341:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoInstagram");

/***/ }),

/***/ 2243:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoTwitter");

/***/ }),

/***/ 3391:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoYoutube");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 9058:
/***/ ((module) => {

module.exports = require("react-sticky-box");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9892,2123,8218,8147,3170,135,4068,7790,5944,1045], () => (__webpack_exec__(7426)));
module.exports = __webpack_exports__;

})();