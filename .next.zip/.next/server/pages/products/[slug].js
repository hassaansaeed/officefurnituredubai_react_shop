"use strict";
(() => {
var exports = {};
exports.id = 7905;
exports.ids = [7905];
exports.modules = {

/***/ 770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProductPage),
  "getStaticPaths": () => (/* reexport */ getStaticPaths),
  "getStaticProps": () => (/* reexport */ getStaticProps)
});

// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ./src/components/layout/layout.tsx
var layout = __webpack_require__(2061);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
// EXTERNAL MODULE: ./src/components/common/counter.tsx + 2 modules
var counter = __webpack_require__(1654);
// EXTERNAL MODULE: ./src/framework/rest/utils/get-variations.ts
var get_variations = __webpack_require__(2347);
// EXTERNAL MODULE: ./src/store/quick-cart/cart.context.tsx + 2 modules
var cart_context = __webpack_require__(4436);
// EXTERNAL MODULE: ./src/lib/use-price.ts
var use_price = __webpack_require__(7259);
// EXTERNAL MODULE: ./src/utils/generate-cart-item.ts
var generate_cart_item = __webpack_require__(4064);
// EXTERNAL MODULE: ./src/components/product/product-attributes.tsx
var product_attributes = __webpack_require__(9582);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(2034);
// EXTERNAL MODULE: ./src/utils/use-window-size.ts
var use_window_size = __webpack_require__(3396);
// EXTERNAL MODULE: ./src/components/ui/carousel/carousel.tsx
var carousel = __webpack_require__(4365);
// EXTERNAL MODULE: external "swiper/react"
var react_ = __webpack_require__(2156);
// EXTERNAL MODULE: external "lodash/isEqual"
var isEqual_ = __webpack_require__(6414);
var isEqual_default = /*#__PURE__*/__webpack_require__.n(isEqual_);
// EXTERNAL MODULE: ./src/components/product/product-variant-price.tsx
var product_variant_price = __webpack_require__(7615);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "lodash/isMatch"
var isMatch_ = __webpack_require__(1333);
var isMatch_default = /*#__PURE__*/__webpack_require__.n(isMatch_);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/product/product-single-details.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
























const productGalleryCarouselResponsive = {
  "768": {
    slidesPerView: 2,
    spaceBetween: 12
  },
  "0": {
    slidesPerView: 1
  }
};

const ProductSingleDetails = ({
  product
}) => {
  var _combineImages$0$orig, _combineImages$, _combineImages$0$orig2, _combineImages$2, _selectedVariation, _selectedVariation2, _selectedVariation3, _product$type, _product$type2, _product$shop, _product$shop2;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    width
  } = (0,use_window_size/* useWindowSize */.i)();
  const {
    addItemToCart
  } = (0,cart_context/* useCart */.jD)();
  const {
    0: attributes,
    1: setAttributes
  } = (0,external_react_.useState)({});
  const {
    0: quantity,
    1: setQuantity
  } = (0,external_react_.useState)(1);
  const {
    0: addToCartLoader,
    1: setAddToCartLoader
  } = (0,external_react_.useState)(false);
  const {
    price,
    basePrice
  } = (0,use_price/* default */.ZP)({
    amount: product !== null && product !== void 0 && product.sale_price ? product === null || product === void 0 ? void 0 : product.sale_price : product === null || product === void 0 ? void 0 : product.price,
    baseAmount: product === null || product === void 0 ? void 0 : product.price
  });
  const variations = (0,get_variations/* getVariations */.y)(product === null || product === void 0 ? void 0 : product.variations);
  const isSelected = !isEmpty_default()(variations) ? !isEmpty_default()(attributes) && Object.keys(variations).every(variation => attributes.hasOwnProperty(variation)) : true;
  let selectedVariation = {};

  if (isSelected) {
    var _product$variation_op;

    selectedVariation = product === null || product === void 0 ? void 0 : (_product$variation_op = product.variation_options) === null || _product$variation_op === void 0 ? void 0 : _product$variation_op.find(o => isEqual_default()(o.options.map(v => v.value).sort(), Object.values(attributes).sort()));
  }

  function addToCart() {
    if (!isSelected) return; // to show btn feedback while product carting

    setAddToCartLoader(true);
    setTimeout(() => {
      setAddToCartLoader(false);
    }, 600);
    const item = (0,generate_cart_item/* generateCartItem */.z)(product, selectedVariation);
    addItemToCart(item, quantity);
    (0,external_react_toastify_.toast)(t("add-to-cart"), {
      type: "dark",
      progressClassName: "fancy-progress-bar",
      position: width > 768 ? "bottom-right" : "top-right",
      autoClose: 2000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true
    });
  }

  function handleAttribute(attribute) {
    // Reset Quantity
    if (!isMatch_default()(attributes, attribute)) {
      setQuantity(1);
    }

    setAttributes(prev => _objectSpread(_objectSpread({}, prev), attribute));
  } // Combine image and gallery


  const combineImages = [...(product === null || product === void 0 ? void 0 : product.gallery), product === null || product === void 0 ? void 0 : product.image];
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "block lg:grid grid-cols-9 gap-x-10 xl:gap-x-14 pt-7 pb-10 lg:pb-14 2xl:pb-20 items-start",
    children: [width < 1025 ? /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
      pagination: {
        clickable: true
      },
      breakpoints: productGalleryCarouselResponsive,
      className: "product-gallery",
      buttonClassName: "hidden",
      children: (combineImages === null || combineImages === void 0 ? void 0 : combineImages.length) > 1 ? combineImages === null || combineImages === void 0 ? void 0 : combineImages.map((item, index) => {
        var _item$original;

        return /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-span-1 transition duration-150 ease-in hover:opacity-90 flex",
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              width: 475,
              height: 618,
              src: (_item$original = item === null || item === void 0 ? void 0 : item.original) !== null && _item$original !== void 0 ? _item$original : "/assets/placeholder/products/product-gallery.svg",
              alt: `${product === null || product === void 0 ? void 0 : product.name}--${index}`,
              className: "object-cover w-full"
            })
          })
        }, `product-gallery-key-${index}`);
      }) : /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-span-1 transition duration-150 ease-in hover:opacity-90 flex",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            width: 475,
            height: 618,
            src: (_combineImages$0$orig = combineImages === null || combineImages === void 0 ? void 0 : (_combineImages$ = combineImages[0]) === null || _combineImages$ === void 0 ? void 0 : _combineImages$.original) !== null && _combineImages$0$orig !== void 0 ? _combineImages$0$orig : "/assets/placeholder/products/product-gallery.svg",
            alt: product === null || product === void 0 ? void 0 : product.name,
            className: "object-cover w-full"
          })
        })
      }, `product-gallery-key`)
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col-span-5 grid grid-cols-2 gap-2.5",
      children: (combineImages === null || combineImages === void 0 ? void 0 : combineImages.length) > 1 ? combineImages === null || combineImages === void 0 ? void 0 : combineImages.map((item, index) => {
        var _item$original2;

        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-span-1 transition duration-150 ease-in hover:opacity-90 flex",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            width: 475,
            height: 618,
            src: (_item$original2 = item === null || item === void 0 ? void 0 : item.original) !== null && _item$original2 !== void 0 ? _item$original2 : "/assets/placeholder/products/product-gallery.svg",
            alt: `${product === null || product === void 0 ? void 0 : product.name}--${index}`,
            className: "object-cover w-full"
          })
        }, index);
      }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "col-span-full bg-gray-300 flex justify-center rounded-md",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "transition duration-150 ease-in hover:opacity-90 w-1/2 flex",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            width: 475,
            height: 618,
            src: (_combineImages$0$orig2 = combineImages === null || combineImages === void 0 ? void 0 : (_combineImages$2 = combineImages[0]) === null || _combineImages$2 === void 0 ? void 0 : _combineImages$2.original) !== null && _combineImages$0$orig2 !== void 0 ? _combineImages$0$orig2 : "/assets/placeholder/products/product-gallery.svg",
            alt: product === null || product === void 0 ? void 0 : product.name,
            className: "object-cover"
          })
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "col-span-4 pt-8 lg:pt-0",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "pb-7 border-b border-gray-300",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "text-heading text-lg md:text-xl lg:text-2xl 2xl:text-3xl font-bold hover:text-black mb-3.5",
          children: product === null || product === void 0 ? void 0 : product.name
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-body text-sm lg:text-base leading-6 lg:leading-8",
          children: product === null || product === void 0 ? void 0 : product.description
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex items-center mt-5",
          children: !isEmpty_default()(variations) ? /*#__PURE__*/jsx_runtime_.jsx(product_variant_price/* default */.Z, {
            selectedVariation: selectedVariation,
            minPrice: product.min_price,
            maxPrice: product.max_price
          }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "text-heading font-semibold text-base md:text-xl lg:text-2xl",
              children: price
            }), basePrice && /*#__PURE__*/jsx_runtime_.jsx("del", {
              className: "font-segoe text-gray-400 text-base lg:text-xl ltr:pl-2.5 rtl:pr-2.5 -mt-0.5 md:mt-0",
              children: basePrice
            })]
          })
        })]
      }), !isEmpty_default()(variations) && /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "pt-7 pb-3 border-b border-gray-300",
        children: Object.keys(variations).map(variation => {
          return /*#__PURE__*/jsx_runtime_.jsx(product_attributes/* ProductAttributes */.P, {
            title: variation,
            attributes: variations[variation],
            active: attributes[variation],
            onClick: handleAttribute
          }, variation);
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center space-x-4 rtl:space-x-reverse ltr:md:pr-32 ltr:lg:pr-12 ltr:2xl:pr-32 ltr:3xl:pr-48 rtl:md:pl-32 rtl:lg:pl-12 rtl:2xl:pl-32 rtl:3xl:pl-48 border-b border-gray-300 py-8",
        children: [isEmpty_default()(variations) && /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: Number(product.quantity) > 0 ? /*#__PURE__*/jsx_runtime_.jsx(counter/* default */.Z, {
            quantity: quantity,
            onIncrement: () => setQuantity(prev => prev + 1),
            onDecrement: () => setQuantity(prev => prev !== 1 ? prev - 1 : 1),
            disableDecrement: quantity === 1,
            disableIncrement: Number(product.quantity) === quantity
          }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-base text-red-500 whitespace-nowrap ltr:lg:ml-7 rtl:lg:mr-7",
            children: t("text-out-stock")
          })
        }), !isEmpty_default()(selectedVariation) && /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: (_selectedVariation = selectedVariation) !== null && _selectedVariation !== void 0 && _selectedVariation.is_disable || selectedVariation.quantity === 0 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-base text-red-500 whitespace-nowrap ltr:lg:ml-7 rtl:lg:mr-7",
            children: t("text-out-stock")
          }) : /*#__PURE__*/jsx_runtime_.jsx(counter/* default */.Z, {
            quantity: quantity,
            onIncrement: () => setQuantity(prev => prev + 1),
            onDecrement: () => setQuantity(prev => prev !== 1 ? prev - 1 : 1),
            disableDecrement: quantity === 1,
            disableIncrement: Number(selectedVariation.quantity) === quantity
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
          onClick: addToCart,
          variant: "slim",
          className: `w-full md:w-6/12 xl:w-full ${!isSelected && "bg-gray-400 hover:bg-gray-400"}`,
          disabled: !isSelected || !(product !== null && product !== void 0 && product.quantity) || !isEmpty_default()(selectedVariation) && !((_selectedVariation2 = selectedVariation) !== null && _selectedVariation2 !== void 0 && _selectedVariation2.quantity),
          loading: addToCartLoader,
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "py-2 3xl:px-8",
            children: product !== null && product !== void 0 && product.quantity || !isEmpty_default()(selectedVariation) && (_selectedVariation3 = selectedVariation) !== null && _selectedVariation3 !== void 0 && _selectedVariation3.quantity ? t("text-add-to-cart") : t("text-out-stock")
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "py-6",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "text-sm space-y-5 pb-1",
          children: [(product === null || product === void 0 ? void 0 : product.sku) && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "font-semibold text-heading inline-block ltr:pr-2 rtl:pl-2",
              children: "SKU:"
            }), product === null || product === void 0 ? void 0 : product.sku]
          }), (product === null || product === void 0 ? void 0 : product.categories) && Array.isArray(product.categories) && product.categories.length > 0 && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "font-semibold text-heading inline-block ltr:pr-2 rtl:pl-2",
              children: "Category:"
            }), product.categories.map((category, index) => {
              var _product$categories;

              return /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
                href: `${routes/* ROUTES.CATEGORY */.Z.CATEGORY}/${category === null || category === void 0 ? void 0 : category.slug}`,
                className: "transition hover:underline hover:text-heading",
                children: (product === null || product === void 0 ? void 0 : (_product$categories = product.categories) === null || _product$categories === void 0 ? void 0 : _product$categories.length) === index + 1 ? category.name : `${category.name}, `
              }, index);
            })]
          }), (product === null || product === void 0 ? void 0 : product.tags) && Array.isArray(product.tags) && product.tags.length > 0 && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "productTags",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "font-semibold text-heading inline-block ltr:pr-2 rtl:pl-2",
              children: "Tags:"
            }), product.tags.map(tag => /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
              href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${tag === null || tag === void 0 ? void 0 : tag.slug}`,
              className: "inline-block ltr:pr-1.5 rtl:pl-1.5 transition hover:underline hover:text-heading ltr:last:pr-0 rtl:last:pl-0",
              children: [tag.name, /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "text-heading",
                children: ","
              })]
            }, tag.id))]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "font-semibold text-heading inline-block ltr:pr-2 rtl:pl-2",
              children: t("text-brand-colon")
            }), /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
              href: `${routes/* ROUTES.BRAND */.Z.BRAND}=${product === null || product === void 0 ? void 0 : (_product$type = product.type) === null || _product$type === void 0 ? void 0 : _product$type.slug}`,
              className: "inline-block ltr:pr-1.5 rtl:pl-1.5 transition hover:underline hover:text-heading ltr:last:pr-0 rtl:last:pl-0",
              children: product === null || product === void 0 ? void 0 : (_product$type2 = product.type) === null || _product$type2 === void 0 ? void 0 : _product$type2.name
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "font-semibold text-heading inline-block ltr:pr-2 rtl:pl-2",
              children: t("text-shop-colon")
            }), /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
              href: `${routes/* ROUTES.SHOPS */.Z.SHOPS}/${product === null || product === void 0 ? void 0 : (_product$shop = product.shop) === null || _product$shop === void 0 ? void 0 : _product$shop.slug}`,
              className: "inline-block ltr:pr-1.5 rtl:pl-1.5 transition hover:underline hover:text-heading ltr:last:pr-0 rtl:last:pl-0",
              children: product === null || product === void 0 ? void 0 : (_product$shop2 = product.shop) === null || _product$shop2 === void 0 ? void 0 : _product$shop2.name
            })]
          })]
        })
      })]
    })]
  });
};

/* harmony default export */ const product_single_details = (ProductSingleDetails);
// EXTERNAL MODULE: ./src/components/ui/divider.tsx
var divider = __webpack_require__(5313);
// EXTERNAL MODULE: ./src/components/common/breadcrumb.tsx + 1 modules
var breadcrumb = __webpack_require__(1045);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/components/ui/loaders/spinner/spinner.tsx
var spinner = __webpack_require__(9204);
// EXTERNAL MODULE: ../node_modules/next/dynamic.js
var dynamic = __webpack_require__(5218);
// EXTERNAL MODULE: ./src/framework/rest/settings/settings.query.ts
var settings_query = __webpack_require__(659);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: ./src/framework/rest/utils/endpoints.ts
var endpoints = __webpack_require__(874);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(3295);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(2585);
// EXTERNAL MODULE: external "react-query/hydration"
var hydration_ = __webpack_require__(9475);
;// CONCATENATED MODULE: ./src/framework/rest/ssr/product.ts
function product_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function product_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { product_ownKeys(Object(source), true).forEach(function (key) { product_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { product_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function product_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






 // This function gets called at build time

async function getStaticPaths({
  locales
}) {
  var _products$data;

  const products = await (0,products_query/* fetchProducts */.t2)({
    queryKey: [endpoints/* API_ENDPOINTS.PRODUCTS */.P.PRODUCTS, {
      limit: 100
    }]
  });
  const paths = products === null || products === void 0 ? void 0 : (_products$data = products.data) === null || _products$data === void 0 ? void 0 : _products$data.flatMap(product => locales === null || locales === void 0 ? void 0 : locales.map(locale => ({
    params: {
      slug: product.slug
    },
    locale
  })));
  return {
    paths,
    fallback: "blocking"
  };
}
const getStaticProps = async ({
  params,
  locale
}) => {
  const slug = params === null || params === void 0 ? void 0 : params.slug;
  const queryClient = new external_react_query_.QueryClient({
    defaultOptions: {
      queries: {
        staleTime: Infinity
      }
    }
  });
  await queryClient.prefetchQuery(endpoints/* API_ENDPOINTS.SETTINGS */.P.SETTINGS, settings_query/* fetchSettings */.w);

  try {
    const product = await (0,products_query/* fetchProduct */.MX)(slug);
    return {
      props: product_objectSpread(product_objectSpread({
        product
      }, await (0,serverSideTranslations_.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
        dehydratedState: JSON.parse(JSON.stringify((0,hydration_.dehydrate)(queryClient)))
      }),
      revalidate: Number(process.env.REVALIDATE_DURATION) || 120
    };
  } catch (error) {
    return {
      notFound: true
    };
  }
};
;// CONCATENATED MODULE: ./src/pages/products/[slug].tsx












const RelatedProducts = (0,dynamic.default)(() => Promise.all(/* import() */[__webpack_require__.e(135), __webpack_require__.e(4068), __webpack_require__.e(2965)]).then(__webpack_require__.bind(__webpack_require__, 2965)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(2965)],
    modules: ["products/[slug].tsx -> " + "@containers/related-products"]
  }
});
function ProductPage({
  product
}) {
  const router = (0,router_.useRouter)(); // If the page is not yet generated, this will be displayed
  // initially until getStaticProps() finishes running

  if (router.isFallback) {
    return /*#__PURE__*/jsx_runtime_.jsx(spinner/* default */.Z, {});
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(divider/* default */.Z, {
      className: "mb-0"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(container/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "pt-8",
        children: /*#__PURE__*/jsx_runtime_.jsx(breadcrumb/* default */.Z, {})
      }), /*#__PURE__*/jsx_runtime_.jsx(product_single_details, {
        product: product
      }), /*#__PURE__*/jsx_runtime_.jsx(RelatedProducts, {
        products: product === null || product === void 0 ? void 0 : product.related_products,
        currentProductId: product === null || product === void 0 ? void 0 : product.id,
        sectionHeading: "text-related-products"
      })]
    })]
  });
}
ProductPage.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 2731:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/fa/FaChevronDown");

/***/ }),

/***/ 1515:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowBack");

/***/ }),

/***/ 4603:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowDown");

/***/ }),

/***/ 7379:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowForward");

/***/ }),

/***/ 491:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoClose");

/***/ }),

/***/ 6545:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoCloseOutline");

/***/ }),

/***/ 9199:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoFacebook");

/***/ }),

/***/ 4341:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoInstagram");

/***/ }),

/***/ 2243:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoTwitter");

/***/ }),

/***/ 3391:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoYoutube");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 6414:
/***/ ((module) => {

module.exports = require("lodash/isEqual");

/***/ }),

/***/ 1333:
/***/ ((module) => {

module.exports = require("lodash/isMatch");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 2034:
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5319:
/***/ ((module) => {

module.exports = require("react-use/lib/useWindowSize");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4074:
/***/ ((module) => {

module.exports = require("swiper");

/***/ }),

/***/ 2156:
/***/ ((module) => {

module.exports = require("swiper/react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9892,2123,8218,8147,3170,3880,9204,8510,1045,2983,5565], () => (__webpack_exec__(770)));
module.exports = __webpack_exports__;

})();