"use strict";
(() => {
var exports = {};
exports.id = 7131;
exports.ids = [7131];
exports.modules = {

/***/ 3315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const ErrorMessage = ({
  message
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
    className: "bg-red-400 p-5 mt-16 mx-auto max-w-sm min-w-min text-center text-lg text-white font-semibold rounded",
    children: message
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorMessage);

/***/ }),

/***/ 5986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports fetchMe, useCustomerQuery */
/* harmony import */ var _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3036);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var _store_authorization_atom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8879);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8250);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jotai__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_4__);





const CustomerService = new _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__/* .CoreApi */ .z(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.CUSTOMER */ .P.CUSTOMER);
const fetchMe = async () => {
  const {
    data
  } = await CustomerService.findAll();
  return {
    me: data
  };
};
const useCustomerQuery = options => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_4__.useQuery)(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.CUSTOMER */ .P.CUSTOMER, fetchMe, options);
};

const useUser = () => {
  const [isAuthorized] = (0,jotai__WEBPACK_IMPORTED_MODULE_3__.useAtom)(_store_authorization_atom__WEBPACK_IMPORTED_MODULE_2__/* .authorizationAtom */ .O);
  const {
    data,
    isLoading,
    error
  } = useCustomerQuery({
    enabled: isAuthorized,
    onError: err => {
      console.log(err);
    }
  });
  return {
    me: data === null || data === void 0 ? void 0 : data.me,
    loading: isLoading,
    error
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useUser);

/***/ }),

/***/ 3749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ AddressType)
/* harmony export */ });
let AddressType;

(function (AddressType) {
  AddressType["Billing"] = "billing";
  AddressType["Shipping"] = "shipping";
})(AddressType || (AddressType = {}));

/***/ }),

/***/ 8459:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AccountDetailsPage),
  "getStaticProps": () => (/* reexport */ common/* getStaticProps */.b)
});

// EXTERNAL MODULE: ./src/components/layout/layout.tsx
var layout = __webpack_require__(2061);
// EXTERNAL MODULE: ./src/components/my-account/account-layout.tsx + 2 modules
var account_layout = __webpack_require__(3045);
// EXTERNAL MODULE: ./src/components/ui/error-message.tsx
var error_message = __webpack_require__(3315);
// EXTERNAL MODULE: ./src/components/ui/loaders/spinner/spinner.tsx
var spinner = __webpack_require__(9204);
// EXTERNAL MODULE: ./src/components/address/address-card.tsx + 1 modules
var address_card = __webpack_require__(4427);
// EXTERNAL MODULE: ./src/components/address/address-header.tsx
var address_header = __webpack_require__(493);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/framework/rest/utils/constants.ts
var constants = __webpack_require__(3749);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/my-account/account-address.tsx
// import { useModalAction } from '@components/ui/modal/modal.context';








const AccountAddress = ({
  addresses,
  label,
  className,
  userId
}) => {
  const {
    setModalView,
    setModalData,
    openModal
  } = (0,ui_context/* useUI */.l8)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common'); //TODO: no address found

  function onAdd() {
    setModalData({
      customerId: userId,
      type: constants/* AddressType.Billing */.D.Billing
    });
    setModalView('ADDRESS_FORM_VIEW');
    return openModal();
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/jsx_runtime_.jsx(address_header/* AddressHeader */.V, {
      onAdd: onAdd,
      count: false,
      label: label
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3",
      children: addresses && addresses !== null && addresses !== void 0 && addresses.length ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: addresses === null || addresses === void 0 ? void 0 : addresses.map(address => /*#__PURE__*/jsx_runtime_.jsx(address_card/* default */.Z, {
          checked: false,
          address: address,
          userId: userId
        }, address.id))
      }) : /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "relative px-5 py-6 text-base text-left bg-gray-100 rounded border border-border-200",
        children: t('text-no-address')
      })
    })]
  });
};
/* harmony default export */ const account_address = (AccountAddress);
// EXTERNAL MODULE: ./src/framework/rest/auth/use-user.ts
var use_user = __webpack_require__(5986);
// EXTERNAL MODULE: ./src/framework/rest/ssr/common.ts
var common = __webpack_require__(857);
;// CONCATENATED MODULE: ./src/pages/my-account/address.tsx









function AccountDetailsPage() {
  const {
    me,
    loading,
    error
  } = (0,use_user/* default */.ZP)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  if (error) return /*#__PURE__*/jsx_runtime_.jsx(error_message/* default */.Z, {
    message: error.message
  });
  return /*#__PURE__*/jsx_runtime_.jsx(account_layout/* default */.Z, {
    children: loading ? /*#__PURE__*/jsx_runtime_.jsx(spinner/* default */.Z, {
      showText: false
    }) : /*#__PURE__*/jsx_runtime_.jsx(account_address, {
      addresses: me.address,
      userId: me.id,
      label: t("text-account-address")
    })
  });
}
AccountDetailsPage.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 4025:
/***/ ((module) => {

module.exports = require("@headlessui/react");

/***/ }),

/***/ 2731:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/fa/FaChevronDown");

/***/ }),

/***/ 4603:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowDown");

/***/ }),

/***/ 7379:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowForward");

/***/ }),

/***/ 4845:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoCallOutline");

/***/ }),

/***/ 7001:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoCartOutline");

/***/ }),

/***/ 491:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoClose");

/***/ }),

/***/ 6545:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoCloseOutline");

/***/ }),

/***/ 9224:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoHomeOutline");

/***/ }),

/***/ 4411:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogOutOutline");

/***/ }),

/***/ 9199:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoFacebook");

/***/ }),

/***/ 4341:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoInstagram");

/***/ }),

/***/ 2243:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoTwitter");

/***/ }),

/***/ 3391:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoYoutube");

/***/ }),

/***/ 9368:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoPersonOutline");

/***/ }),

/***/ 5515:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoSettingsOutline");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9892,2123,8218,8147,3170,7831,2493,9204,857,6098,3045,2816,3669], () => (__webpack_exec__(8459)));
module.exports = __webpack_exports__;

})();