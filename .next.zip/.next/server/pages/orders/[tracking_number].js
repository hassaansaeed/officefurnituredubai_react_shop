"use strict";
(() => {
var exports = {};
exports.id = 3201;
exports.ids = [3201];
exports.modules = {

/***/ 8458:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ OrderPage),
  "getStaticPaths": () => (/* reexport */ order/* getStaticPaths */.F),
  "getStaticProps": () => (/* reexport */ order/* getStaticProps */.b)
});

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/framework/rest/orders/orders.query.ts
var orders_query = __webpack_require__(2702);
// EXTERNAL MODULE: ./src/components/ui/loaders/spinner/spinner.tsx
var spinner = __webpack_require__(9204);
// EXTERNAL MODULE: ./src/components/orders/order-view.tsx + 6 modules
var order_view = __webpack_require__(5100);
// EXTERNAL MODULE: ./src/components/ui/divider.tsx
var divider = __webpack_require__(5313);
// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/store/quick-cart/cart.context.tsx + 2 modules
var cart_context = __webpack_require__(4436);
// EXTERNAL MODULE: external "jotai"
var external_jotai_ = __webpack_require__(8250);
// EXTERNAL MODULE: ./src/store/checkout.ts
var checkout = __webpack_require__(7900);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/orders/new-order.tsx













function NewOrder() {
  const {
    resetCart
  } = (0,cart_context/* useCart */.jD)();
  const [, resetCheckout] = (0,external_jotai_.useAtom)(checkout/* clearCheckoutAtom */.y9);
  const {
    query
  } = (0,router_.useRouter)();
  const {
    data,
    isLoading
  } = (0,orders_query/* useOrderQuery */.OT)({
    tracking_number: query.tracking_number
  });
  (0,external_react_.useEffect)(() => {
    resetCart();
    resetCheckout();
  }, [resetCart, resetCheckout]);

  if (isLoading) {
    return /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-full h-full flex items-center justify-center",
      children: /*#__PURE__*/jsx_runtime_.jsx(spinner/* default */.Z, {
        showText: false
      })
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(divider/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(container/* default */.Z, {
      children: /*#__PURE__*/jsx_runtime_.jsx(order_view/* default */.Z, {
        order: data === null || data === void 0 ? void 0 : data.order
      })
    })]
  });
}
// EXTERNAL MODULE: ./src/components/layout/layout.tsx
var layout = __webpack_require__(2061);
// EXTERNAL MODULE: ./src/components/ui/page-loader/page-loader.tsx
var page_loader = __webpack_require__(8883);
// EXTERNAL MODULE: ./src/framework/rest/ssr/order.ts
var order = __webpack_require__(5983);
;// CONCATENATED MODULE: ./src/pages/orders/[tracking_number].tsx






function OrderPage() {
  const router = (0,router_.useRouter)(); // If the page is not yet generated, this will be displayed
  // initially until getStaticProps() finishes running

  if (router.isFallback) {
    return /*#__PURE__*/jsx_runtime_.jsx(page_loader/* default */.Z, {});
  }

  return /*#__PURE__*/jsx_runtime_.jsx(NewOrder, {});
}
OrderPage.authenticate = true;
OrderPage.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 2731:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/fa/FaChevronDown");

/***/ }),

/***/ 4603:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowDown");

/***/ }),

/***/ 7379:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowForward");

/***/ }),

/***/ 491:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoClose");

/***/ }),

/***/ 6545:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoCloseOutline");

/***/ }),

/***/ 9199:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoFacebook");

/***/ }),

/***/ 4341:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoInstagram");

/***/ }),

/***/ 2243:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoTwitter");

/***/ }),

/***/ 3391:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoYoutube");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8349:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6356:
/***/ ((module) => {

module.exports = require("rc-table");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9892,2123,8218,8147,3170,3880,9204,6098,9742,2702,3283], () => (__webpack_exec__(8458)));
module.exports = __webpack_exports__;

})();