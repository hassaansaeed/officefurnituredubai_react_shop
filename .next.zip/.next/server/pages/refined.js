"use strict";
(() => {
var exports = {};
exports.id = 2353;
exports.ids = [2353,8810];
exports.modules = {

/***/ 6117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5038);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1103);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const BannerBlock = ({
  data,
  className = "mb-12 md:mb-14 xl:mb-16"
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    className: `${className} px-2.5 grid grid-cols-2 sm:grid-cols-9 gap-2 md:gap-2.5 max-w-[1920px] mx-auto`,
    children: data === null || data === void 0 ? void 0 : data.map(banner => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      data: banner,
      href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_1__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${banner.slug}`,
      effectActive: true,
      variant: "default",
      className: banner.type === "medium" ? "col-span-full sm:col-span-5" : "col-span-1 sm:col-span-2"
    }, `banner--key${banner.id}`))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerBlock);

/***/ }),

/***/ 7774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* reexport */ getStaticProps)
});

// EXTERNAL MODULE: ./src/components/common/banner-card.tsx
var banner_card = __webpack_require__(5038);
// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ./src/containers/category-block.tsx + 2 modules
var category_block = __webpack_require__(622);
// EXTERNAL MODULE: ./src/components/layout/layout-two.tsx
var layout_two = __webpack_require__(2573);
// EXTERNAL MODULE: ./src/components/product/feeds/new-arrivals-product-feed.tsx
var new_arrivals_product_feed = __webpack_require__(4584);
// EXTERNAL MODULE: ./src/containers/product-flash-sale-block.tsx + 1 modules
var product_flash_sale_block = __webpack_require__(9637);
// EXTERNAL MODULE: ./src/containers/products-featured.tsx + 1 modules
var products_featured = __webpack_require__(1403);
// EXTERNAL MODULE: ./src/components/common/subscription.tsx + 1 modules
var subscription = __webpack_require__(5530);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: ./src/data/static/banners.ts
var banners = __webpack_require__(5941);
// EXTERNAL MODULE: ./src/containers/testimonial-carousel.tsx + 4 modules
var testimonial_carousel = __webpack_require__(9667);
// EXTERNAL MODULE: ./src/containers/brand-block.tsx
var brand_block = __webpack_require__(5748);
// EXTERNAL MODULE: ./src/containers/collection-block.tsx + 1 modules
var collection_block = __webpack_require__(2992);
// EXTERNAL MODULE: ./src/data/static/collection.ts
var collection = __webpack_require__(776);
// EXTERNAL MODULE: ./src/containers/products-top-block.tsx
var products_top_block = __webpack_require__(9230);
// EXTERNAL MODULE: ./src/containers/hero-with-category.tsx + 1 modules
var hero_with_category = __webpack_require__(9755);
// EXTERNAL MODULE: ./src/containers/sale-banner-with-products.tsx
var sale_banner_with_products = __webpack_require__(1856);
// EXTERNAL MODULE: ./src/containers/banner-block.tsx
var banner_block = __webpack_require__(6117);
// EXTERNAL MODULE: ./src/components/common/instagram.tsx + 1 modules
var instagram = __webpack_require__(7141);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(2585);
// EXTERNAL MODULE: ./src/framework/rest/utils/endpoints.ts
var endpoints = __webpack_require__(874);
// EXTERNAL MODULE: ./src/framework/rest/settings/settings.query.ts
var settings_query = __webpack_require__(659);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(3295);
// EXTERNAL MODULE: ./src/framework/rest/category/categories.query.ts
var categories_query = __webpack_require__(4362);
// EXTERNAL MODULE: ./src/framework/rest/brand/brands.query.tsx
var brands_query = __webpack_require__(4412);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: ./src/settings/site.settings.tsx + 6 modules
var site_settings = __webpack_require__(5278);
// EXTERNAL MODULE: external "react-query/hydration"
var hydration_ = __webpack_require__(9475);
// EXTERNAL MODULE: ./src/framework/rest/products/popular-products.query.ts
var popular_products_query = __webpack_require__(8208);
;// CONCATENATED MODULE: ./src/framework/rest/ssr/homepage/refined.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











const getStaticProps = async ({
  locale
}) => {
  const queryClient = new external_react_query_.QueryClient({
    defaultOptions: {
      queries: {
        staleTime: Infinity
      }
    }
  });

  try {
    var _siteSettings$homePag, _siteSettings$homePag2, _siteSettings$homePag3, _siteSettings$homePag4, _siteSettings$homePag5, _siteSettings$homePag6;

    await Promise.all([await queryClient.prefetchQuery(endpoints/* API_ENDPOINTS.SETTINGS */.P.SETTINGS, settings_query/* fetchSettings */.w), // Fetch brands
    await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.TYPE */.P.TYPE, {
      limit: 12
    }], brands_query/* fetchBrands */.S0), // Fetch products based on tags -> on-sale products
    await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.PRODUCTS */.P.PRODUCTS, {
      limit: 4,
      tags: site_settings/* siteSettings */.U === null || site_settings/* siteSettings */.U === void 0 ? void 0 : (_siteSettings$homePag = site_settings/* siteSettings.homePageBlocks */.U.homePageBlocks) === null || _siteSettings$homePag === void 0 ? void 0 : (_siteSettings$homePag2 = _siteSettings$homePag.onSaleSettings) === null || _siteSettings$homePag2 === void 0 ? void 0 : _siteSettings$homePag2.slug
    }], products_query/* fetchProducts */.t2), // Fetch products based on tags -> featured-products products
    await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.PRODUCTS */.P.PRODUCTS, {
      limit: 8,
      tags: site_settings/* siteSettings */.U === null || site_settings/* siteSettings */.U === void 0 ? void 0 : (_siteSettings$homePag3 = site_settings/* siteSettings.homePageBlocks */.U.homePageBlocks) === null || _siteSettings$homePag3 === void 0 ? void 0 : (_siteSettings$homePag4 = _siteSettings$homePag3.featuredProducts) === null || _siteSettings$homePag4 === void 0 ? void 0 : _siteSettings$homePag4.slug
    }], products_query/* fetchProducts */.t2), //  fetch categories
    await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.CATEGORIES */.P.CATEGORIES, {
      limit: 10,
      parent: null
    }], categories_query/* fetchCategories */.pE), // Fetch products based on tags -> new arrival products
    await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.PRODUCTS */.P.PRODUCTS, {
      limit: 10,
      orderBy: "created_at",
      sortedBy: "DESC"
    }], products_query/* fetchProducts */.t2), // Fetch products based on tags -> flash-sale products
    await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.PRODUCTS */.P.PRODUCTS, {
      limit: 10,
      tags: site_settings/* siteSettings */.U === null || site_settings/* siteSettings */.U === void 0 ? void 0 : (_siteSettings$homePag5 = site_settings/* siteSettings.homePageBlocks */.U.homePageBlocks) === null || _siteSettings$homePag5 === void 0 ? void 0 : (_siteSettings$homePag6 = _siteSettings$homePag5.flashSale) === null || _siteSettings$homePag6 === void 0 ? void 0 : _siteSettings$homePag6.slug
    }], products_query/* fetchProducts */.t2), // popular products
    await queryClient.prefetchQuery([endpoints/* API_ENDPOINTS.POPULAR_PRODUCTS */.P.POPULAR_PRODUCTS, {
      limit: 6
    }], popular_products_query/* fetchPopularProducts */.R)]);
    return {
      props: _objectSpread(_objectSpread({}, await (0,serverSideTranslations_.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
        dehydratedState: JSON.parse(JSON.stringify((0,hydration_.dehydrate)(queryClient)))
      }),
      revalidate: Number(process.env.REVALIDATE_DURATION) || 120
    };
  } catch (error) {
    // If we get here means something went wrong in promise fetching
    return {
      notFound: true
    };
  }
};
;// CONCATENATED MODULE: ./src/pages/refined.tsx























function Home() {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(container/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(hero_with_category/* default */.Z, {
        data: banners/* homeRefinedHeroBanner */.MH,
        paginationPosition: "left",
        className: "hero-slider-pagination-area mb-12 md:mb-14 xl:mb-16"
      }), /*#__PURE__*/jsx_runtime_.jsx(brand_block/* default */.Z, {
        sectionHeading: "text-top-brands"
      }), /*#__PURE__*/jsx_runtime_.jsx(sale_banner_with_products/* default */.Z, {
        sectionHeading: "text-on-selling-products",
        categorySlug: "/search",
        variant: "center"
      }), /*#__PURE__*/jsx_runtime_.jsx(products_featured/* default */.Z, {
        sectionHeading: "text-featured-products",
        variant: "flat",
        limit: 8
      }), /*#__PURE__*/jsx_runtime_.jsx(banner_block/* default */.Z, {
        data: banners/* bannerDataFour */.R3,
        className: "mb-12 md:mb-14 xl:mb-16 hidden sm:flex"
      }), /*#__PURE__*/jsx_runtime_.jsx(banner_block/* default */.Z, {
        data: banners/* bannerDataFourMobile */.f9,
        className: "mb-12 md:mb-14 xl:mb-16 sm:hidden"
      }), /*#__PURE__*/jsx_runtime_.jsx(category_block/* default */.Z, {
        sectionHeading: "text-browse-categories"
      }), /*#__PURE__*/jsx_runtime_.jsx(new_arrivals_product_feed/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
        data: banners/* homeEightWinterBanner */.iy,
        href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banners/* homeEightWinterBanner.slug */.iy.slug}`,
        className: "mb-12 lg:mb-14 xl:mb-16 pb-0.5 lg:pb-1 xl:pb-0"
      }), /*#__PURE__*/jsx_runtime_.jsx(product_flash_sale_block/* default */.Z, {
        date: "2023-03-01T01:02:03",
        variant: "slider"
      }), /*#__PURE__*/jsx_runtime_.jsx(products_top_block/* default */.Z, {
        sectionHeading: "text-top-products"
      }), /*#__PURE__*/jsx_runtime_.jsx(collection_block/* default */.Z, {
        variant: "modern",
        data: collection/* modernDemoCollectionData */.s
      }), /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
        data: banners/* homeEightCoupons */.wj,
        href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banners/* homeEightCoupons.slug */.wj.slug}`,
        className: "mb-12 lg:mb-14 xl:mb-16 pb-0.5 lg:pb-1 xl:pb-0"
      }), /*#__PURE__*/jsx_runtime_.jsx(testimonial_carousel/* default */.Z, {
        sectionHeading: "text-testimonial"
      }), /*#__PURE__*/jsx_runtime_.jsx(instagram/* default */.Z, {
        className: "mb-12 md:mb-14 xl:mb-16"
      }), /*#__PURE__*/jsx_runtime_.jsx(subscription/* default */.Z, {
        className: "px-5 sm:px-8 md:px-16 2xl:px-24 relative overflow-hidden sm:items-center lg:items-start",
        variant: "modern"
      })]
    })
  });
}
Home.getLayout = layout_two/* getLayout */.G;

/***/ }),

/***/ 2166:
/***/ ((module) => {

module.exports = require("@hookform/resolvers/yup");

/***/ }),

/***/ 2731:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/fa/FaChevronDown");

/***/ }),

/***/ 5818:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/fa/FaInstagram");

/***/ }),

/***/ 3903:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/fa/FaLink");

/***/ }),

/***/ 1515:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowBack");

/***/ }),

/***/ 4603:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowDown");

/***/ }),

/***/ 7379:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io/IoIosArrowForward");

/***/ }),

/***/ 491:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoClose");

/***/ }),

/***/ 6545:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoCloseOutline");

/***/ }),

/***/ 9199:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoFacebook");

/***/ }),

/***/ 4341:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoInstagram");

/***/ }),

/***/ 2243:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoTwitter");

/***/ }),

/***/ 3391:
/***/ ((module) => {

module.exports = require("@react-icons/all-files/io5/IoLogoYoutube");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2662:
/***/ ((module) => {

module.exports = require("react-hook-form");

/***/ }),

/***/ 182:
/***/ ((module) => {

module.exports = require("react-mailchimp-subscribe");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5319:
/***/ ((module) => {

module.exports = require("react-use/lib/useWindowSize");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4074:
/***/ ((module) => {

module.exports = require("swiper");

/***/ }),

/***/ 2156:
/***/ ((module) => {

module.exports = require("swiper/react");

/***/ }),

/***/ 9440:
/***/ ((module) => {

module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9892,2123,8218,8147,3170,7831,5013,135,4068,7790,4271,4362,9204,4412,8510,7267,622,193,6945,5330,5748,4471,8899,9471,9755,1856,9230], () => (__webpack_exec__(7774)));
module.exports = __webpack_exports__;

})();