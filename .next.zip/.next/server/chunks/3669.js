"use strict";
exports.id = 3669;
exports.ids = [3669];
exports.modules = {

/***/ 4427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ address_card)
});

// EXTERNAL MODULE: ./src/components/icons/close-icon.tsx
var close_icon = __webpack_require__(7831);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/icons/pencil-icon.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const PencilIcon = props => /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 20 20",
  fill: "currentColor",
  children: /*#__PURE__*/jsx_runtime_.jsx("path", {
    d: "M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"
  })
}));
// EXTERNAL MODULE: ./src/lib/format-address.ts
var format_address = __webpack_require__(2528);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: ./src/framework/rest/utils/constants.ts
var constants = __webpack_require__(3749);
;// CONCATENATED MODULE: ./src/components/address/address-card.tsx










const AddressCard = ({
  checked,
  address,
  userId
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    setModalView,
    setModalData,
    openModal
  } = (0,ui_context/* useUI */.l8)();

  function onEdit() {
    setModalData({
      customerId: userId,
      type: constants/* AddressType.Billing */.D.Billing,
      address: address
    });
    setModalView("ADDRESS_FORM_VIEW");
    return openModal();
  }

  function onDelete() {
    setModalData({
      customerId: userId,
      type: constants/* AddressType.Billing */.D.Billing,
      address: address
    });
    setModalView("ADDRESS_DELETE_VIEW");
    return openModal();
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: external_classnames_default()("relative p-4 lg:p-5 xl:p-6 h-full rounded border cursor-pointer group hover:border-accent", {
      "border-2 border-heading": checked,
      "bg-gray-200 border-gray-100": !checked
    }),
    children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
      className: "text-base text-heading font-semibold mb-2 md:mb-3 capitalize",
      children: address.title
    }), /*#__PURE__*/jsx_runtime_.jsx("p", {
      className: "text-sm text-body leading-6",
      children: (0,format_address/* formatAddress */.T)(address.address)
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "absolute top-4 ltr:right-4 rtl:left-4 flex space-x-2 rtl:space-x-reverse opacity-0 group-hover:opacity-100",
      children: [onEdit && /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        className: "flex items-center justify-center w-5 h-5 rounded-full bg-heading hover:bg-gray-600 text-white",
        onClick: onEdit,
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "sr-only",
          children: t("text-edit")
        }), /*#__PURE__*/jsx_runtime_.jsx(PencilIcon, {
          className: "w-3 h-3"
        })]
      }), onDelete && /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        className: "flex items-center justify-center w-5 h-5 rounded-full bg-[#F34459] text-white",
        onClick: onDelete,
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "sr-only",
          children: t("text-delete")
        }), /*#__PURE__*/jsx_runtime_.jsx(close_icon/* CloseIcon */.T, {
          className: "w-3 h-3"
        })]
      })]
    })]
  });
};

/* harmony default export */ const address_card = (AddressCard);

/***/ }),

/***/ 493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ AddressHeader)
/* harmony export */ });
/* harmony import */ var _components_icons_plus_icon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2816);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const AddressHeader = ({
  onAdd,
  count,
  label
}) => {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("common");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
    className: "flex items-center justify-between mb-5 lg:mb-6 xl:mb-7 -mt-1 xl:-mt-2",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: "flex items-center space-x-3 md:space-x-4 rtl:space-x-reverse text-lg lg:text-xl xl:text-2xl text-heading capitalize font-bold",
      children: [count && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("span", {
        className: "flex items-center justify-center ltr:mr-2 rtl:ml-2",
        children: [count, "."]
      }), label]
    }), onAdd && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("button", {
      className: "flex items-center text-sm font-semibold text-heading transition-colors duration-200 focus:outline-none focus:opacity-70 hover:opacity-70 mt-1",
      onClick: onAdd,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_components_icons_plus_icon__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
        className: "w-4 h-4 stroke-2 ltr:mr-0.5 rtl:ml-0.5 relative top-[1px]"
      }), t("text-add")]
    })]
  });
};

/***/ })

};
;