"use strict";
exports.id = 6945;
exports.ids = [6945];
exports.modules = {

/***/ 2992:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ collection_block)
});

// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: ./src/components/ui/text.tsx
var ui_text = __webpack_require__(4068);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/common/collection-card.tsx








const CollectionCard = ({
  collection,
  imgWidth = 580,
  imgHeight = 580,
  contactClassName = "",
  variant = "default"
}) => {
  const {
    slug,
    image,
    title,
    description
  } = collection;
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
    href: slug,
    className: external_classnames_default()("group text-center flex flex-col sm:last:hidden lg:last:flex border sm:border-0 border-gray-300 overflow-hidden rounded-md pb-4 sm:pb-0", {
      "justify-between sm:even:flex-col-reverse": variant === "default"
    }),
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex mx-auto flex-col relative",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: image !== null && image !== void 0 ? image : "/assets/placeholder/collection.svg",
          alt: t("title") || t("text-card-thumbnail"),
          width: imgWidth,
          height: imgHeight,
          className: "bg-gray-300 object-cover sm:rounded-md transition duration-200 ease-in-out group-hover:opacity-90"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "overflow-hidden absolute bottom-3.5 lg:bottom-5 ltr:right-3.5 ltr:lg:right-5 rtl:left-3.5 rtl:lg:left-5 p-2",
        children: /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "inline-block text-[13px] md:text-sm leading-4 cursor-pointer transition ease-in-out duration-300 font-semibold text-center rounded-md bg-white text-heading shadow-navigation py-3 lg:py-4 px-4 lg:px-6 hover:bg-heading hover:text-white transform lg:translate-y-full lg:opacity-0 lg:group-hover:opacity-100 lg:group-hover:translate-y-0",
          children: t("button-view-collection")
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: contactClassName,
      children: [/*#__PURE__*/jsx_runtime_.jsx(ui_text/* default */.Z, {
        variant: "mediumHeading",
        className: "mb-1.5 lg:mb-2.5 2xl:mb-3 3xl:mb-3.5",
        children: t(`${title}`)
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-body text-[13px] md:text-sm leading-6 md:leading-7 xl:px-10 3xl:px-20",
        children: t(`${description}`)
      })]
    })]
  });
};

/* harmony default export */ const collection_card = (CollectionCard);
;// CONCATENATED MODULE: ./src/containers/collection-block.tsx



const CollectionBlock = ({
  className = "mb-12 md:mb-14 xl:mb-16 pb-0.5 lg:pt-1 xl:pt-0",
  data,
  variant = "default"
}) => {
  var _data$slice;

  const isEven = value => {
    return value % 2;
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: `${className} grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 xl:gap-7`,
    children: data === null || data === void 0 ? void 0 : (_data$slice = data.slice(0, 3)) === null || _data$slice === void 0 ? void 0 : _data$slice.map((item, index) => /*#__PURE__*/jsx_runtime_.jsx(collection_card, {
      collection: item,
      variant: variant,
      contactClassName: isEven(index + 1) == 0 && variant !== "modern" ? "sm:pb-4 md:pb-5 lg:pb-4 2xl:pb-5 3xl:pb-6 pt-3.5 sm:pt-0.5 lg:pt-1 px-4 sm:px-0" : "pt-3.5 lg:pt-4 xl:pt-5 3xl:pt-7 px-4 sm:px-0"
    }, item.id))
  });
};

/* harmony default export */ const collection_block = (CollectionBlock);

/***/ }),

/***/ 776:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ collectionData),
/* harmony export */   "s": () => (/* binding */ modernDemoCollectionData)
/* harmony export */ });
const collectionData = [{
  id: 1,
  slug: "/search",
  image: "/assets/images/collection/1.jpg",
  title: "collection-title-one",
  description: "collection-description-one"
}, {
  id: 2,
  slug: "/search",
  image: "/assets/images/collection/2.jpg",
  title: "collection-title-two",
  description: "collection-description-two"
}, {
  id: 3,
  slug: "/search",
  image: "/assets/images/collection/3.jpg",
  title: "collection-title-three",
  description: "collection-description-three"
}];
const modernDemoCollectionData = [{
  id: 1,
  slug: "/search",
  image: "/assets/images/collection/4.jpg",
  title: "collection-title-one",
  description: "collection-description-one"
}, {
  id: 2,
  slug: "/search",
  image: "/assets/images/collection/5.jpg",
  title: "collection-title-four",
  description: "collection-description-four"
}, {
  id: 3,
  slug: "/search",
  image: "/assets/images/collection/6.jpg",
  title: "collection-title-three",
  description: "collection-description-three"
}];

/***/ })

};
;