"use strict";
exports.id = 2123;
exports.ids = [2123];
exports.modules = {

/***/ 3036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ CoreApi)
/* harmony export */ });
/* harmony import */ var lodash_pickBy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4661);
/* harmony import */ var lodash_pickBy__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_pickBy__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8549);
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



class CoreApi {
  constructor(_base_path) {
    this._base_path = _base_path;

    _defineProperty(this, "http", _request__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z);
  }

  stringifySearchQuery(values) {
    const parsedValues = lodash_pickBy__WEBPACK_IMPORTED_MODULE_0___default()(values);
    return Object.keys(parsedValues).map(k => {
      if (k === 'type') {
        return `${k}.slug:${parsedValues[k]};`;
      }

      if (k === 'category') {
        return `categories.slug:${parsedValues[k]};`;
      }

      if (k === 'tags') {
        return `tags.slug:${parsedValues[k]};`;
      }

      if (k === 'variations') {
        return `variations.value:${parsedValues[k]};`;
      }

      return `${k}:${parsedValues[k]};`;
    }).join('').slice(0, -1);
  }

  find(params) {
    const {
      type,
      text: name,
      category,
      tags,
      variations,
      status,
      is_active,
      shop_id,
      limit = 30,
      sortedBy = "DESC",
      orderBy = "created_at",
      min_price,
      max_price
    } = params;
    const searchString = this.stringifySearchQuery({
      type,
      name,
      category,
      tags,
      variations,
      status,
      shop_id,
      is_active,
      min_price,
      max_price
    });
    const queryString = `?search=${searchString}&searchJoin=and&limit=${limit}&sortedBy=${sortedBy}&orderBy=${orderBy}`;
    return this.http.get(this._base_path + queryString);
  }

  findAll() {
    return this.http.get(this._base_path);
  }

  fetchUrl(url) {
    return this.http.get(url);
  }

  postUrl(url, data) {
    return this.http.post(url, data);
  }

  findOne(id) {
    return this.http.get(`${this._base_path}/${id}`);
  }

  create(data, options) {
    return this.http.post(this._base_path, data, options).then(res => res.data);
  }

  update(id, data) {
    return this.http.put(`${this._base_path}/${id}`, data).then(res => res.data);
  }

  delete(id) {
    return this.http.delete(`${this._base_path}/${id}`);
  }

}

/***/ }),

/***/ 874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ API_ENDPOINTS)
/* harmony export */ });
const API_ENDPOINTS = {
  CATEGORIES: "categories",
  PRODUCTS: "products",
  POPULAR_PRODUCTS: "popular-products",
  SETTINGS: "settings",
  CUSTOMER: "me",
  COUPONS: "coupons",
  EMAIL_VERIFICATION: "vendor/verify-email",
  PARENT_CATEGORIES: "categories",
  FEATURED_CATEGORIES: "featured-categories",
  TYPE: "types",
  UPLOAD: "attachments",
  ORDER: "orders",
  ORDER_STATUS: "order-status",
  LOGIN: "token",
  SOCIAL_LOGIN: "social-login-token",
  REGISTER: "register",
  FORGET_PASSWORD: "forget-password",
  LOGOUT: "logout",
  CHANGE_PASSWORD: "change-password",
  RESET_PASSWORD: "reset-password",
  VERIFY_FORGET_PASSWORD: "verify-forget-password-token",
  VERIFY_CHECKOUT: "orders/checkout/verify",
  CONTACT: "contact-us",
  ADDRESS: "address",
  ATTRIBUTES: "attributes",
  SHOPS: "shops",
  ORDERS: "orders",
  SEND_OTP_CODE: "send-otp-code",
  ADD_CUSTOMER_CONTACT: "add-customer-contact",
  VERIFY_OTP_CODE: "verify-otp-code",
  OTP_LOGIN: "otp-login",
  TWO_FACTOR: "two_factor",
  CONTACT_SEND_OTP_CODE: "contact-otp-code",
  UPDATE_CONTACT: "update-contact",
  CUSTOMERS: "users",
  TAGS: "tags"
};

/***/ }),

/***/ 8549:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ utils_request)
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2376);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(6155);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);
;// CONCATENATED MODULE: ./src/framework/rest/utils/get-token.ts

const getToken = () => {
  if (false) {}

  return external_js_cookie_default().get('auth_token');
};
;// CONCATENATED MODULE: ./src/framework/rest/utils/request.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const request = external_axios_default().create({
  baseURL: "https://api.modernofficefurniture.net/",
  // TODO: take this api URL from env
  timeout: 30000,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json'
  }
}); // Change request data/error here

request.interceptors.request.use(config => {
  const token = getToken();
  config.headers = _objectSpread(_objectSpread({}, config.headers), {}, {
    Authorization: `Bearer ${token ? token : ''}`
  });
  return config;
}, error => {
  return Promise.reject(error);
});
/* harmony default export */ const utils_request = (request);

/***/ }),

/***/ 509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "qW": () => (/* binding */ CART_KEY),
/* harmony export */   "UA": () => (/* binding */ AUTH_TOKEN),
/* harmony export */   "iK": () => (/* binding */ CHECKOUT)
/* harmony export */ });
/* unused harmony exports TOKEN, AUTH_PERMISSIONS, LIMIT, SUPER_ADMIN, CUSTOMER */
const CART_KEY = 'chawk-cart';
const TOKEN = 'token';
const AUTH_TOKEN = 'auth_token';
const AUTH_PERMISSIONS = 'auth_permissions';
const LIMIT = 10;
const SUPER_ADMIN = 'super_admin';
const CUSTOMER = 'customer';
const CHECKOUT = 'chawkbazar-checkout';

/***/ }),

/***/ 8879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ authorizationAtom)
/* harmony export */ });
/* unused harmony export checkIsLoggedIn */
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(509);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8250);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jotai__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6155);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_1__);



function checkIsLoggedIn() {
  const token = js_cookie__WEBPACK_IMPORTED_MODULE_1___default().get(_lib_constants__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_TOKEN */ .UA);
  if (!token) return false;
  return true;
}
const authorizationAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(checkIsLoggedIn());

/***/ }),

/***/ 7900:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "hq": () => (/* binding */ checkoutAtom),
/* harmony export */   "y9": () => (/* binding */ clearCheckoutAtom),
/* harmony export */   "Km": () => (/* binding */ billingAddressAtom),
/* harmony export */   "du": () => (/* binding */ shippingAddressAtom),
/* harmony export */   "Gh": () => (/* binding */ deliveryTimeAtom),
/* harmony export */   "HA": () => (/* binding */ paymentGatewayAtom),
/* harmony export */   "_p": () => (/* binding */ verifiedTokenAtom),
/* harmony export */   "lu": () => (/* binding */ customerContactAtom),
/* harmony export */   "Jb": () => (/* binding */ verifiedResponseAtom),
/* harmony export */   "GO": () => (/* binding */ couponAtom),
/* harmony export */   "yw": () => (/* binding */ discountAtom)
/* harmony export */ });
/* unused harmony export defaultCheckout */
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(509);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8250);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jotai__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jotai_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3837);
/* harmony import */ var jotai_utils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jotai_utils__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const defaultCheckout = {
  billing_address: null,
  shipping_address: null,
  delivery_time: null,
  payment_gateway: 'STRIPE',
  customer_contact: '',
  verified_response: null,
  coupon: null
};
// Original atom.
const checkoutAtom = (0,jotai_utils__WEBPACK_IMPORTED_MODULE_1__.atomWithStorage)(_lib_constants__WEBPACK_IMPORTED_MODULE_2__/* .CHECKOUT */ .iK, defaultCheckout);
const clearCheckoutAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(null, (_get, set, _data) => {
  return set(checkoutAtom, defaultCheckout);
});
const billingAddressAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => get(checkoutAtom).billing_address, (get, set, data) => {
  const prev = get(checkoutAtom);
  return set(checkoutAtom, _objectSpread(_objectSpread({}, prev), {}, {
    billing_address: data
  }));
});
const shippingAddressAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => get(checkoutAtom).shipping_address, (get, set, data) => {
  const prev = get(checkoutAtom);
  return set(checkoutAtom, _objectSpread(_objectSpread({}, prev), {}, {
    shipping_address: data
  }));
});
const deliveryTimeAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => get(checkoutAtom).delivery_time, (get, set, data) => {
  const prev = get(checkoutAtom);
  return set(checkoutAtom, _objectSpread(_objectSpread({}, prev), {}, {
    delivery_time: data
  }));
});
const paymentGatewayAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => get(checkoutAtom).payment_gateway, (get, set, data) => {
  const prev = get(checkoutAtom);
  return set(checkoutAtom, _objectSpread(_objectSpread({}, prev), {}, {
    payment_gateway: data
  }));
});
const verifiedTokenAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => get(checkoutAtom).token, (get, set, data) => {
  const prev = get(checkoutAtom);
  return set(checkoutAtom, _objectSpread(_objectSpread({}, prev), {}, {
    token: data
  }));
});
const customerContactAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => get(checkoutAtom).customer_contact, (get, set, data) => {
  const prev = get(checkoutAtom);
  return set(checkoutAtom, _objectSpread(_objectSpread({}, prev), {}, {
    customer_contact: data
  }));
});
const verifiedResponseAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => get(checkoutAtom).verified_response, (get, set, data) => {
  const prev = get(checkoutAtom);
  return set(checkoutAtom, _objectSpread(_objectSpread({}, prev), {}, {
    verified_response: data
  }));
});
const couponAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => get(checkoutAtom).coupon, (get, set, data) => {
  const prev = get(checkoutAtom);
  return set(checkoutAtom, _objectSpread(_objectSpread({}, prev), {}, {
    coupon: data
  }));
});
const discountAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)(get => {
  var _get$coupon;

  return (_get$coupon = get(checkoutAtom).coupon) === null || _get$coupon === void 0 ? void 0 : _get$coupon.amount;
});

/***/ })

};
;