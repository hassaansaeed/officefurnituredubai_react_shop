exports.id = 6296;
exports.ids = [6296];
exports.modules = {

/***/ 702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9440);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4271);
/* harmony import */ var _components_ui_password_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2875);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7993);
/* harmony import */ var _framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6838);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4580);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4386);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2166);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5013);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6155);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8250);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(jotai__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _store_authorization_atom__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8879);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(509);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1103);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // @ts-ignore

// import { ImFacebook2 } from "@react-icons/all-files/im/ImFacebook2";




















const loginFormSchema = yup__WEBPACK_IMPORTED_MODULE_2__.object().shape({
  email: yup__WEBPACK_IMPORTED_MODULE_2__.string().email("forms:email-error").required("forms:email-required"),
  password: yup__WEBPACK_IMPORTED_MODULE_2__.string().required("forms:password-required")
});
const defaultValues = {
  email: "",
  password: ""
};

const LoginForm = ({
  layout = "modal"
}) => {
  var _errors$email, _errors$password;

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
  const {
    setModalView,
    openModal,
    closeModal
  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_7__/* .useUI */ .l8)();
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
  const {
    0: errorMessage,
    1: setErrorMessage
  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)("");
  const [_, authorize] = (0,jotai__WEBPACK_IMPORTED_MODULE_13__.useAtom)(_store_authorization_atom__WEBPACK_IMPORTED_MODULE_14__/* .authorizationAtom */ .O);
  const {
    mutate: login,
    isLoading: loading
  } = (0,_framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_6__/* .useLoginMutation */ .YA)();
  const {
    register,
    handleSubmit,
    formState: {
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_0__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_9__.yupResolver)(loginFormSchema),
    defaultValues
  });

  function onSubmit({
    email,
    password,
    remember_me
  }) {
    login({
      email,
      password
    }, {
      onSuccess: data => {
        var _data$permissions;

        console.log("🚀 ~ file: login-form.tsx:75 ~ onSubmit ~ data", data);
        localStorage.setItem("user_id", data.user_id);

        if (data !== null && data !== void 0 && data.token && data !== null && data !== void 0 && (_data$permissions = data.permissions) !== null && _data$permissions !== void 0 && _data$permissions.length) {
          js_cookie__WEBPACK_IMPORTED_MODULE_12___default().set(_lib_constants__WEBPACK_IMPORTED_MODULE_19__/* .AUTH_TOKEN */ .UA, data.token, {
            expires: remember_me ? 365 : undefined
          });
          authorize(true);

          if (layout === "page") {
            // Redirect to the my-account page
            return router.push(_lib_routes__WEBPACK_IMPORTED_MODULE_16__/* .ROUTES.ACCOUNT */ .Z.ACCOUNT);
          } else {
            closeModal();
            return;
          }
        } else if (data.status === 0) {
          localStorage.setItem("user_id", data.user_id);
          setModalView("EMAIL_VERIFICATION_VIEW");
          react_toastify__WEBPACK_IMPORTED_MODULE_17__.toast.dark(data.message);
        }

        if (!data.token) {
          setErrorMessage(t("forms:error-credential-wrong"));
        }
      },
      onError: error => {
        console.log(error.message);
      }
    });
  }

  function handleSignUp() {
    if (layout === "modal") {
      setModalView("SIGN_UP_VIEW");
      return openModal();
    } else {
      router.push(`${_lib_routes__WEBPACK_IMPORTED_MODULE_16__/* .ROUTES.SIGN_UP */ .Z.SIGN_UP}`);
    }
  }

  function handleForgetPassword() {
    if (layout === "modal") {
      setModalView("FORGET_PASSWORD");
      return openModal();
    } else {
      router.push(`${_lib_routes__WEBPACK_IMPORTED_MODULE_16__/* .ROUTES.FORGET_PASSWORD */ .Z.FORGET_PASSWORD}`);
    }
  }

  function handleOtpLogin() {
    if (layout === "modal") {
      setModalView("OTP_LOGIN_VIEW");
      return openModal();
    } else {
      router.push(`${_lib_routes__WEBPACK_IMPORTED_MODULE_16__/* .ROUTES.OTP_LOGIN */ .Z.OTP_LOGIN}`);
    }
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
    className: "overflow-hidden bg-white mx-auto rounded-lg w-full sm:w-96 md:w-450px border border-gray-300 py-5 px-5 sm:px-8",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
      className: "text-center mb-6 pt-2.5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
        onClick: closeModal,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {})
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("p", {
        className: "text-sm md:text-base text-body mt-2 mb-8 sm:mb-10",
        children: t("common:login-helper")
      })]
    }), errorMessage && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
      message: errorMessage,
      variant: "error",
      className: "my-3"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("form", {
      onSubmit: handleSubmit(onSubmit),
      className: "flex flex-col justify-center",
      noValidate: true,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
        className: "flex flex-col space-y-3.5",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_components_ui_input__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, _objectSpread(_objectSpread({
          labelKey: "forms:label-email-star",
          type: "email",
          variant: "solid"
        }, register("email")), {}, {
          errorKey: (_errors$email = errors.email) === null || _errors$email === void 0 ? void 0 : _errors$email.message
        })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_components_ui_password_input__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, _objectSpread({
          labelKey: "forms:label-password-star",
          errorKey: (_errors$password = errors.password) === null || _errors$password === void 0 ? void 0 : _errors$password.message
        }, register("password"))), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
          className: "flex items-center justify-center",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex items-center flex-shrink-0",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("label", {
              className: "switch relative inline-block w-10 cursor-pointer",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("input", _objectSpread({
                id: "remember",
                type: "checkbox",
                className: "opacity-0 w-0 h-0"
              }, register("remember_me"))), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("span", {
                className: "bg-gray-500 absolute inset-0 transition-all duration-300 ease-in slider round"
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("label", {
              htmlFor: "remember",
              className: "flex-shrink-0 text-sm text-heading ltr:pl-3 rtl:pr-3 cursor-pointer",
              children: t("forms:label-remember-me")
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
            className: "flex ltr:ml-auto rtl:mr-auto",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("button", {
              type: "button",
              onClick: handleForgetPassword,
              className: "ltr:text-right rtl:text-left text-sm text-heading ltr:pl-3 rtl:pr-3 underline hover:no-underline focus:no-underline focus:outline-none",
              children: t("common:text-forgot-password")
            })
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
          className: "relative",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
            type: "submit",
            loading: loading,
            disabled: loading,
            className: "h-11 md:h-12 w-full mt-1.5",
            children: t("common:text-login")
          })
        })]
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
      className: "flex flex-col items-center justify-center relative text-sm text-heading mt-6 mb-3.5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("hr", {
        className: "w-full border-gray-300"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("span", {
        className: "absolute -top-2.5 px-2 bg-white",
        children: t("common:text-or")
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
      className: "text-sm sm:text-base text-body text-center mt-5 mb-1",
      children: [t("common:text-no-account"), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("button", {
        type: "button",
        className: "text-sm sm:text-base text-heading underline font-bold hover:no-underline focus:no-underline focus:outline-none",
        onClick: handleSignUp,
        children: t("common:text-register")
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
      className: "flex flex-col items-center justify-center relative text-sm text-heading mt-6 mb-3.5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("hr", {
        className: "w-full border-gray-300"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("span", {
        className: "absolute -top-2.5 px-2 bg-white",
        children: t("common:text-or")
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
      className: "text-sm sm:text-base text-body text-center mt-5 mb-1",
      children: ["Want to be Vendor?", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("button", {
        type: "button",
        className: "text-sm sm:text-base text-heading underline font-bold hover:no-underline focus:no-underline focus:outline-none",
        onClick: handleSignUp,
        children: t("common:text-register")
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginForm);

/***/ }),

/***/ 8883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _page_loader_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1381);
/* harmony import */ var _page_loader_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_page_loader_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);





const PageLoader = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_0___default()("w-full h-screen flex flex-col items-center justify-center"),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: "flex relative",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
        className: (_page_loader_module_css__WEBPACK_IMPORTED_MODULE_2___default().page_loader)
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
        className: "text-sm font-semibold text-body italic absolute top-1/2 -mt-2 w-full text-center",
        children: "Loading..."
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageLoader);

/***/ }),

/***/ 1381:
/***/ ((module) => {

// Exports
module.exports = {
	"page_loader": "page-loader_page_loader__2Bj7D",
	"spin": "page-loader_spin__1ZvtZ",
	"heart-beat": "page-loader_heart-beat__389xr"
};


/***/ })

};
;