"use strict";
exports.id = 1997;
exports.ids = [1997];
exports.modules = {

/***/ 1997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ exclusive_block)
});

// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
;// CONCATENATED MODULE: ./src/data/static/exclusive-block.ts
const exclusiveBlock = {
  exclusiveName: "text-new-year",
  year: 2021,
  exclusiveData: [{
    id: 1,
    slug: "/collections/womens-collection",
    buttonText: "button-women-exclusive",
    image: "/assets/images/exclusive/women.png",
    backgroundColor: "bg-gray-150"
  }, {
    id: 2,
    slug: "/collections/mens-collection",
    buttonText: "button-men-exclusive",
    image: "/assets/images/exclusive/men.png",
    backgroundColor: "bg-linenSecondary"
  }]
};
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/containers/exclusive-block.tsx







const ExclusiveBlock = ({
  className = "mb-12 md:mb-14 xl:mb-16"
}) => {
  var _data$exclusiveData;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: `rounded-md overflow-hidden lg:block ${className}`,
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-between",
      children: exclusiveBlock === null || exclusiveBlock === void 0 ? void 0 : (_data$exclusiveData = exclusiveBlock.exclusiveData) === null || _data$exclusiveData === void 0 ? void 0 : _data$exclusiveData.slice(0, 2).map(item => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `group w-2/4 flex justify-between items-end relative transition duration-200 ease-in ${item.id === 2 ? "flex-row-reverse bg-linenSecondary" : "bg-gray-150"}`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "exclusiveImage relative z-10 flex transform transition duration-200 ease-in group-hover:scale-105",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: item.image,
            alt: item.buttonText,
            width: 600,
            height: 600
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
          href: item.slug,
          className: `absolute z-10 bottom-3 sm:bottom-5 xl:bottom-7 inline-block bg-white shadow-product rounded-md text-heading lowercase text-sm xl:text-xl 2xl:text-xl sm:uppercase px-3 sm:px-5 xl:px-6 2xl:px-8 py-2.5 sm:py-4 xl:py-5 2xl:py-7  transform transition duration-300 ease-in-out hover:bg-heading hover:text-white ${item.id === 2 ? "ltr:left-3 ltr:sm:left-5 ltr:xl:left-7 rtl:right-3 rtl:sm:right-5 rtl:xl:right-7" : "ltr:right-3 ltr:sm:right-5 ltr:xl:right-7 rtl:left-3 rtl:sm:left-5 rtl:xl:left-7"}`,
          children: t(`${item.buttonText}`)
        }), exclusiveBlock.exclusiveName && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `z-0 absolute top-10 xl:top-12 2xl:top-16 3xl:top-24 uppercase text-black opacity-10 text-xl xl:text-2xl 3xl:text-3xl tracking-widest leading-5 ${item.id === 2 ? "ltr:left-5 ltr:xl:left-7 rtl:right-5 rtl:xl:right-7" : "ltr:right-5 ltr:xl:right-7 rtl:left-5 rtl:xl:left-7"}`,
          children: item.id !== 2 ? t(`${exclusiveBlock.exclusiveName}`) : t("text-exclusive")
        }), exclusiveBlock.year && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `exclusiveYear absolute top-16 xl:top-20 2xl:top-24 3xl:top-32 ltr:left-0 rtl:right-0 z-10 text-black font-bold leading-none tracking-widest ${item.id === 2 ? "ltr:text-left rtl:text-right pl-4 ltr:left-0 rtl:right-0" : "ltr:text-right rtl:text-left ltr:right-0 rtl:left-0"}`,
          children: item.id !== 2 ? exclusiveBlock.year.toString().slice(0, 2) : exclusiveBlock.year.toString().slice(2, 4)
        })]
      }, `exclusive--key${item.id}`))
    })
  });
};

/* harmony default export */ const exclusive_block = (ExclusiveBlock);

/***/ })

};
;