"use strict";
exports.id = 3786;
exports.ids = [3786];
exports.modules = {

/***/ 6678:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var _framework_settings_settings_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(659);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3295);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _framework_category_categories_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4362);
/* harmony import */ var _framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4412);
/* harmony import */ var _framework_products_products_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2317);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5278);
/* harmony import */ var _framework_products_popular_products_query__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8208);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9475);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_query_hydration__WEBPACK_IMPORTED_MODULE_9__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











const getStaticProps = async ({
  locale
}) => {
  const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_0__.QueryClient({
    defaultOptions: {
      queries: {
        staleTime: Infinity
      }
    }
  });

  try {
    var _siteSettings$homePag, _siteSettings$homePag2;

    await Promise.all([await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.SETTINGS */ .P.SETTINGS, _framework_settings_settings_query__WEBPACK_IMPORTED_MODULE_2__/* .fetchSettings */ .w), await queryClient.prefetchQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.CATEGORIES */ .P.CATEGORIES, {
      limit: 10,
      parent: null
    }], _framework_category_categories_query__WEBPACK_IMPORTED_MODULE_4__/* .fetchCategories */ .pE), // Fetch products based on tags -> flash-sale products
    await queryClient.prefetchQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS, {
      limit: 10,
      tags: _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings */ .U === null || _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings */ .U === void 0 ? void 0 : (_siteSettings$homePag = _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings.homePageBlocks */ .U.homePageBlocks) === null || _siteSettings$homePag === void 0 ? void 0 : (_siteSettings$homePag2 = _siteSettings$homePag.flashSale) === null || _siteSettings$homePag2 === void 0 ? void 0 : _siteSettings$homePag2.slug
    }], _framework_products_products_query__WEBPACK_IMPORTED_MODULE_6__/* .fetchProducts */ .t2), // Fetch products based on tags -> new arrival products
    await queryClient.prefetchQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS, {
      limit: 10,
      orderBy: "created_at",
      sortedBy: "DESC"
    }], _framework_products_products_query__WEBPACK_IMPORTED_MODULE_6__/* .fetchProducts */ .t2), // Fetch popular products
    await queryClient.prefetchQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.POPULAR_PRODUCTS */ .P.POPULAR_PRODUCTS, {
      limit: 10
    }], _framework_products_popular_products_query__WEBPACK_IMPORTED_MODULE_8__/* .fetchPopularProducts */ .R), await queryClient.prefetchQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.TYPE */ .P.TYPE, {
      limit: 16
    }], _framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_5__/* .fetchBrands */ .S0)]);
    return {
      props: _objectSpread(_objectSpread({}, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_3__.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
        dehydratedState: JSON.parse(JSON.stringify((0,react_query_hydration__WEBPACK_IMPORTED_MODULE_9__.dehydrate)(queryClient)))
      }),
      revalidate: Number(process.env.REVALIDATE_DURATION) || 120
    };
  } catch (error) {
    // If we get here means something went wrong in promise fetching
    return {
      notFound: true
    };
  }
};

/***/ }),

/***/ 3786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* reexport */ standard/* getStaticProps */.b)
});

// EXTERNAL MODULE: ./src/components/common/banner-card.tsx
var banner_card = __webpack_require__(5038);
// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ./src/containers/collection-block.tsx + 1 modules
var collection_block = __webpack_require__(2992);
// EXTERNAL MODULE: ./src/containers/banner-carousel-block.tsx
var banner_carousel_block = __webpack_require__(1298);
// EXTERNAL MODULE: ./src/components/ui/divider.tsx
var divider = __webpack_require__(5313);
// EXTERNAL MODULE: ./src/components/ui/carousel/carousel.tsx
var carousel = __webpack_require__(4365);
// EXTERNAL MODULE: ./src/utils/use-window-size.ts
var use_window_size = __webpack_require__(3396);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "swiper/react"
var react_ = __webpack_require__(2156);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/containers/hero-block.tsx






const breakpoints = {
  "1500": {
    slidesPerView: 2
  },
  "0": {
    slidesPerView: 1
  }
};

const HeroBlock = ({
  data
}) => {
  const {
    width
  } = (0,use_window_size/* useWindowSize */.i)();
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "heroBannerOne relative max-w-[1920px] mb-5 md:mb-12 lg:mb-14 2xl:mb-16 mx-auto overflow-hidden px-4 md:px-8 2xl:px-0",
    children: /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
      breakpoints: breakpoints,
      centeredSlides: width < 1500 ? false : true,
      autoplay: {
        delay: 5000
      },
      className: "mx-0",
      buttonClassName: "hidden",
      pagination: {
        clickable: true
      },
      children: data === null || data === void 0 ? void 0 : data.map(banner => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
        className: "carouselItem px-0 2xl:px-3.5",
        children: /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
          data: banner,
          href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banner.slug}`
        })
      }, `banner--key-${banner === null || banner === void 0 ? void 0 : banner.id}`))
    })
  });
};

/* harmony default export */ const hero_block = (HeroBlock);
// EXTERNAL MODULE: ./src/containers/brand-block.tsx
var brand_block = __webpack_require__(5748);
// EXTERNAL MODULE: ./src/containers/category-block.tsx + 2 modules
var category_block = __webpack_require__(622);
// EXTERNAL MODULE: ./src/containers/feature-block.tsx + 2 modules
var feature_block = __webpack_require__(1886);
// EXTERNAL MODULE: ./src/components/layout/layout.tsx
var layout = __webpack_require__(2061);
// EXTERNAL MODULE: ./src/components/common/sale-with-progress.tsx + 3 modules
var sale_with_progress = __webpack_require__(2577);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/404/not-found-item.tsx
var not_found_item = __webpack_require__(6857);
// EXTERNAL MODULE: ./src/settings/site.settings.tsx + 6 modules
var site_settings = __webpack_require__(5278);
;// CONCATENATED MODULE: ./src/components/product/feeds/flash-sale-product-feed.tsx












const banner = {
  id: 1,
  title: "banner-on-selected-items",
  slug: "search",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-2.jpg",
      width: 450,
      height: 150
    },
    desktop: {
      url: "/assets/images/banner/banner-2.jpg",
      width: 1190,
      height: 450
    }
  }
};
const flashSaleCarouselBreakpoint = {
  "1280": {
    slidesPerView: 1
  },
  "1025": {
    slidesPerView: 2,
    spaceBetween: 28
  },
  "768": {
    slidesPerView: 2,
    spaceBetween: 20
  },
  "0": {
    slidesPerView: 1
  }
};

const FlashSaleBlock = ({
  className = "mb-12 lg:mb-14 xl:mb-7",
  limit = 10
}) => {
  var _siteSettings$homePag;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const flashSellSettings = site_settings/* siteSettings */.U === null || site_settings/* siteSettings */.U === void 0 ? void 0 : (_siteSettings$homePag = site_settings/* siteSettings.homePageBlocks */.U.homePageBlocks) === null || _siteSettings$homePag === void 0 ? void 0 : _siteSettings$homePag.flashSale;
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,products_query/* useProductsQuery */.kN)({
    limit,
    tags: flashSellSettings === null || flashSellSettings === void 0 ? void 0 : flashSellSettings.slug
  });

  if (!loading && isEmpty_default()(products === null || products === void 0 ? void 0 : products.data)) {
    return /*#__PURE__*/jsx_runtime_.jsx(not_found_item/* default */.Z, {
      text: t("text-no-flash-products-found")
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: external_classnames_default()(`grid grid-cols-1 xl:grid-cols-3 gap-y-12 lg:gap-y-14 xl:gap-y-0 xl:gap-x-7`, className),
    children: [/*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
      data: banner,
      href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banner.slug}`,
      className: "xl:h-full xl:col-span-2",
      effectActive: true
    }, `banner--key${banner.id}`), error ? /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/jsx_runtime_.jsx(sale_with_progress/* default */.Z, {
      carouselBreakpoint: flashSaleCarouselBreakpoint,
      products: products === null || products === void 0 ? void 0 : products.data,
      loading: loading,
      className: "col-span-full xl:col-span-1 lg:mb-1 xl:mb-0"
    })]
  });
};

/* harmony default export */ const flash_sale_product_feed = (FlashSaleBlock);
// EXTERNAL MODULE: ./src/components/product/feeds/best-seller-product-feed.tsx
var best_seller_product_feed = __webpack_require__(2563);
// EXTERNAL MODULE: ./src/components/product/feeds/new-arrivals-product-feed.tsx
var new_arrivals_product_feed = __webpack_require__(4584);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: ./src/data/static/banners.ts
var banners = __webpack_require__(5941);
// EXTERNAL MODULE: ./src/data/static/collection.ts
var collection = __webpack_require__(776);
// EXTERNAL MODULE: ./src/framework/rest/ssr/homepage/standard.ts
var standard = __webpack_require__(6678);
;// CONCATENATED MODULE: ./src/pages/standard.tsx






















function Home() {
  const {
    openModal,
    setModalView
  } = (0,ui_context/* useUI */.l8)();
  (0,external_react_.useEffect)(() => {
    setModalView('NEWSLETTER_VIEW');
    setTimeout(() => {
      openModal();
    }, 2000);
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(hero_block, {
      data: banners/* standardDemoHeroBanner */.RW
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(container/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(flash_sale_product_feed, {}), /*#__PURE__*/jsx_runtime_.jsx(banner_carousel_block/* default */.Z, {
        banners: banners/* standardDemoPromotionBanner */.bF
      }), /*#__PURE__*/jsx_runtime_.jsx(category_block/* default */.Z, {
        sectionHeading: "text-shop-by-category"
      }), /*#__PURE__*/jsx_runtime_.jsx(divider/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(best_seller_product_feed/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
        data: banners/* standardDemoBanner */.gS,
        href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banners/* standardDemoBanner.slug */.gS.slug}`,
        className: "mb-12 lg:mb-14 xl:mb-16 pb-0.5 lg:pb-1 xl:pb-0",
        classNameInner: "h-28 sm:h-auto"
      }), /*#__PURE__*/jsx_runtime_.jsx(new_arrivals_product_feed/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(divider/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(brand_block/* default */.Z, {
        sectionHeading: "text-top-brands"
      }), /*#__PURE__*/jsx_runtime_.jsx(collection_block/* default */.Z, {
        data: collection/* collectionData */.B
      }), /*#__PURE__*/jsx_runtime_.jsx(feature_block/* default */.Z, {})]
    })]
  });
}
Home.getLayout = layout/* getLayout */.G;

/***/ })

};
;