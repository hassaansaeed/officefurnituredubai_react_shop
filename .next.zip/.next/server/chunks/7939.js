"use strict";
exports.id = 7939;
exports.ids = [7939];
exports.modules = {

/***/ 2563:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BestSellerProductFeed)
/* harmony export */ });
/* harmony import */ var _containers_products_block__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1402);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_404_not_found_item__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6857);
/* harmony import */ var _framework_products_popular_products_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8208);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);






function BestSellerProductFeed() {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,_framework_products_popular_products_query__WEBPACK_IMPORTED_MODULE_4__/* .usePopularProductsQuery */ .T)({
    limit: 10
  });

  if (!loading && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(products)) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_404_not_found_item__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
      text: t("text-no-best-selling-products-found")
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_containers_products_block__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
    sectionHeading: "text-best-sellers",
    products: products,
    loading: loading,
    error: error === null || error === void 0 ? void 0 : error.message,
    uniqueKey: "best-sellers"
  });
}

/***/ }),

/***/ 1886:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ feature_block)
});

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/common/text-information.tsx






const TextInformation = ({
  item,
  className
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: external_classnames_default()(`text-center border-gray-300 xl:border-l ltr:xl:first:border-l-0 rtl:ltr:xl:first:border-r-0 px-4 sm:px-2.5 2xl:px-8 3xl:px-12 xl:py-12`, className),
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mb-3.5 md:mb-5 xl:mb-3.5 2xl:mb-5 w-14 md:w-auto mx-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: item.icon,
        alt: t(`${item.title}`),
        width: "78",
        height: "78"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "-mb-1",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: "text-heading text-base md:text-lg font-semibold mb-1.5 md:mb-2",
        children: t(`${item.title}`)
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-body text-xs md:text-sm leading-6 md:leading-7",
        children: t(`${item.description}`)
      })]
    })]
  });
};

/* harmony default export */ const text_information = (TextInformation);
;// CONCATENATED MODULE: ./src/data/static/feature-block.ts
const featureBlock = [{
  id: 1,
  icon: "/assets/images/feature/saving.svg",
  title: "feature-title-one",
  description: "feature-description-one"
}, {
  id: 2,
  icon: "/assets/images/feature/risk-free.svg",
  title: "feature-title-two",
  description: "feature-description-two"
}, {
  id: 3,
  icon: "/assets/images/feature/delivery.svg",
  title: "feature-title-three",
  description: "feature-description-three"
}, {
  id: 4,
  icon: "/assets/images/feature/product.svg",
  title: "feature-title-four",
  description: "feature-description-four"
}];
;// CONCATENATED MODULE: ./src/containers/feature-block.tsx




const FeatureBlock = ({
  className = "mb-12 md:mb-14 xl:mb-16"
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: `${className} bg-gray-200 feature-block-wrapper border border-gray-300 rounded-md w-full grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-10 md:gap-12 xl:gap-0 overflow-hidden py-12 xl:py-0 sm:px-4 md:px-8 lg:px-16 xl:px-0`,
    children: featureBlock === null || featureBlock === void 0 ? void 0 : featureBlock.map(item => /*#__PURE__*/jsx_runtime_.jsx(text_information, {
      item: item
    }, item.id))
  });
};

/* harmony default export */ const feature_block = (FeatureBlock);

/***/ }),

/***/ 8208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ usePopularProductsQuery),
/* harmony export */   "R": () => (/* binding */ fetchPopularProducts)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var _framework_utils_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8549);




const fetchPopularProducts = async ({
  queryKey
}) => {
  const [_key, params] = queryKey;
  const {
    limit = 10
  } = params;
  const url = `${_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.POPULAR_PRODUCTS */ .P.POPULAR_PRODUCTS}?&limit=${limit}`;
  const {
    data
  } = await _framework_utils_request__WEBPACK_IMPORTED_MODULE_2__/* .default.get */ .Z.get(url);
  return data;
};

const usePopularProductsQuery = options => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.POPULAR_PRODUCTS */ .P.POPULAR_PRODUCTS, options], fetchPopularProducts);
};



/***/ })

};
;