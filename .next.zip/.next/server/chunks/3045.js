"use strict";
exports.id = 3045;
exports.ids = [3045];
exports.modules = {

/***/ 3045:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ account_layout)
});

// EXTERNAL MODULE: ./src/components/ui/page-header.tsx
var page_header = __webpack_require__(3246);
// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoLogOutOutline"
var IoLogOutOutline_ = __webpack_require__(4411);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/my-account/account-nav.tsx







function AccountNav({
  options
}) {
  const {
    pathname
  } = (0,router_.useRouter)();
  const newPathname = pathname.split("/").slice(2, 3);
  const mainPath = `/${newPathname[0]}`;
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
    className: "flex flex-col",
    children: [options === null || options === void 0 ? void 0 : options.map(item => {
      const menuPathname = item.slug.split("/").slice(2, 3);
      const menuPath = `/${menuPathname[0]}`;
      return /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
        href: item.slug,
        className: mainPath === menuPath ? "bg-gray-100 font-semibold flex items-center cursor-pointer text-sm lg:text-base text-heading py-3.5 px-4 lg:px-5 rounded mb-2 " : "flex items-center cursor-pointer text-sm lg:text-base text-heading font-normal py-3.5 px-4 lg:px-5 rounded mb-2",
        children: [item.icon, /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ltr:pl-2 rtl:pr-2",
          children: t(`${item.name}`)
        })]
      }, item.slug);
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
      href: `${routes/* ROUTES.LOGOUT */.Z.LOGOUT}`,
      className: "flex items-center cursor-pointer text-sm lg:text-base text-heading font-normal py-3.5 px-4 lg:px-5 focus:outline-none",
      children: [/*#__PURE__*/jsx_runtime_.jsx(IoLogOutOutline_.IoLogOutOutline, {
        className: "w-5 h-5"
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "ltr:pl-2 rtl:pr-2",
        children: t("text-logout")
      })]
    })]
  });
}
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@headlessui/react"
var react_ = __webpack_require__(4025);
// EXTERNAL MODULE: external "@react-icons/all-files/fa/FaChevronDown"
var FaChevronDown_ = __webpack_require__(2731);
;// CONCATENATED MODULE: ./src/components/my-account/account-nav-mobile.tsx










function AccountNavMobile({
  options
}) {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const router = (0,router_.useRouter)();
  const {
    pathname
  } = router;
  const currentSelectedItem = pathname ? options.find(o => o.slug === pathname) : options[0];
  const {
    0: selectedItem,
    1: setSelectedItem
  } = (0,external_react_.useState)(currentSelectedItem);
  (0,external_react_.useEffect)(() => {
    setSelectedItem(currentSelectedItem);
  }, [currentSelectedItem]);

  function handleItemClick(slugs) {
    setSelectedItem(slugs);
    router.push(slugs.slug);
  }

  return /*#__PURE__*/jsx_runtime_.jsx(react_.Listbox, {
    value: selectedItem,
    onChange: handleItemClick,
    children: ({
      open
    }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "relative w-full font-body",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Listbox.Button, {
        className: "relative w-full p-4 md:p-5 ltr:text-left rtl:text-right rounded focus:outline-none cursor-pointer border border-gray-300 bg-gray-200 flex items-center",
        children: [selectedItem === null || selectedItem === void 0 ? void 0 : selectedItem.icon, /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "flex truncate items-center text-sm md:text-[15px] ltr:pl-2.5 rtl:pr-2.5 relative text-heading font-semibold",
          children: t(selectedItem === null || selectedItem === void 0 ? void 0 : selectedItem.name)
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "absolute inset-y-0 ltr:right-4 ltr:md:right-5 rtl:left-4 rtl:md:left-5 flex items-center pointer-events-none",
          children: /*#__PURE__*/jsx_runtime_.jsx(FaChevronDown_.FaChevronDown, {
            className: "w-3 md:w-3.5 h-3 md:h-3.5 text-base text-opacity-70",
            "aria-hidden": "true"
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(react_.Transition, {
        show: open,
        as: external_react_.Fragment,
        leave: "transition ease-in duration-100",
        leaveFrom: "opacity-100",
        leaveTo: "opacity-0",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Listbox.Options, {
          static: true,
          className: "absolute z-20 w-full py-2.5 mt-1.5 overflow-auto bg-white rounded-md shadow-dropDown max-h-72 focus:outline-none text-sm md:text-[15px]",
          children: [options === null || options === void 0 ? void 0 : options.map((option, index) => /*#__PURE__*/jsx_runtime_.jsx(react_.Listbox.Option, {
            className: ({
              active
            }) => `cursor-pointer relative py-3 px-4 md:px-5 ${active ? "text-md md:text-base bg-gray-200" : "text-md md:text-base"}`,
            value: option,
            children: ({
              selected,
              active
            }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
              className: "flex items-center",
              children: [option === null || option === void 0 ? void 0 : option.icon, /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: `block truncate ltr:pl-2.5 rtl:pr-2.5 ltr:md:pl-3 rtl:md:pr-3 ${selected ? "font-semibold text-heading" : "font-normal"}`,
                children: t(option === null || option === void 0 ? void 0 : option.name)
              }), selected ? /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: `${active && "text-amber-600"}
                                 absolute inset-y-0 ltr:left-0 rtl:right-0 flex items-center ltr:pl-3 rtl:pr-3`
              }) : null]
            })
          }, index)), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
            className: "w-full flex items-center text-sm lg:text-[15px] py-3 px-4 md:px-5 cursor-pointer focus:outline-none hover:bg-gray-200",
            href: `${routes/* ROUTES.LOGOUT */.Z.LOGOUT}`,
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "flex-shrink-0 flex justify-center",
              children: /*#__PURE__*/jsx_runtime_.jsx(IoLogOutOutline_.IoLogOutOutline, {
                className: "w-[18px] md:w-5 h-[18px] md:h-5"
              })
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "block truncate ltr:pl-2.5 rtl:pr-2.5 ltr:md:pl-3 rtl:md:pr-3",
              children: t("text-logout")
            })]
          })]
        })
      })]
    })
  });
}
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoHomeOutline"
var IoHomeOutline_ = __webpack_require__(9224);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoCartOutline"
var IoCartOutline_ = __webpack_require__(7001);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoPersonOutline"
var IoPersonOutline_ = __webpack_require__(9368);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoCallOutline"
var IoCallOutline_ = __webpack_require__(4845);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoSettingsOutline"
var IoSettingsOutline_ = __webpack_require__(5515);
;// CONCATENATED MODULE: ./src/components/my-account/account-layout.tsx













const accountMenu = [{
  slug: routes/* ROUTES.ACCOUNT */.Z.ACCOUNT,
  name: 'text-dashboard',
  icon: /*#__PURE__*/jsx_runtime_.jsx(IoHomeOutline_.IoHomeOutline, {
    className: "w-[18px] md:w-5 h-[18px] md:h-5"
  })
}, {
  slug: routes/* ROUTES.ACCOUNT_ORDERS */.Z.ACCOUNT_ORDERS,
  name: 'text-orders',
  icon: /*#__PURE__*/jsx_runtime_.jsx(IoCartOutline_.IoCartOutline, {
    className: "w-[18px] md:w-5 h-[18px] md:h-5"
  })
}, {
  slug: routes/* ROUTES.ACCOUNT_ADDRESS */.Z.ACCOUNT_ADDRESS,
  name: 'text-account-address',
  icon: /*#__PURE__*/jsx_runtime_.jsx(IoPersonOutline_.IoPersonOutline, {
    className: "w-[18px] md:w-5 h-[18px] md:h-5"
  })
}, {
  slug: routes/* ROUTES.ACCOUNT_CONTACT_NUMBER */.Z.ACCOUNT_CONTACT_NUMBER,
  name: 'text-contact-number',
  icon: /*#__PURE__*/jsx_runtime_.jsx(IoCallOutline_.IoCallOutline, {
    className: "w-[18px] md:w-5 h-[18px] md:h-5"
  })
}, {
  slug: routes/* ROUTES.ACCOUNT_CHANGE_PASSWORD */.Z.ACCOUNT_CHANGE_PASSWORD,
  name: 'text-change-password',
  icon: /*#__PURE__*/jsx_runtime_.jsx(IoSettingsOutline_.IoSettingsOutline, {
    className: "w-[18px] md:w-5 h-[18px] md:h-5"
  })
}];

const AccountLayout = ({
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(page_header/* default */.Z, {
      pageHeader: "text-page-my-account"
    }), /*#__PURE__*/jsx_runtime_.jsx(container/* default */.Z, {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "py-16 lg:py-20 px-0 xl:max-w-screen-xl mx-auto flex  md:flex-row w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col lg:flex-row w-full",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "lg:hidden",
            children: /*#__PURE__*/jsx_runtime_.jsx(AccountNavMobile, {
              options: accountMenu
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "hidden lg:block flex-shrink-0 md:w-2/6 2xl:w-4/12 ltr:md:pr-8 ltr:lg:pr-12 ltr:xl:pr-16 ltr:2xl:pr-20 rtl:md:pl-8 rtl:lg:pl-12 rtl:xl:pl-16 rtl:2xl:pl-20 pb-2 md:pb-0",
            children: /*#__PURE__*/jsx_runtime_.jsx(AccountNav, {
              options: accountMenu
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "lg:w-4/6 2xl:w-8/12 mt-6 lg:mt-0",
            children: children
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const account_layout = (AccountLayout);

/***/ })

};
;