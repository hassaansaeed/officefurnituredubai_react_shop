"use strict";
exports.id = 5748;
exports.ids = [5748];
exports.modules = {

/***/ 5748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3765);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7125);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4365);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2156);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ui_loaders_card_rounded_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1802);
/* harmony import */ var _framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4412);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1103);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5013);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_404_not_found_item__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6857);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _lib_filter_brands__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7640);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);















const breakpoints = {
  "1720": {
    slidesPerView: 8,
    spaceBetween: 28
  },
  "1400": {
    slidesPerView: 7,
    spaceBetween: 28
  },
  "1025": {
    slidesPerView: 6,
    spaceBetween: 28
  },
  "768": {
    slidesPerView: 5,
    spaceBetween: 20
  },
  "500 ": {
    slidesPerView: 4,
    spaceBetween: 20
  },
  "0": {
    slidesPerView: 3,
    spaceBetween: 12
  }
};

const BrandBlock = ({
  className = "mb-11 md:mb-11 lg:mb-12 xl:mb-14 lg:pb-1 xl:pb-0",
  sectionHeading
}) => {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_11__.useTranslation)();
  const {
    data: brands,
    isLoading: loading,
    error
  } = (0,_framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_5__/* .useBrandsQuery */ .ac)({
    limit: 16
  });

  if (!loading && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_8___default()(brands === null || brands === void 0 ? void 0 : brands.data)) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_404_not_found_item__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
      text: t("text-no-brands-found")
    });
  } // Filter brands for grid layout


  const sliderBrand = (0,_lib_filter_brands__WEBPACK_IMPORTED_MODULE_13__/* .filterBrands */ .b)(brands === null || brands === void 0 ? void 0 : brands.data, "slider-layout");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      sectionHeading: sectionHeading
    }), error ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      breakpoints: breakpoints,
      loop: false,
      buttonClassName: "-mt-8 md:-mt-12",
      children: loading && !(brands !== null && brands !== void 0 && brands.data) ? Array.from({
        length: 7
      }).map((_, idx) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_ui_loaders_card_rounded_loader__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
          uniqueKey: `category-${idx}`
        })
      }, idx)) : sliderBrand === null || sliderBrand === void 0 ? void 0 : sliderBrand.map(brand => {
        var _filterBrandImages, _filterBrandImages$im;

        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
            item: brand,
            variant: "rounded" // size="medium"
            ,
            href: {
              pathname: _lib_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.SEARCH */ .Z.SEARCH,
              query: {
                brand: brand.slug
              }
            },
            image: (_filterBrandImages = (0,_lib_filter_brands__WEBPACK_IMPORTED_MODULE_13__/* .filterBrandImages */ .z)(brand === null || brand === void 0 ? void 0 : brand.images, "slider-layout")) === null || _filterBrandImages === void 0 ? void 0 : (_filterBrandImages$im = _filterBrandImages.image) === null || _filterBrandImages$im === void 0 ? void 0 : _filterBrandImages$im[0]
          })
        }, `brand--key${brand.id}`);
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BrandBlock);

/***/ })

};
;