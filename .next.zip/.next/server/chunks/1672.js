"use strict";
exports.id = 1672;
exports.ids = [1672];
exports.modules = {

/***/ 5188:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_search_block)
});

// UNUSED EXPORTS: ProductSearchBlock

// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
;// CONCATENATED MODULE: ./src/lib/format-price-range.ts
/**
 * Helper method to format price range as , seperated
 *
 * @param price
 */
const formatPriceRange = price => {
  // Replace - to ,
  let replaceChar = price.replaceAll("-", ",");
  const priceArr = replaceChar.split(",");
  let arrLen = priceArr.length,
      min = Infinity,
      max = -Infinity;

  while (arrLen--) {
    // If price has over 1000+
    if (priceArr[arrLen] === "1000+") {
      return ['1000'];
    } // Calculate the minimum


    if (priceArr[arrLen].trim() !== '' && Number(priceArr[arrLen]) < min) {
      min = Number(priceArr[arrLen]);
    } // Calculate the maximum


    if (priceArr[arrLen].trim() !== '' && Number(priceArr[arrLen]) > max) {
      max = Number(priceArr[arrLen]);
    }
  }

  return [min.toString(), max.toString()];
};
// EXTERNAL MODULE: ./src/components/common/drawer/drawer.tsx
var drawer = __webpack_require__(5536);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/icons/filter-icon.tsx



const FilterIcon = ({
  color = "currentColor",
  width = "18px",
  height = "14px"
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18 14",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("g", {
      id: "Group_36196",
      "data-name": "Group 36196",
      transform: "translate(-925 -1122.489)",
      children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
        id: "Path_22590",
        "data-name": "Path 22590",
        d: "M942.581,1295.564H925.419c-.231,0-.419-.336-.419-.75s.187-.75.419-.75h17.163c.231,0,.419.336.419.75S942.813,1295.564,942.581,1295.564Z",
        transform: "translate(0 -169.575)",
        fill: color
      }), /*#__PURE__*/jsx_runtime_.jsx("path", {
        id: "Path_22591",
        "data-name": "Path 22591",
        d: "M942.581,1951.5H925.419c-.231,0-.419-.336-.419-.75s.187-.75.419-.75h17.163c.231,0,.419.336.419.75S942.813,1951.5,942.581,1951.5Z",
        transform: "translate(0 -816.512)",
        fill: color
      }), /*#__PURE__*/jsx_runtime_.jsx("path", {
        id: "Path_22593",
        "data-name": "Path 22593",
        d: "M1163.713,1122.489a2.5,2.5,0,1,0,1.768.732A2.483,2.483,0,0,0,1163.713,1122.489Z",
        transform: "translate(-233.213)",
        fill: color
      }), /*#__PURE__*/jsx_runtime_.jsx("path", {
        id: "Path_22594",
        "data-name": "Path 22594",
        d: "M2344.886,1779.157a2.5,2.5,0,1,0,.731,1.768A2.488,2.488,0,0,0,2344.886,1779.157Z",
        transform: "translate(-1405.617 -646.936)",
        fill: color
      })]
    })
  });
};

/* harmony default export */ const filter_icon = (FilterIcon);
// EXTERNAL MODULE: ./src/components/ui/text.tsx
var ui_text = __webpack_require__(4068);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: ./src/components/shop/filters.tsx + 8 modules
var filters = __webpack_require__(5959);
// EXTERNAL MODULE: ./src/components/common/scrollbar.tsx
var scrollbar = __webpack_require__(7654);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoArrowBack"
var IoArrowBack_ = __webpack_require__(5256);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoArrowForward"
var IoArrowForward_ = __webpack_require__(2713);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/utils/get-direction.ts
var get_direction = __webpack_require__(1727);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./src/components/shop/filter-sidebar.tsx












const FilterSidebar = ({
  searchResultCount
}) => {
  const {
    closeFilter
  } = (0,ui_context/* useUI */.l8)();
  const router = (0,router_.useRouter)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const dir = (0,get_direction/* getDirection */.M)(router.locale);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-col justify-between w-full h-full",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full border-b border-gray-100 flex justify-between items-center relative ltr:pr-5 rtl:pl-5 ltr:md:pr-7 rtl:md:pl-7 flex-shrink-0 py-0.5",
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "flex text-2xl items-center justify-center text-gray-500 px-4 md:px-5 py-6 lg:py-8 focus:outline-none transition-opacity hover:opacity-60",
        onClick: closeFilter,
        "aria-label": "close",
        children: dir === "rtl" ? /*#__PURE__*/jsx_runtime_.jsx(IoArrowForward_.IoArrowForward, {
          className: "text-black"
        }) : /*#__PURE__*/jsx_runtime_.jsx(IoArrowBack_.IoArrowBack, {
          className: "text-black"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "font-bold text-xl md:text-2xl m-0 text-heading w-full text-center ltr:pr-6 ltr:pl-6",
        children: t("text-filters")
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(scrollbar/* default */.Z, {
      className: "menu-scrollbar flex-grow mb-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex flex-col py-7 px-5 md:px-7 text-heading",
        children: /*#__PURE__*/jsx_runtime_.jsx(filters/* ShopFilters */.M, {})
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "text-sm md:text-base leading-4 flex items-center justify-center px-7 flex-shrink-0 h-14 bg-heading text-white",
      children: [searchResultCount !== null && searchResultCount !== void 0 ? searchResultCount : 0, " ", t("text-items")]
    })]
  });
};

/* harmony default export */ const filter_sidebar = (FilterSidebar);
// EXTERNAL MODULE: external "@headlessui/react"
var react_ = __webpack_require__(4025);
// EXTERNAL MODULE: external "@react-icons/all-files/hi/HiOutlineSelector"
var HiOutlineSelector_ = __webpack_require__(6201);
// EXTERNAL MODULE: external "@react-icons/all-files/hi/HiCheck"
var HiCheck_ = __webpack_require__(488);
;// CONCATENATED MODULE: ./src/components/ui/list-box.tsx
const _excluded = ["orderBy", "sortedBy"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }










function ListBox({
  options
}) {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const router = (0,router_.useRouter)();
  const {
    pathname,
    query
  } = router;
  const currentSelectedItem = query !== null && query !== void 0 && query.orderBy && query !== null && query !== void 0 && query.sortedBy ? options.find(o => o.value === `${query.orderBy}|${query.sortedBy}`) : options[0];
  const {
    0: selectedItem,
    1: setSelectedItem
  } = (0,external_react_.useState)(currentSelectedItem);
  (0,external_react_.useEffect)(() => {
    setSelectedItem(currentSelectedItem);
  }, [query === null || query === void 0 ? void 0 : query.orderBy, query === null || query === void 0 ? void 0 : query.sortedBy]);

  function handleItemClick(values) {
    setSelectedItem(values);

    const {
      orderBy,
      sortedBy
    } = query,
          restQuery = _objectWithoutProperties(query, _excluded);

    const splitValues = values.value.split("|");
    router.push({
      pathname,
      query: _objectSpread(_objectSpread({}, restQuery), values.value !== options[0].value ? {
        orderBy: splitValues[0],
        sortedBy: splitValues[1]
      } : {})
    }, undefined, {
      scroll: false
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(react_.Listbox, {
    value: selectedItem,
    onChange: handleItemClick,
    children: ({
      open
    }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "relative ltr:ml-2 rtl:mr-2 ltr:lg:ml-0 rtl:lg:mr-0 z-10 min-w-[180px]",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(react_.Listbox.Button, {
        className: "border border-gray-300  text-heading text-[13px] md:text-sm font-semibold  relative w-full py-2 ltr:pl-3 rtl:pr-3 ltr:pr-10 rtl:pl-10 ltr:text-left rtl:text-right bg-white rounded-lg shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-opacity-75 focus-visible:ring-white focus-visible:ring-offset-orange-300 focus-visible:ring-offset-2 focus-visible:border-indigo-500 sm:text-sm cursor-pointer",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "block truncate",
          children: t(selectedItem.name)
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "absolute inset-y-0 ltr:right-0 rtl:left-0 flex items-center ltr:pr-2 rtl:pl-2 pointer-events-none",
          children: /*#__PURE__*/jsx_runtime_.jsx(HiOutlineSelector_.HiOutlineSelector, {
            className: "w-5 h-5 text-gray-400",
            "aria-hidden": "true"
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(react_.Transition, {
        show: open,
        as: external_react_.Fragment,
        leave: "transition ease-in duration-100",
        leaveFrom: "opacity-100",
        leaveTo: "opacity-0",
        children: /*#__PURE__*/jsx_runtime_.jsx(react_.Listbox.Options, {
          static: true,
          className: "absolute w-full py-1 mt-1 overflow-auto bg-white rounded-md shadow-lg max-h-60 ring-1 ring-black ring-opacity-5 focus:outline-none text-sm",
          children: options === null || options === void 0 ? void 0 : options.map((option, personIdx) => /*#__PURE__*/jsx_runtime_.jsx(react_.Listbox.Option, {
            className: ({
              active
            }) => `${active ? "text-amber-900 bg-gray-100" : "text-gray-900"}
                          cursor-pointer select-none relative py-2 ltr:pl-10 rtl:pr-10 ltr:pr-4 rtl:pl-4`,
            value: option,
            children: ({
              selected,
              active
            }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                className: `${selected ? "font-medium" : "font-normal"} block truncate`,
                children: t(option.name)
              }), selected && /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: `${active && "text-amber-600"}
                                check-icon absolute inset-y-0 ltr:left-0 rtl:right-0 flex items-center ltr:pl-3 rtl:pr-3`,
                children: /*#__PURE__*/jsx_runtime_.jsx(HiCheck_.HiCheck, {
                  className: "w-5 h-5",
                  "aria-hidden": "true"
                })
              })]
            })
          }, personIdx))
        })
      })]
    })
  });
}
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
;// CONCATENATED MODULE: ./src/components/shop/top-bar.tsx














const SearchTopBar = ({
  searchResultCount
}) => {
  const {
    query
  } = (0,router_.useRouter)();
  const {
    openFilter,
    displayFilter,
    closeFilter
  } = (0,ui_context/* useUI */.l8)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    locale
  } = (0,router_.useRouter)();
  const dir = (0,get_direction/* getDirection */.M)(locale);
  const contentWrapperCSS = dir === "ltr" ? {
    left: 0
  } : {
    right: 0
  };
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex justify-between items-center mb-7",
    children: [/*#__PURE__*/jsx_runtime_.jsx(ui_text/* default */.Z, {
      variant: "pageHeading",
      className: "hidden lg:inline-flex pb-1",
      children: isEmpty_default()(query) ? t("text-shop") : t("text-search-result")
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
      className: "lg:hidden text-heading text-sm px-4 py-2 font-semibold border border-gray-300 rounded-md flex items-center transition duration-200 ease-in-out focus:outline-none hover:bg-gray-200",
      onClick: openFilter,
      children: [/*#__PURE__*/jsx_runtime_.jsx(filter_icon, {}), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "ltr:pl-2.5 rtl:pr-2.5",
        children: t("text-filters")
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex items-center justify-end",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex-shrink-0 text-body text-xs md:text-sm leading-4 ltr:pr-4 rtl:pl-4 ltr:md:mr-6 rtl:md:ml-6 ltr:pl-2 rtl:pr-2 hidden lg:block",
        children: [searchResultCount !== null && searchResultCount !== void 0 ? searchResultCount : 0, " ", t("text-items")]
      }), /*#__PURE__*/jsx_runtime_.jsx(ListBox, {
        options: [{
          name: "text-sorting-options",
          value: "options"
        }, {
          name: "text-oldest",
          value: "created_at|ASC"
        }, {
          name: "text-popularity",
          value: "orders_count|DESC"
        }, {
          name: "text-price-low-high",
          value: "min_price|ASC"
        }, {
          name: "text-price-high-low",
          value: "max_price|DESC"
        }]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(drawer/* Drawer */.d, {
      placement: dir === "rtl" ? "right" : "left",
      open: displayFilter,
      onClose: closeFilter,
      handler: false,
      showMask: true,
      level: null,
      contentWrapperStyle: contentWrapperCSS,
      children: /*#__PURE__*/jsx_runtime_.jsx(filter_sidebar, {
        searchResultCount: searchResultCount !== null && searchResultCount !== void 0 ? searchResultCount : 0
      })
    })]
  });
};

/* harmony default export */ const top_bar = (SearchTopBar);
// EXTERNAL MODULE: ./src/components/product/product-infinite-grid.tsx
var product_infinite_grid = __webpack_require__(5944);
;// CONCATENATED MODULE: ./src/components/product/product-search-block.tsx
function product_search_block_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function product_search_block_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { product_search_block_ownKeys(Object(source), true).forEach(function (key) { product_search_block_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { product_search_block_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function product_search_block_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









const ProductSearchBlock = ({
  className = ""
}) => {
  var _data$pages, _data$pages$, _data$pages$$paginato;

  const {
    query
  } = (0,router_.useRouter)();
  const priceRange = query.price && formatPriceRange(query.price);
  const {
    isLoading,
    isFetchingNextPage: loadingMore,
    fetchNextPage,
    hasNextPage,
    data,
    error
  } = (0,products_query/* useProductsInfiniteQuery */.Ue)(product_search_block_objectSpread(product_search_block_objectSpread({
    text: query.q && query.q,
    category: query.category && query.category,
    type: query.brand && query.brand,
    orderBy: query.orderBy && query.orderBy,
    sortedBy: query.sortedBy && query.sortedBy,
    variations: query.variations && query.variations,
    tags: query.tags && query.tags
  }, priceRange && priceRange.length === 2 && {
    min_price: priceRange.join(",")
  }), priceRange && priceRange.length === 1 && {
    max_price: priceRange[0]
  }));
  if (error) return /*#__PURE__*/jsx_runtime_.jsx("p", {
    children: error.message
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(top_bar, {
      searchResultCount: data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : (_data$pages$ = _data$pages[0]) === null || _data$pages$ === void 0 ? void 0 : (_data$pages$$paginato = _data$pages$.paginatorInfo) === null || _data$pages$$paginato === void 0 ? void 0 : _data$pages$$paginato.total
    }), /*#__PURE__*/jsx_runtime_.jsx(product_infinite_grid/* default */.Z, {
      className: className,
      loading: isLoading,
      data: data,
      hasNextPage: hasNextPage,
      loadingMore: loadingMore,
      fetchNextPage: fetchNextPage
    })]
  });
};
/* harmony default export */ const product_search_block = (ProductSearchBlock);

/***/ }),

/***/ 5959:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "M": () => (/* binding */ ShopFilters)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/checkbox.tsx
const _excluded = ["labelKey", "label"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const CheckBox = /*#__PURE__*/external_react_default().forwardRef((_ref, ref) => {
  let {
    labelKey,
    label
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
    className: "group flex items-center text-heading text-sm cursor-pointer",
    children: [/*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
      type: "checkbox",
      className: "form-checkbox w-5 h-5 border border-gray-300 rounded cursor-pointer transition duration-500 ease-in-out focus:ring-offset-0 text-heading hover:border-heading focus:outline-none focus:ring-0 focus-visible:outline-none checked:bg-heading",
      ref: ref
    }, rest)), /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "ltr:ml-4 rtl:mr-4 -mt-0.5",
      children: labelKey ? t(labelKey) : label
    })]
  });
});
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
// EXTERNAL MODULE: ./src/framework/rest/category/categories.query.ts
var categories_query = __webpack_require__(4362);
;// CONCATENATED MODULE: ./src/components/shop/category-filter.tsx
const category_filter_excluded = ["category"];

function category_filter_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function category_filter_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { category_filter_ownKeys(Object(source), true).forEach(function (key) { category_filter_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { category_filter_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function category_filter_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function category_filter_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = category_filter_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function category_filter_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const CategoryFilter = () => {
  var _data$pages;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const router = (0,router_.useRouter)();
  const {
    pathname,
    query
  } = router;
  const {
    data,
    isLoading,
    hasNextPage,
    isFetchingNextPage: loadingMore,
    fetchNextPage
  } = (0,categories_query/* useCategoriesInfiniteQuery */.PP)({
    limit: 5,
    parent: null
  });
  const selectedCategories = query !== null && query !== void 0 && query.category ? query.category.split(",") : [];
  const [formState, setFormState] = external_react_default().useState(selectedCategories);
  external_react_default().useEffect(() => {
    setFormState(selectedCategories);
  }, [query === null || query === void 0 ? void 0 : query.category]);

  function handleItemClick(e) {
    const {
      value
    } = e.currentTarget;
    let currentFormState = formState.includes(value) ? formState.filter(i => i !== value) : [...formState, value];

    const {
      category
    } = query,
          restQuery = category_filter_objectWithoutProperties(query, category_filter_excluded);

    router.push({
      pathname,
      query: category_filter_objectSpread(category_filter_objectSpread({}, restQuery), !!currentFormState.length ? {
        category: currentFormState.join(",")
      } : {})
    }, undefined, {
      scroll: false
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "block border-b border-gray-300 pb-7 mb-7",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
      className: "text-heading text-sm md:text-base font-semibold mb-7",
      children: t("text-category")
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "mt-2 flex flex-col space-y-4",
      children: [!isLoading && (data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : _data$pages.map(page => {
        return page === null || page === void 0 ? void 0 : page.data.map(category => /*#__PURE__*/jsx_runtime_.jsx(CheckBox, {
          label: category.name,
          name: category.name.toLowerCase(),
          checked: formState.includes(category.slug),
          value: category.slug,
          onChange: handleItemClick
        }, category.id));
      })), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "w-full",
        children: hasNextPage && /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
          variant: "custom",
          disabled: loadingMore,
          onClick: () => fetchNextPage(),
          className: "text-sm text-heading ltr:pl-9 rtl:pr-9 pt-1",
          children: t("button-load-more")
        })
      })]
    })]
  });
};
// EXTERNAL MODULE: ./src/framework/rest/brand/brands.query.tsx
var brands_query = __webpack_require__(4412);
;// CONCATENATED MODULE: ./src/components/shop/brand-filter.tsx
const brand_filter_excluded = ["brand"];

function brand_filter_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function brand_filter_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { brand_filter_ownKeys(Object(source), true).forEach(function (key) { brand_filter_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { brand_filter_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function brand_filter_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function brand_filter_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = brand_filter_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function brand_filter_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









const BrandFilter = () => {
  var _data$pages;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const router = (0,router_.useRouter)();
  const {
    pathname,
    query
  } = router;
  const {
    data,
    isLoading,
    hasNextPage,
    isFetchingNextPage: loadingMore,
    fetchNextPage
  } = (0,brands_query/* useBrandsInfiniteQuery */.Yn)({
    limit: 5
  });
  const selectedBrands = query !== null && query !== void 0 && query.brand ? query.brand.split(",") : [];
  const [formState, setFormState] = external_react_default().useState(selectedBrands);
  external_react_default().useEffect(() => {
    setFormState(selectedBrands);
  }, [query === null || query === void 0 ? void 0 : query.brand]);

  function handleItemClick(e) {
    const {
      value
    } = e.currentTarget;
    let currentFormState = formState.includes(value) ? formState.filter(i => i !== value) : [...formState, value]; // setFormState(currentFormState);

    const {
      brand
    } = query,
          restQuery = brand_filter_objectWithoutProperties(query, brand_filter_excluded);

    router.push({
      pathname,
      query: brand_filter_objectSpread(brand_filter_objectSpread({}, restQuery), !!currentFormState.length ? {
        brand: currentFormState.join(",")
      } : {})
    }, undefined, {
      scroll: false
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "block border-b border-gray-300 pb-7 mb-7",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
      className: "text-heading text-sm md:text-base font-semibold mb-7",
      children: t("text-brands")
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "mt-2 flex flex-col space-y-4",
      children: [!isLoading && (data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : _data$pages.map(page => {
        return page === null || page === void 0 ? void 0 : page.data.map(brand => /*#__PURE__*/jsx_runtime_.jsx(CheckBox, {
          label: brand === null || brand === void 0 ? void 0 : brand.name,
          name: brand === null || brand === void 0 ? void 0 : brand.name.toLowerCase(),
          checked: formState === null || formState === void 0 ? void 0 : formState.includes(brand.slug),
          value: brand === null || brand === void 0 ? void 0 : brand.slug,
          onChange: handleItemClick
        }, brand === null || brand === void 0 ? void 0 : brand.id));
      })), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "w-full",
        children: hasNextPage && /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
          variant: "custom",
          disabled: loadingMore,
          onClick: () => fetchNextPage(),
          className: "text-sm text-heading ltr:pl-9 rtl:pr-9 pt-1",
          children: t("button-load-more")
        })
      })]
    })]
  });
};
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoClose"
var IoClose_ = __webpack_require__(491);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
;// CONCATENATED MODULE: ./src/components/shop/filtered-item.tsx
function filtered_item_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function filtered_item_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { filtered_item_ownKeys(Object(source), true).forEach(function (key) { filtered_item_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { filtered_item_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function filtered_item_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const FilteredItem = ({
  itemKey,
  itemValue
}) => {
  const router = (0,router_.useRouter)();
  const {
    pathname,
    query
  } = router;

  function handleClose() {
    const currentItem = query[itemKey].split(",").filter(i => i !== itemValue);
    delete query[itemKey];
    router.push({
      pathname,
      query: filtered_item_objectSpread(filtered_item_objectSpread({}, query), !isEmpty_default()(currentItem) ? {
        [itemKey]: currentItem.join(",")
      } : {})
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "group flex flex-shrink-0 m-1.5 items-center border border-gray-300 bg-borderBottom rounded-lg text-xs px-3.5 py-2.5 capitalize text-heading cursor-pointer transition duration-200 ease-in-out hover:border-heading",
    onClick: handleClose,
    children: [itemValue, /*#__PURE__*/jsx_runtime_.jsx(IoClose_.IoClose, {
      className: "text-sm text-body ltr:ml-2 rtl:mr-2 flex-shrink-0 ltr:-mr-0.5 rtl:-ml-0.5 mt-0.5 transition duration-200 ease-in-out group-hover:text-heading"
    })]
  });
};
;// CONCATENATED MODULE: ./src/components/shop/price-filter.tsx
const price_filter_excluded = ["price"];

function price_filter_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function price_filter_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { price_filter_ownKeys(Object(source), true).forEach(function (key) { price_filter_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { price_filter_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function price_filter_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function price_filter_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = price_filter_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function price_filter_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







const priceFilterItems = [{
  id: "1",
  name: "Under $50",
  slug: "0-50"
}, {
  id: "2",
  name: "$50 to $100",
  slug: "50-100"
}, {
  id: "3",
  name: "$100 to $150",
  slug: "100-150"
}, {
  id: "4",
  name: "$150 to $200",
  slug: "150-200"
}, {
  id: "5",
  name: "$200 to $300",
  slug: "200-300"
}, {
  id: "6",
  name: "$300 to $500",
  slug: "300-500"
}, {
  id: "7",
  name: "$500 to $1000",
  slug: "500-1000"
}, {
  id: "8",
  name: "Over $1000",
  slug: "1000+"
}];
const PriceFilter = () => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const router = (0,router_.useRouter)();
  const {
    pathname,
    query
  } = router;
  const selectedPrices = query !== null && query !== void 0 && query.price ? query.price.split(",") : [];
  const [formState, setFormState] = external_react_default().useState(selectedPrices);
  external_react_default().useEffect(() => {
    setFormState(selectedPrices);
  }, [query === null || query === void 0 ? void 0 : query.price]);

  function handleItemClick(e) {
    const {
      value
    } = e.currentTarget;
    let currentFormState = formState.includes(value) ? formState.filter(i => i !== value) : [...formState, value]; // setFormState(currentFormState);

    const {
      price
    } = query,
          restQuery = price_filter_objectWithoutProperties(query, price_filter_excluded);

    router.push({
      pathname,
      query: price_filter_objectSpread(price_filter_objectSpread({}, restQuery), !!currentFormState.length ? {
        price: currentFormState.join(",")
      } : {})
    }, undefined, {
      scroll: false
    });
  }

  const items = priceFilterItems;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "block border-b border-gray-300 pb-7 mb-7",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
      className: "text-heading text-sm md:text-base font-semibold mb-7",
      children: t("text-price")
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mt-2 flex flex-col space-y-4",
      children: items === null || items === void 0 ? void 0 : items.map(item => /*#__PURE__*/jsx_runtime_.jsx(CheckBox, {
        label: item.name,
        name: item.name.toLowerCase(),
        checked: formState.includes(item.slug),
        value: item.slug,
        onChange: handleItemClick
      }, item.id))
    })]
  });
};
// EXTERNAL MODULE: ./src/framework/rest/attributes/attributes.query.ts
var attributes_query = __webpack_require__(4533);
;// CONCATENATED MODULE: ./src/components/shop/color-filter.tsx
const color_filter_excluded = ["variations"];

function color_filter_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function color_filter_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { color_filter_ownKeys(Object(source), true).forEach(function (key) { color_filter_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { color_filter_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function color_filter_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function color_filter_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = color_filter_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function color_filter_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







const ColorFilter = ({
  attribute
}) => {
  var _attribute$values;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const router = (0,router_.useRouter)();
  const {
    pathname,
    query
  } = router;
  const selectedColors = query !== null && query !== void 0 && query.variations ? query.variations.split(",") : [];
  const [formState, setFormState] = external_react_default().useState(selectedColors);
  external_react_default().useEffect(() => {
    setFormState(selectedColors);
  }, [query === null || query === void 0 ? void 0 : query.variations]);

  function handleItemClick(e) {
    const {
      value
    } = e.currentTarget;
    let currentFormState = formState.includes(value) ? formState.filter(i => i !== value) : [...formState, value]; // setFormState(currentFormState);

    const {
      variations
    } = query,
          restQuery = color_filter_objectWithoutProperties(query, color_filter_excluded);

    router.push({
      pathname,
      query: color_filter_objectSpread(color_filter_objectSpread({}, restQuery), !!currentFormState.length ? {
        variations: currentFormState.join(",")
      } : {})
    }, undefined, {
      scroll: false
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "block border-b border-gray-300 pb-7 mb-7",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
      className: "text-heading text-sm md:text-base font-semibold mb-7",
      children: t("text-colors")
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mt-2 flex flex-col space-y-4",
      children: (_attribute$values = attribute.values) === null || _attribute$values === void 0 ? void 0 : _attribute$values.map(item => {
        var _item$meta;

        return /*#__PURE__*/jsx_runtime_.jsx(CheckBox, {
          label: /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: "flex items-center",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: `w-5 h-5 rounded-full block ltr:mr-3 rtl:ml-3 mt-0.5 border border-black border-opacity-20`,
              style: {
                backgroundColor: (_item$meta = item.meta) !== null && _item$meta !== void 0 ? _item$meta : item.value
              }
            }), item.value]
          }),
          name: item.value.toLowerCase(),
          checked: formState.includes(item.value),
          value: item.value,
          onChange: handleItemClick
        }, item.id);
      })
    })]
  });
};
;// CONCATENATED MODULE: ./src/components/shop/variation-filter.tsx
const variation_filter_excluded = ["variations"];

function variation_filter_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function variation_filter_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { variation_filter_ownKeys(Object(source), true).forEach(function (key) { variation_filter_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { variation_filter_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function variation_filter_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function variation_filter_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = variation_filter_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function variation_filter_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






const VariationFilter = ({
  attribute
}) => {
  var _attribute$values;

  const router = (0,router_.useRouter)();
  const {
    pathname,
    query
  } = router;
  const selectedAttribute = query !== null && query !== void 0 && query.variations ? query.variations.split(",") : [];
  const [formState, setFormState] = external_react_default().useState(selectedAttribute);
  external_react_default().useEffect(() => {
    setFormState(selectedAttribute);
  }, [query === null || query === void 0 ? void 0 : query.variations]);

  function handleItemClick(e) {
    const {
      value
    } = e.currentTarget;
    let currentFormState = formState.includes(value) ? formState.filter(i => i !== value) : [...formState, value]; // setFormState(currentFormState);

    const {
      variations
    } = query,
          restQuery = variation_filter_objectWithoutProperties(query, variation_filter_excluded);

    router.push({
      pathname,
      query: variation_filter_objectSpread(variation_filter_objectSpread({}, restQuery), !!currentFormState.length ? {
        variations: currentFormState.join(",")
      } : {})
    }, undefined, {
      scroll: false
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "block border-b border-gray-300 pb-7 mb-7",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
      className: "text-heading text-sm md:text-base font-semibold mb-7",
      children: attribute.name
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mt-2 flex flex-col space-y-4",
      children: (_attribute$values = attribute.values) === null || _attribute$values === void 0 ? void 0 : _attribute$values.map(item => /*#__PURE__*/jsx_runtime_.jsx(CheckBox, {
        label: item.value,
        name: item.value.toLowerCase(),
        checked: formState.includes(item.value),
        value: item.value,
        onChange: handleItemClick
      }, item.id))
    })]
  });
};
;// CONCATENATED MODULE: ./src/components/shop/attributes-filter.tsx





const AttributesFilter = ({
  attributes
}) => /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
  children: attributes.map(attribute => attribute.slug === 'color' ? /*#__PURE__*/jsx_runtime_.jsx(ColorFilter, {
    attribute: attribute
  }, attribute.id) : /*#__PURE__*/jsx_runtime_.jsx(VariationFilter, {
    attribute: attribute
  }, attribute.id))
});
;// CONCATENATED MODULE: ./src/components/shop/filters.tsx











const ShopFilters = () => {
  const router = (0,router_.useRouter)();
  const {
    pathname,
    query
  } = router;
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    data
  } = (0,attributes_query/* useAttributesQuery */.O)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "pt-1",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "block border-b border-gray-300 pb-7 mb-7",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between mb-2.5",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "font-semibold text-heading text-xl md:text-2xl",
          children: t("text-filters")
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "flex-shrink text-xs mt-0.5 transition duration-150 ease-in focus:outline-none hover:text-heading",
          "aria-label": "Clear All",
          onClick: () => {
            router.push(pathname);
          },
          children: t("text-clear-all")
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex flex-wrap -m-1.5 pt-2",
        children: !isEmpty_default()(query) && Object.values(query).join(",").split(",").map((v, idx) => /*#__PURE__*/jsx_runtime_.jsx(FilteredItem, {
          itemKey: Object.keys(query).find(k => {
            var _query$k;

            return (_query$k = query[k]) === null || _query$k === void 0 ? void 0 : _query$k.includes(v);
          }),
          itemValue: v
        }, idx))
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(CategoryFilter, {}), /*#__PURE__*/jsx_runtime_.jsx(BrandFilter, {}), /*#__PURE__*/jsx_runtime_.jsx(PriceFilter, {}), data && /*#__PURE__*/jsx_runtime_.jsx(AttributesFilter, {
      attributes: data.attributes
    })]
  });
};

/***/ }),

/***/ 4533:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ fetchAttributes),
/* harmony export */   "O": () => (/* binding */ useAttributesQuery)
/* harmony export */ });
/* harmony import */ var _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3036);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);



const AttributesService = new _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__/* .CoreApi */ .z(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.ATTRIBUTES */ .P.ATTRIBUTES);
const fetchAttributes = async () => {
  const {
    data
  } = await AttributesService.findAll();
  return {
    attributes: data
  };
};
const useAttributesQuery = () => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.ATTRIBUTES */ .P.ATTRIBUTES, fetchAttributes);
};

/***/ }),

/***/ 4443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var _framework_settings_settings_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659);
/* harmony import */ var _framework_category_categories_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4362);
/* harmony import */ var _framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4412);
/* harmony import */ var _framework_products_products_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2317);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(874);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3295);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9475);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_query_hydration__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _framework_attributes_attributes_query__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4533);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










const getStaticProps = async ({
  locale
}) => {
  const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_6__.QueryClient({
    defaultOptions: {
      queries: {
        staleTime: Infinity
      }
    }
  });

  try {
    await Promise.all([await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.SETTINGS */ .P.SETTINGS, _framework_settings_settings_query__WEBPACK_IMPORTED_MODULE_0__/* .fetchSettings */ .w), await queryClient.prefetchInfiniteQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS, {}], _framework_products_products_query__WEBPACK_IMPORTED_MODULE_3__/* .fetchInfiniteProducts */ .GU), await queryClient.prefetchInfiniteQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.CATEGORIES */ .P.CATEGORIES, {
      limit: 5,
      parent: null
    }], _framework_category_categories_query__WEBPACK_IMPORTED_MODULE_1__/* .fetchInfiniteCategories */ .PS), await queryClient.prefetchInfiniteQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.TYPE */ .P.TYPE, {
      limit: 5
    }], _framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_2__/* .fetchInfiniteBrands */ .dv), await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.ATTRIBUTES */ .P.ATTRIBUTES, _framework_attributes_attributes_query__WEBPACK_IMPORTED_MODULE_8__/* .fetchAttributes */ .A)]);
    return {
      props: _objectSpread(_objectSpread({}, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_5__.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
        dehydratedState: JSON.parse(JSON.stringify((0,react_query_hydration__WEBPACK_IMPORTED_MODULE_7__.dehydrate)(queryClient)))
      }),
      revalidate: Number(process.env.REVALIDATE_DURATION) || 120
    };
  } catch (error) {
    // If we get here means something went wrong in promise fetching
    return {
      notFound: true
    };
  }
};

/***/ })

};
;