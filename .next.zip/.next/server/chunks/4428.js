"use strict";
exports.id = 4428;
exports.ids = [4428];
exports.modules = {

/***/ 4428:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ MobileMenu)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1420);
/* harmony import */ var _components_common_scrollbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7654);
/* harmony import */ var _react_icons_all_files_io_IoIosArrowDown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4603);
/* harmony import */ var _react_icons_all_files_io_IoIosArrowDown__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_react_icons_all_files_io_IoIosArrowDown__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4386);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4580);
/* harmony import */ var _react_icons_all_files_io5_IoClose__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(491);
/* harmony import */ var _react_icons_all_files_io5_IoClose__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_react_icons_all_files_io5_IoClose__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _contexts_settings_context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3792);
/* harmony import */ var _lib_get_icon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8473);
/* harmony import */ var _components_icons_social_icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7855);
/* harmony import */ var _data_static_menus__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9038);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);















function MobileMenu() {
  var _settings$contactDeta;

  const {
    0: activeMenus,
    1: setActiveMenus
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const settings = (0,_contexts_settings_context__WEBPACK_IMPORTED_MODULE_8__/* .useSettings */ .rV)();
  const socials = settings === null || settings === void 0 ? void 0 : (_settings$contactDeta = settings.contactDetails) === null || _settings$contactDeta === void 0 ? void 0 : _settings$contactDeta.socials;
  const {
    closeSidebar
  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_5__/* .useUI */ .l8)();
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)("menu");

  const handleArrowClick = menuName => {
    let newActiveMenus = [...activeMenus];

    if (newActiveMenus.includes(menuName)) {
      let index = newActiveMenus.indexOf(menuName);

      if (index > -1) {
        newActiveMenus.splice(index, 1);
      }
    } else {
      newActiveMenus.push(menuName);
    }

    setActiveMenus(newActiveMenus);
  };

  const ListMenu = ({
    dept,
    data,
    hasSubMenu,
    menuName,
    menuIndex,
    className = ""
  }) => data.label && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("li", {
    className: `mb-0.5 ${className}`,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
      className: "flex items-center justify-between",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_ui_link__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
        href: data.path,
        className: "w-full text-[15px] menu-item relative py-3 ltr:pl-5 ltr:md:pl-7 rtl:pr-5 rtl:md:pr-7 ltr:pr-4 rtl:pl-4 transition duration-300 ease-in-out",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("span", {
          className: "block w-full",
          onClick: closeSidebar,
          children: t(`${data.label}`)
        })
      }), hasSubMenu && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("div", {
        className: "cursor-pointer w-16 md:w-20 h-8 text-lg flex-shrink-0 flex items-center justify-center",
        onClick: () => handleArrowClick(menuName),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_react_icons_all_files_io_IoIosArrowDown__WEBPACK_IMPORTED_MODULE_3__.IoIosArrowDown, {
          className: `transition duration-200 ease-in-out transform text-heading ${activeMenus.includes(menuName) ? "-rotate-180" : "rotate-0"}`
        })
      })]
    }), hasSubMenu && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(SubMenu, {
      dept: dept,
      data: data.subMenu,
      toggle: activeMenus.includes(menuName),
      menuIndex: menuIndex
    })]
  });

  const SubMenu = ({
    dept,
    data,
    toggle,
    menuIndex
  }) => {
    if (!toggle) {
      return null;
    }

    dept = dept + 1;
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("ul", {
      className: "pt-0.5",
      children: data === null || data === void 0 ? void 0 : data.map((menu, index) => {
        const menuName = `sidebar-submenu-${dept}-${menuIndex}-${index}`;
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(ListMenu, {
          dept: dept,
          data: menu,
          hasSubMenu: menu.subMenu,
          menuName: menuName,
          menuIndex: index,
          className: dept > 1 && "ltr:pl-4 rtl:pr-4"
        }, menuName);
      })
    });
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
      className: "flex flex-col justify-between w-full h-full",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
        className: "w-full border-b border-gray-100 flex justify-between items-center relative ltr:pl-5 ltr:md:pl-7 rtl:pr-5 rtl:md:pr-7 flex-shrink-0 py-0.5",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("button", {
          className: "flex text-2xl items-center justify-center text-gray-500 px-4 md:px-5 py-6 lg:py-8 focus:outline-none transition-opacity hover:opacity-60",
          onClick: closeSidebar,
          "aria-label": "close",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_react_icons_all_files_io5_IoClose__WEBPACK_IMPORTED_MODULE_6__.IoClose, {
            className: "text-black mt-1 md:mt-0.5"
          })
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_scrollbar__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
        className: "menu-scrollbar flex-grow mb-auto",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("div", {
          className: "flex flex-col py-7 px-0 lg:px-2 text-heading",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("ul", {
            className: "mobileMenu",
            children: _data_static_menus__WEBPACK_IMPORTED_MODULE_11__/* .mobileMenu */ .e === null || _data_static_menus__WEBPACK_IMPORTED_MODULE_11__/* .mobileMenu */ .e === void 0 ? void 0 : _data_static_menus__WEBPACK_IMPORTED_MODULE_11__/* .mobileMenu.map */ .e.map((menu, index) => {
              const dept = 1;
              const menuName = `sidebar-menu-${dept}-${index}`;
              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(ListMenu, {
                dept: dept,
                data: menu,
                hasSubMenu: menu.subMenu,
                menuName: menuName,
                menuIndex: index
              }, menuName);
            })
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("div", {
        className: "flex items-center justify-center bg-white border-t border-gray-100 px-7 flex-shrink-0 space-x-1 rtl:space-x-reverse",
        children: socials === null || socials === void 0 ? void 0 : socials.map((social, index) => {
          var _social$url;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("a", {
            href: (_social$url = social === null || social === void 0 ? void 0 : social.url) !== null && _social$url !== void 0 ? _social$url : "#!",
            className: `text-heading p-5 opacity-60 ltr:first:-ml-4 rtl:first:-mr-4 transition duration-300 ease-in hover:opacity-100`,
            target: "_blank",
            rel: "noreferrer",
            children: (0,_lib_get_icon__WEBPACK_IMPORTED_MODULE_9__/* .getIcon */ .q)({
              iconList: _components_icons_social_icon__WEBPACK_IMPORTED_MODULE_10__/* .default */ .ZP,
              iconName: social === null || social === void 0 ? void 0 : social.icon
            })
          }, index);
        })
      })]
    })
  });
}

/***/ })

};
;