"use strict";
exports.id = 6244;
exports.ids = [6244];
exports.modules = {

/***/ 6244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5038);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4365);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1103);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2156);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);






const breakpoints = {
  "1720": {
    slidesPerView: 3,
    spaceBetween: 12
  },
  "1366": {
    slidesPerView: 3,
    spaceBetween: 12
  },
  "1025": {
    slidesPerView: 3
  },
  "768": {
    slidesPerView: 2
  },
  "0": {
    slidesPerView: 1
  }
};

const HeroSlider = ({
  className = "mb-12 md:mb-14 xl:mb-[60px]",
  variant = "box",
  variantRounded = "rounded",
  data,
  paginationPosition = "center",
  buttonClassName = "hidden",
  buttonPosition = "outside"
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("relative mb-5 md:mb-8", {
      "mx-auto max-w-[1920px]": variant === "fullWidth"
    }, className),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      autoplay: {
        delay: 5000
      },
      className: `mx-0 ${variant === "fullWidth" ? "carousel-full-width" : ""} pagination-${paginationPosition}`,
      buttonClassName: classnames__WEBPACK_IMPORTED_MODULE_4___default()(buttonClassName),
      pagination: {
        clickable: true
      },
      scrollbar: {
        draggable: true,
        hide: false
      },
      buttonPosition: buttonPosition,
      breakpoints: variant === "fashion" ? breakpoints : {},
      children: data === null || data === void 0 ? void 0 : data.map(banner => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
        className: "carouselItem",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
          data: banner,
          href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_2__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${banner.slug}`,
          variant: variantRounded
        })
      }, `banner--key-${banner === null || banner === void 0 ? void 0 : banner.id}`))
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroSlider);

/***/ })

};
;