"use strict";
exports.id = 9230;
exports.ids = [9230];
exports.modules = {

/***/ 9230:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_product_product_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(135);
/* harmony import */ var _framework_products_popular_products_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8208);
/* harmony import */ var _components_ui_loaders_product_list_feed_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9471);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7125);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5013);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const ProductsTopBlock = ({
  sectionHeading,
  className = "mb-12 md:mb-14 xl:mb-16",
  limit = 6
}) => {
  const {
    data,
    isLoading,
    error
  } = (0,_framework_products_popular_products_query__WEBPACK_IMPORTED_MODULE_1__/* .usePopularProductsQuery */ .T)({
    limit: limit
  });
  console.log(data);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: `${className}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
      sectionHeading: sectionHeading
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 md:gap-5 xl:gap-7 xl:-mt-1.5 2xl:mt-0",
      children: error ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        className: "col-span-full",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
          message: error === null || error === void 0 ? void 0 : error.message
        })
      }) : isLoading && !(data !== null && data !== void 0 && data.length) ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_loaders_product_list_feed_loader__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
        limit: limit
      }) : data === null || data === void 0 ? void 0 : data.map(product => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_product_product_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
        product: product,
        imgWidth: 265,
        imgHeight: 265,
        imageContentClassName: "flex-shrink-0 w-32 sm:w-44 md:w-40 lg:w-52 2xl:w-56 3xl:w-64",
        contactClassName: "ltr:pl-3.5 ltr:sm:pl-5 ltr:md:pl-4 ltr:xl:pl-5 ltr:2xl:pl-6 ltr:3xl:pl-10 rtl:pr-3.5 rtl:sm:pr-5 rtl:md:pr-4 rtl:xl:pr-5 rtl:2xl:pr-6 rtl:3xl:pr-10"
      }, `product--key-${product.id}`))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsTopBlock);

/***/ }),

/***/ 8208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ usePopularProductsQuery),
/* harmony export */   "R": () => (/* binding */ fetchPopularProducts)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var _framework_utils_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8549);




const fetchPopularProducts = async ({
  queryKey
}) => {
  const [_key, params] = queryKey;
  const {
    limit = 10
  } = params;
  const url = `${_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.POPULAR_PRODUCTS */ .P.POPULAR_PRODUCTS}?&limit=${limit}`;
  const {
    data
  } = await _framework_utils_request__WEBPACK_IMPORTED_MODULE_2__/* .default.get */ .Z.get(url);
  return data;
};

const usePopularProductsQuery = options => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.POPULAR_PRODUCTS */ .P.POPULAR_PRODUCTS, options], fetchPopularProducts);
};



/***/ })

};
;