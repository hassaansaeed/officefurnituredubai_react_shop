"use strict";
exports.id = 2983;
exports.ids = [2983];
exports.modules = {

/***/ 1654:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ counter)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/icons/minus-icon.tsx


const MinusIcon = ({
  color = "currentColor",
  width = "10px",
  height = "2px"
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 1.5",
    children: /*#__PURE__*/jsx_runtime_.jsx("rect", {
      "data-name": "Rectangle 970",
      width: width,
      height: height,
      fill: color
    })
  });
};

/* harmony default export */ const minus_icon = (MinusIcon);
;// CONCATENATED MODULE: ./src/components/icons/counter-plus-icon.tsx

const CounterPlusIcon = ({
  color = "currentColor",
  width = "10px",
  height = "10px"
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", {
    "data-name": "plus (2)",
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 12 12",
    children: /*#__PURE__*/jsx_runtime_.jsx("g", {
      "data-name": "Group 5367",
      children: /*#__PURE__*/jsx_runtime_.jsx("path", {
        "data-name": "Path 17138",
        d: "M6.749,5.251V0h-1.5V5.251H0v1.5H5.251V12h1.5V6.749H12v-1.5Z",
        fill: color
      })
    })
  });
};
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./src/components/common/counter.tsx






const Counter = ({
  quantity,
  onDecrement,
  onIncrement,
  disableIncrement = false,
  disableDecrement = false,
  variant = "default"
}) => {
  const size = variant !== "dark" ? "12px" : "10px";
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: external_classnames_default()("group flex items-center justify-between rounded-md overflow-hidden flex-shrink-0", {
      "border h-11 md:h-12 border-gray-300": variant === "default",
      "h-8 md:h-9 shadow-navigation bg-heading": variant === "dark"
    }),
    children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
      onClick: onDecrement,
      className: external_classnames_default()("flex items-center justify-center flex-shrink-0 h-full transition ease-in-out duration-300 focus:outline-none", {
        "w-10 md:w-12 text-heading ltr:border-r rtl:border-l border-gray-300 hover:text-white hover:bg-heading": variant === "default",
        "w-8 md:w-9 text-white bg-heading hover:bg-gray-600 focus:outline-none": variant === "dark"
      }),
      disabled: disableDecrement,
      children: /*#__PURE__*/jsx_runtime_.jsx(minus_icon, {
        width: size
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: external_classnames_default()("font-semibold flex items-center justify-center h-full  transition-colors duration-250 ease-in-out cursor-default flex-shrink-0", {
        "text-base text-heading w-12  md:w-20 xl:w-24": variant === "default",
        "text-sm text-white w-8 md:w-10 ": variant === "dark"
      }),
      children: quantity
    }), /*#__PURE__*/jsx_runtime_.jsx("button", {
      onClick: onIncrement,
      className: external_classnames_default()("flex items-center justify-center h-full flex-shrink-0 transition ease-in-out duration-300 focus:outline-none", {
        "w-10 md:w-12 text-heading ltr:border-l rtl:border-r border-gray-300 hover:text-white hover:bg-heading": variant === "default",
        "w-8 md:w-9 text-white bg-heading hover:bg-gray-600 focus:outline-none": variant === "dark"
      }),
      disabled: disableIncrement,
      children: /*#__PURE__*/jsx_runtime_.jsx(CounterPlusIcon, {
        width: size,
        height: size
      })
    })]
  });
};

/* harmony default export */ const counter = (Counter);

/***/ }),

/***/ 659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ fetchSettings),
/* harmony export */   "n": () => (/* binding */ useSettingsQuery)
/* harmony export */ });
/* harmony import */ var _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3036);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);



const SettingsService = new _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__/* .CoreApi */ .z(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.SETTINGS */ .P.SETTINGS);
const fetchSettings = async () => {
  const {
    data
  } = await SettingsService.findAll();
  return {
    settings: data
  };
};
const useSettingsQuery = () => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.SETTINGS */ .P.SETTINGS, fetchSettings);
};

/***/ })

};
;