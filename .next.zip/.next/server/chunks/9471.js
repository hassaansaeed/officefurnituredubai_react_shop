"use strict";
exports.id = 9471;
exports.ids = [9471];
exports.modules = {

/***/ 9471:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_list_feed_loader)
});

// EXTERNAL MODULE: external "react-content-loader"
var external_react_content_loader_ = __webpack_require__(9081);
var external_react_content_loader_default = /*#__PURE__*/__webpack_require__.n(external_react_content_loader_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/loaders/product-list-card-loader.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ProductListCardLoader = props => /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_content_loader_default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 644,
  height: 256,
  viewBox: "0 0 644 256",
  backgroundColor: "#f9f9f9",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "296",
    y: "120",
    rx: "3",
    ry: "3",
    width: "280",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "296",
    y: "160",
    rx: "3",
    ry: "3",
    width: "80",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "296",
    y: "88",
    rx: "3",
    ry: "3",
    width: "180",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "256",
    height: "256"
  })]
}));

/* harmony default export */ const product_list_card_loader = (ProductListCardLoader);
;// CONCATENATED MODULE: ./src/components/ui/loaders/product-list-feed-loader.tsx




const ProductListFeedLoader = ({
  limit = 4
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: Array.from({
      length: limit
    }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(product_list_card_loader, {
      uniqueKey: `product-top-${idx}`
    }, idx))
  });
};

/* harmony default export */ const product_list_feed_loader = (ProductListFeedLoader);

/***/ })

};
;