"use strict";
exports.id = 9742;
exports.ids = [9742];
exports.modules = {

/***/ 9742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "rc": () => (/* reexport */ category_banner),
  "Hb": () => (/* reexport */ product),
  "Y4": () => (/* reexport */ product_placeholder_thumbnail)
});

// UNUSED EXPORTS: avatarPlaceholder, couponPlaceholder, logoPlaceholder

;// CONCATENATED MODULE: ./src/assets/placeholders/product.svg
/* harmony default export */ const product = ({"src":"/_next/static/image/src/assets/placeholders/product.b93f2cf45b80b3ffdfcdcbe72b038fd4.svg","height":210,"width":270});
;// CONCATENATED MODULE: ./src/assets/placeholders/coupon.svg
/* harmony default export */ const coupon = ({"src":"/_next/static/image/src/assets/placeholders/coupon.1d69ebf4508d9803c322897b9802928a.svg","height":240,"width":320});
;// CONCATENATED MODULE: ./src/assets/placeholders/avatar.svg
/* harmony default export */ const avatar = ({"src":"/_next/static/image/src/assets/placeholders/avatar.2a4ed68cad8ebe21317b04e155b6b245.svg","height":120,"width":120});
;// CONCATENATED MODULE: ./src/assets/placeholders/logo.svg
/* harmony default export */ const logo = ({"src":"/_next/static/image/src/assets/placeholders/logo.f7653fd47c1ec8f573559e524693e385.svg","height":18,"width":109});
;// CONCATENATED MODULE: ./src/assets/placeholders/product-placeholder-thumbnail.svg
/* harmony default export */ const product_placeholder_thumbnail = ({"src":"/_next/static/image/src/assets/placeholders/product-placeholder-thumbnail.482307d9869de7de5fc44e55f0cf6420.svg","height":42,"width":42});
;// CONCATENATED MODULE: ./src/assets/placeholders/category-banner.png
/* harmony default export */ const category_banner = ({"src":"/_next/static/image/src/assets/placeholders/category-banner.5de83040f7c85b96e5ef3d58bf1c4d8a.png","height":270,"width":1800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAMAAADU3h9xAAAAA1BMVEX49/Nj5MtuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAC0lEQVQImWNggAIAAAkAAeNZIR4AAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./src/lib/placeholders.tsx







/***/ })

};
;