"use strict";
exports.id = 1298;
exports.ids = [1298];
exports.modules = {

/***/ 1298:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5038);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4365);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2156);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1103);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);





const breakpoints = {
  "1025": {
    slidesPerView: 3,
    spaceBetween: 28
  },
  "480": {
    slidesPerView: 2,
    spaceBetween: 20
  },
  "0": {
    slidesPerView: 1,
    spaceBetween: 12
  }
};

const BannerCarouselBlock = ({
  className = "mb-12 md:mb-12 lg:mb-14 pb-0.5 xl:pb-1.5",
  banners
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    className: className,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      breakpoints: breakpoints,
      autoplay: {
        delay: 5000
      },
      children: banners === null || banners === void 0 ? void 0 : banners.map(banner => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
          data: banner,
          href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_3__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${banner.slug}`,
          effectActive: true
        })
      }, `promotion-banner-key-${banner === null || banner === void 0 ? void 0 : banner.id}`))
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerCarouselBlock);

/***/ })

};
;