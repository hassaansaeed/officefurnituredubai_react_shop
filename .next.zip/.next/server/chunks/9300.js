"use strict";
exports.id = 9300;
exports.ids = [9300];
exports.modules = {

/***/ 9300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ OTP)
/* harmony export */ });
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7993);
/* harmony import */ var _framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6838);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_phone_input_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5183);
/* harmony import */ var react_phone_input_2__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_phone_input_2__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5013);
/* harmony import */ var react_otp_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2512);
/* harmony import */ var react_otp_input__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_otp_input__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_ui_label__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2357);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4580);
/* harmony import */ var _utils_get_direction__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1727);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _framework_auth_use_user__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5986);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9440);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2166);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__);
// import Button from "@components/ui/button";
// import {
//   useSendOtpCodeMutation,
//   useVerifyOtpCodeMutation,
// } from "@framework/auth/auth.query";
// import { useState } from "react";
// import PhoneInput from "react-phone-input-2";
// import Alert from "@components/ui/alert";
// import MobileOtpInput from "react-otp-input";
// import Label from "@components/ui/label";
// import { useTranslation } from "next-i18next";
// import "react-phone-input-2/lib/bootstrap.css";
// import { getDirection } from "@utils/get-direction";
// import { useRouter } from "next/router";
// interface OTPProps {
//   defaultValue: string | undefined;
//   onVerify: (phoneNumber: string) => void;
// }
// export const OTP: React.FC<OTPProps> = ({ defaultValue, onVerify }) => {
//   const { t } = useTranslation("common");
//   const [errorMessage, setErrorMessage] = useState<string | null>(null);
//   const [number, setNumber] = useState(defaultValue ?? "");
//   const [otp, setOtp] = useState("");
//   const [hasOTP, setHasOTP] = useState(false);
//   const [otpId, setOtpId] = useState("");
//   const router = useRouter();
// 	const dir = getDirection(router.locale);
//   const { mutate: verifyOtpCode, isLoading: otpVerifyLoading } =
//     useVerifyOtpCodeMutation();
//   const { mutate: sendOtpCode, isLoading: loading } = useSendOtpCodeMutation();
//   function onSendCodeSubmission() {
//     sendOtpCode(
//       {
//         phone_number: number,
//       },
//       {
//         onSuccess: (data: any) => {
//           if (data?.success) {
//             setErrorMessage(null);
//             setHasOTP(true);
//             setOtpId(data?.sendOtpCode?.id!);
//           }
//           if (!data?.success) {
//             console.log("text-otp-failed");
//             setErrorMessage(data?.message);
//           }
//         },
//         onError: (error: any) => {
//           setErrorMessage(error?.response?.data?.message);
//         },
//       }
//     );
//   }
//   function onVerifyCodeSubmission() {
//     verifyOtpCode(
//       {
//         phone_number: number,
//         code: otp,
//         otp_id: otpId,
//       },
//       {
//         onSuccess: (data) => {
//           if (data?.success) {
//             setErrorMessage(null);
//             onVerify(number);
//           } else {
//             setErrorMessage(data?.message);
//           }
//           setHasOTP(false);
//         },
//         onError: (error: any) => {
//           setErrorMessage(error?.response?.data?.message);
//         },
//       }
//     );
//   }
//   return (
//     <>
//       {!hasOTP ? (
//         <div className={`flex items-center ${dir === 'rtl' ? 'rtl-view': 'ltr-view'}`}>
//           <PhoneInput
//             country={"us"}
//             value={number}
//             onChange={(phone) => setNumber(`+${phone}`)}
//             inputClass="!p-0 ltr:!pr-4 rtl:!pl-4 ltr:!pl-14 rtl:!pr-14 !flex !items-center !w-full !appearance-none !transition !duration-300 !ease-in-out !text-heading !text-sm focus:!outline-none focus:!ring-0 !border !border-gray-300 ltr:!border-r-0 rtl:!border-l-0 !rounded ltr:rounded-r-none rtl:rounded-l-none focus:!border-black !h-12"
//             dropdownClass="focus:!ring-0 !border !border-gray-300 !shadow-350"
//           />
//           <Button
//             loading={loading}
//             disabled={loading}
//             onClick={onSendCodeSubmission}
//             className="ltr:rounded-l-none rtl:rounded-r-none flex-shrink-0 capitalize !h-12 !px-6"
//           >
//             {t("text-send-otp")}
//           </Button>
//         </div>
//       ) : (
//         <div className="w-full flex flex-col md:flex-row md:items-center md:space-x-5">
//           <Label className="md:mb-0">{t("text-otp-code")}</Label>
//           <MobileOtpInput
//             value={otp}
//             onChange={(value: string) => setOtp(value)}
//             numInputs={6}
//             separator={
//               <span className="hidden sm:inline-block sm:mx-2">-</span>
//             }
//             containerStyle="justify-center space-x-2 sm:space-x-0 mb-5 md:mb-0"
//             inputStyle="flex items-center justify-center !w-full sm:!w-11 appearance-none transition duration-300 ease-in-out text-heading text-sm focus:outline-none focus:ring-0 border border-gray-100 rounded focus:border-heading h-12"
//             disabledStyle="!bg-gray-100"
//           />
//           <Button
//             loading={otpVerifyLoading}
//             disabled={otpVerifyLoading}
//             onClick={onVerifyCodeSubmission}
//           >
//             {t("text-verify-code")}
//           </Button>
//         </div>
//       )}
//       {errorMessage && (
//         <Alert
//           variant="error"
//           message={t(errorMessage)}
//           className="mt-4"
//           closeable={true}
//           onClose={() => setErrorMessage(null)}
//         />
//       )}
//     </>
//   );
// };




















const PhoneInputSchema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
  phone_number: yup__WEBPACK_IMPORTED_MODULE_13__.string().required("forms:error-phone-required").min(12, "forms:error-min-phone")
});
const OTP = ({
  defaultValue,
  onVerify
}) => {
  var _errors$phone_number;

  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)("common");
  const {
    me
  } = (0,_framework_auth_use_user__WEBPACK_IMPORTED_MODULE_11__/* .default */ .ZP)();
  const isUser = !!me;
  const {
    0: errorMessage,
    1: setErrorMessage
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
  const {
    0: number,
    1: setNumber
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(defaultValue !== null && defaultValue !== void 0 ? defaultValue : "");
  const {
    0: phoneNumber,
    1: setPhoneNumber
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
  const {
    0: otp,
    1: setOtp
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
  const {
    0: hasOTP,
    1: setHasOTP
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const {
    0: otpId,
    1: setOtpId
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
  const {
    setModalView,
    openModal,
    closeModal
  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_8__/* .useUI */ .l8)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
  const dir = (0,_utils_get_direction__WEBPACK_IMPORTED_MODULE_16__/* .getDirection */ .M)(router.locale); // const { mutate: verifyOtpCode, isLoading: otpVerifyLoading } =
  //   useVerifyOtpCodeMutation();

  const {
    mutate: twoFactor,
    isLoading: otpLoginLoading
  } = (0,_framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_1__/* .useTwoFactorMutation */ .yt)();
  const {
    mutate: contactSendOtpCode,
    isLoading: loading
  } = (0,_framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_1__/* .useContactSendOtpCodeMutation */ .bL)();
  const {
    register,
    handleSubmit,
    control,
    setValue,
    formState: {
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_12__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_14__.yupResolver)(PhoneInputSchema),
    shouldUnregister: true,
    defaultValues: {
      phone_number: number
    }
  });

  function onSendCodeSubmission(values) {
    setPhoneNumber(`+${values.phone_number}`);
    contactSendOtpCode({
      phone_number: `+${values.phone_number}`,
      user_id: localStorage.getItem("user_id")
    }, {
      onSuccess: data => {
        if (data.status) {
          var _data$sendOtpCode;

          setErrorMessage(null);
          setHasOTP(true);
          setOtpId(data === null || data === void 0 ? void 0 : (_data$sendOtpCode = data.sendOtpCode) === null || _data$sendOtpCode === void 0 ? void 0 : _data$sendOtpCode.id); // setModalView("TWO_FACTOR");
        } else {
          console.log("text-otp-failed");
          setErrorMessage(data === null || data === void 0 ? void 0 : data.message);
        }
      },
      onError: error => {
        var _error$response, _error$response$data;

        setErrorMessage(error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : (_error$response$data = _error$response.data) === null || _error$response$data === void 0 ? void 0 : _error$response$data.message);
      }
    });
  }

  function onVerifyCodeSubmission() {
    twoFactor({
      phone_number: phoneNumber,
      code: otp,
      otp_id: otpId,
      user_id: localStorage.getItem("user_id")
    }, {
      onSuccess: data => {
        console.log("sttaus", data === null || data === void 0 ? void 0 : data.status);

        if ((data === null || data === void 0 ? void 0 : data.status) === 1) {
          setErrorMessage(null);
          onVerify(number);
        } else if ((data === null || data === void 0 ? void 0 : data.status) === 0) {
          setErrorMessage(data === null || data === void 0 ? void 0 : data.message);
        } else {
          react_toastify__WEBPACK_IMPORTED_MODULE_10__.toast.success(data === null || data === void 0 ? void 0 : data.message);
          closeModal();
        }
      },
      onError: error => {
        var _error$response2, _error$response2$data;

        setErrorMessage(error === null || error === void 0 ? void 0 : (_error$response2 = error.response) === null || _error$response2 === void 0 ? void 0 : (_error$response2$data = _error$response2.data) === null || _error$response2$data === void 0 ? void 0 : _error$response2$data.message);
      }
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.Fragment, {
    children: [!hasOTP ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("form", {
      onSubmit: handleSubmit(onSendCodeSubmission),
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("div", {
        className: `flex items-center ${dir === "rtl" ? "rtl-view" : "ltr-view"}`,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_12__.Controller, {
          control: control,
          render: ({
            field: {
              onChange,
              onBlur: _,
              value
            },
            fieldState: {
              error
            }
          }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.Fragment, {
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((react_phone_input_2__WEBPACK_IMPORTED_MODULE_3___default()), {
              country: "pk",
              value: value,
              onChange: onChange,
              inputClass: "!p-0 ltr:!pr-4 rtl:!pl-4 ltr:!pl-14 rtl:!pr-14 !flex !items-center !w-full !appearance-none !transition !duration-300 !ease-in-out !text-heading !text-sm focus:!outline-none focus:!ring-0 !border !border-gray-300 ltr:!border-r-0 rtl:!border-l-0 !rounded ltr:rounded-r-none rtl:rounded-l-none focus:!border-black !h-12",
              dropdownClass: "focus:!ring-0 !border !border-gray-300 !shadow-350"
            })
          }),
          name: "phone_number"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
          loading: loading,
          disabled: loading // onClick={onSendCodeSubmission}
          ,
          className: "ltr:rounded-l-none rtl:rounded-r-none flex-shrink-0 capitalize !h-12 !px-6",
          children: t("text-send-otp")
        })]
      }), errors && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("p", {
        className: "my-2 text-xs text-danger",
        children: t(errors === null || errors === void 0 ? void 0 : (_errors$phone_number = errors.phone_number) === null || _errors$phone_number === void 0 ? void 0 : _errors$phone_number.message)
      })]
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("div", {
      className: "w-full flex flex-col md:flex-row md:items-center md:space-x-5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
        className: "md:mb-0",
        children: t("text-otp-code")
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((react_otp_input__WEBPACK_IMPORTED_MODULE_5___default()), {
        value: otp,
        onChange: value => setOtp(value),
        numInputs: 4,
        separator: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("span", {
          className: "hidden sm:inline-block sm:mx-2",
          children: "-"
        }),
        containerStyle: "justify-center space-x-2 sm:space-x-0 mb-5 md:mb-0",
        inputStyle: "flex items-center justify-center !w-full sm:!w-11 appearance-none transition duration-300 ease-in-out text-heading text-sm focus:outline-none focus:ring-0 border border-gray-100 rounded focus:border-heading h-12",
        disabledStyle: "!bg-gray-100"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
        loading: otpLoginLoading,
        disabled: otpLoginLoading,
        onClick: onVerifyCodeSubmission,
        children: t("text-verify-code")
      })]
    }), errorMessage && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
      variant: "error",
      message: t(errorMessage),
      className: "mt-4",
      closeable: true,
      onClose: () => setErrorMessage(null)
    })]
  });
};

/***/ })

};
;