"use strict";
exports.id = 2599;
exports.ids = [2599];
exports.modules = {

/***/ 2599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ otp_login)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/components/ui/logo.tsx
var logo = __webpack_require__(4386);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(6155);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);
// EXTERNAL MODULE: ./src/lib/constants.ts
var constants = __webpack_require__(509);
// EXTERNAL MODULE: external "jotai"
var external_jotai_ = __webpack_require__(8250);
// EXTERNAL MODULE: ./src/store/authorization-atom.ts
var authorization_atom = __webpack_require__(8879);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
// EXTERNAL MODULE: ./src/framework/rest/auth/auth.query.ts + 1 modules
var auth_query = __webpack_require__(6838);
// EXTERNAL MODULE: external "react-phone-input-2"
var external_react_phone_input_2_ = __webpack_require__(5183);
var external_react_phone_input_2_default = /*#__PURE__*/__webpack_require__.n(external_react_phone_input_2_);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: external "react-otp-input"
var external_react_otp_input_ = __webpack_require__(2512);
var external_react_otp_input_default = /*#__PURE__*/__webpack_require__.n(external_react_otp_input_);
// EXTERNAL MODULE: ./src/components/ui/label.tsx
var label = __webpack_require__(2357);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(9440);
// EXTERNAL MODULE: external "@hookform/resolvers/yup"
var yup_ = __webpack_require__(2166);
// EXTERNAL MODULE: external "react-hook-form"
var external_react_hook_form_ = __webpack_require__(2662);
// EXTERNAL MODULE: ./src/components/ui/input.tsx
var input = __webpack_require__(4271);
// EXTERNAL MODULE: ./src/utils/get-direction.ts
var get_direction = __webpack_require__(1727);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/auth/otp/otp-login-form.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




















const defaultValues = {
  name: "",
  email: "",
  code: ""
};
const otpLoginFormSchema = external_yup_.object().shape({
  email: external_yup_.string().email("forms:error-email-format").when("isContactExist", {
    is: false,
    then: external_yup_.string().required("forms:error-email-required")
  }),
  name: external_yup_.string().when("isContactExist", {
    is: false,
    then: external_yup_.string().required("forms:error-name-required")
  }),
  code: external_yup_.string().required("forms:error-code-required").min(6, "forms:error-min-code")
});
const OTPLoginForm = ({
  onLoginSuccess
}) => {
  var _errors$name, _errors$email;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    0: errorMessage,
    1: setErrorMessage
  } = (0,external_react_.useState)(null);
  const {
    0: hasOTP,
    1: setHasOTP
  } = (0,external_react_.useState)(false);
  const {
    0: otpId,
    1: setOtpId
  } = (0,external_react_.useState)("");
  const {
    0: number,
    1: setNumber
  } = (0,external_react_.useState)("");
  const {
    0: isContactExist,
    1: setIsContactExist
  } = (0,external_react_.useState)(false);
  const {
    mutate: sendOtpCode,
    isLoading: loading
  } = (0,auth_query/* useSendOtpCodeMutation */.MZ)();
  const {
    mutate: otpLogin,
    isLoading: otpLoginLoading
  } = (0,auth_query/* useOtpLoginMutation */._0)();
  const router = (0,router_.useRouter)();
  const dir = (0,get_direction/* getDirection */.M)(router.locale);
  const {
    register,
    handleSubmit,
    control,
    setValue,
    formState: {
      errors
    }
  } = (0,external_react_hook_form_.useForm)({
    defaultValues: _objectSpread(_objectSpread({}, defaultValues), {}, {
      isContactExist
    }),
    resolver: (0,yup_.yupResolver)(otpLoginFormSchema),
    shouldUnregister: true
  });

  function onSendCodeSubmission() {
    sendOtpCode({
      phone_number: number
    }, {
      onSuccess: data => {
        if (data !== null && data !== void 0 && data.success) {
          var _data$sendOtpCode;

          setErrorMessage(null);
          setIsContactExist(data === null || data === void 0 ? void 0 : data.is_contact_exist);
          setHasOTP(true);
          setOtpId(data === null || data === void 0 ? void 0 : (_data$sendOtpCode = data.sendOtpCode) === null || _data$sendOtpCode === void 0 ? void 0 : _data$sendOtpCode.id); // Update isContactExist value for update validation

          setValue("isContactExist", !!(data !== null && data !== void 0 && data.is_contact_exist));
        }

        if (!(data !== null && data !== void 0 && data.success)) {
          setErrorMessage(data === null || data === void 0 ? void 0 : data.message);
        }
      },
      onError: error => {
        var _error$response, _error$response$data;

        setErrorMessage(error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : (_error$response$data = _error$response.data) === null || _error$response$data === void 0 ? void 0 : _error$response$data.message);
      }
    });
  }

  function onOtpLoginSubmission(values) {
    otpLogin(_objectSpread(_objectSpread({}, values), {}, {
      phone_number: number,
      otp_id: otpId
    }), {
      onSuccess: data => {
        var _data$permissions;

        if (data !== null && data !== void 0 && data.token && data !== null && data !== void 0 && (_data$permissions = data.permissions) !== null && _data$permissions !== void 0 && _data$permissions.length) {
          onLoginSuccess(data === null || data === void 0 ? void 0 : data.token);
        }

        if (!(data !== null && data !== void 0 && data.token)) {
          setErrorMessage("text-otp-verify-failed");
        }
      },
      onError: error => {
        var _error$response2, _error$response2$data;

        console.log("Error", error);
        setErrorMessage(error === null || error === void 0 ? void 0 : (_error$response2 = error.response) === null || _error$response2 === void 0 ? void 0 : (_error$response2$data = _error$response2.data) === null || _error$response2$data === void 0 ? void 0 : _error$response2$data.message);
      }
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [errorMessage && /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
      variant: "error",
      message: t(errorMessage),
      className: "mb-4",
      closeable: true,
      onClose: () => setErrorMessage(null)
    }), !hasOTP ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `flex items-center ${dir === 'rtl' ? 'rtl-view' : 'ltr-view'}`,
      children: [/*#__PURE__*/jsx_runtime_.jsx((external_react_phone_input_2_default()), {
        country: "us",
        value: number,
        onChange: phone => setNumber(`+${phone}`),
        inputClass: "!p-0 ltr:!pr-4 rtl:!pl-4 ltr:!pl-14 rtl:!pr-14 !flex !items-center !w-full !appearance-none !transition !duration-300 !ease-in-out !text-heading !text-sm focus:!outline-none focus:!ring-0 !border !border-gray-300 ltr:!border-r-0 rtl:!border-l-0 !rounded ltr:!rounded-r-none rtl:!rounded-l-none focus:!border-black !h-12",
        dropdownClass: "focus:!ring-0 !border !border-gray-300 !shadow-350"
      }), /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
        loading: loading,
        disabled: loading,
        onClick: onSendCodeSubmission,
        className: "ltr:!rounded-l-none rtl:!rounded-r-none flex-shrink-0 capitalize !h-12 !px-6",
        children: t("text-send-otp")
      })]
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-full flex flex-col md:flex-row md:items-center md:space-x-5",
      children: /*#__PURE__*/jsx_runtime_.jsx("form", {
        onSubmit: handleSubmit(onOtpLoginSubmission),
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col space-y-4",
          children: [!isContactExist && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(input/* default */.Z, _objectSpread(_objectSpread({
              labelKey: "forms:label-name-star",
              type: "text",
              variant: "solid"
            }, register("name")), {}, {
              errorKey: (_errors$name = errors.name) === null || _errors$name === void 0 ? void 0 : _errors$name.message
            })), /*#__PURE__*/jsx_runtime_.jsx(input/* default */.Z, _objectSpread(_objectSpread({
              labelKey: "forms:label-email-star",
              type: "email",
              variant: "solid"
            }, register("email")), {}, {
              errorKey: (_errors$email = errors.email) === null || _errors$email === void 0 ? void 0 : _errors$email.message
            }))]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            children: [/*#__PURE__*/jsx_runtime_.jsx(label/* default */.Z, {
              children: t("text-otp-code")
            }), /*#__PURE__*/jsx_runtime_.jsx(external_react_hook_form_.Controller, {
              control: control,
              render: ({
                field: {
                  onChange,
                  onBlur: _,
                  value
                },
                fieldState: {
                  error
                }
              }) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [/*#__PURE__*/jsx_runtime_.jsx((external_react_otp_input_default()), {
                  value: value,
                  onChange: onChange,
                  numInputs: 6,
                  separator: /*#__PURE__*/jsx_runtime_.jsx("span", {
                    className: "hidden sm:inline-block sm:mx-2",
                    children: "-"
                  }),
                  containerStyle: "justify-center space-x-2 sm:space-x-0 mb-5 md:mb-0",
                  inputStyle: "flex items-center justify-center !w-full sm:!w-11 appearance-none transition duration-300 ease-in-out text-heading text-sm focus:outline-none focus:ring-0 border border-gray-100 rounded focus:border-heading h-12",
                  disabledStyle: "!bg-gray-100"
                }), error && /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "my-2 text-xs text-red-500",
                  children: t(error === null || error === void 0 ? void 0 : error.message)
                })]
              }),
              name: "code",
              defaultValue: ""
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "relative",
            children: /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
              type: "submit",
              loading: otpLoginLoading,
              disabled: otpLoginLoading,
              className: "h-11 md:h-12 w-full mt-1.5",
              children: t("common:text-login")
            })
          })]
        })
      })
    })]
  });
};
;// CONCATENATED MODULE: ./src/components/auth/otp/otp-login.tsx














const OtpLogin = ({
  layout = "modal"
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const router = (0,router_.useRouter)();
  const {
    setModalView,
    openModal,
    closeModal
  } = (0,ui_context/* useUI */.l8)();
  const [_, authorize] = (0,external_jotai_.useAtom)(authorization_atom/* authorizationAtom */.O);

  const onLoginSuccess = token => {
    if (token) {
      external_js_cookie_default().set(constants/* AUTH_TOKEN */.UA, token);
      authorize(true);

      if (layout === "modal") {
        closeModal();
        return;
      } else {
        return router.push(routes/* ROUTES.ACCOUNT */.Z.ACCOUNT);
      }
    }
  };

  const handleSignIn = () => {
    if (layout === "modal") {
      setModalView("LOGIN_VIEW");
      return openModal();
    } else {
      return router.push(routes/* ROUTES.LOGIN */.Z.LOGIN);
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "py-6 px-5 sm:p-8 bg-white mx-auto rounded-lg w-full sm:w-96 md:w-450px border border-gray-300",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "text-center mb-9 pt-2.5",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        onClick: closeModal,
        children: /*#__PURE__*/jsx_runtime_.jsx(logo/* default */.Z, {})
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-sm md:text-base text-body mt-3 sm:mt-4 mb-8 sm:mb-10",
        children: t("common:forgot-password-helper")
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(OTPLoginForm, {
      onLoginSuccess: onLoginSuccess
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col items-center justify-center relative text-sm text-heading mt-8 sm:mt-10 mb-6 sm:mb-7",
      children: [/*#__PURE__*/jsx_runtime_.jsx("hr", {
        className: "w-full border-gray-300"
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "absolute -top-2.5 px-2 bg-white",
        children: t("common:text-or")
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "text-sm sm:text-base text-body text-center",
      children: [t("common:text-back-to"), " ", /*#__PURE__*/jsx_runtime_.jsx("button", {
        type: "button",
        className: "text-sm sm:text-base text-heading underline font-bold hover:no-underline focus:outline-none",
        onClick: handleSignIn,
        children: t("common:text-login")
      })]
    })]
  });
};

/* harmony default export */ const otp_login = (OtpLogin);

/***/ })

};
;