"use strict";
exports.id = 4471;
exports.ids = [4471];
exports.modules = {

/***/ 2573:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ getLayout)
/* harmony export */ });
/* harmony import */ var _components_layout_header_header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1395);
/* harmony import */ var _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9308);
/* harmony import */ var _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6725);
/* harmony import */ var _components_common_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6203);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const SiteLayout = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: "flex flex-col min-h-screen",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_header_header__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      variant: "modern"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("main", {
      className: "relative flex-grow",
      style: {
        minHeight: "-webkit-fill-available",
        WebkitOverflowScrolling: "touch"
      },
      children: children
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {})]
  });
};

const getLayout = page => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(SiteLayout, {
  children: page
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SiteLayout)));

/***/ }),

/***/ 9667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ testimonial_carousel)
});

// EXTERNAL MODULE: ./src/components/ui/text.tsx
var ui_text = __webpack_require__(4068);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/icons/star-icon.tsx


const StarIcon = ({
  color = "#FFC107",
  width = "16.5px",
  height = "16px",
  className = ''
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 16.696 16",
    className: className,
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      id: "star",
      d: "M16.652,6.538a.886.886,0,0,0-.764-.61L11.07,5.49,9.164,1.03a.887.887,0,0,0-1.632,0L5.627,5.49l-4.82.438A.888.888,0,0,0,.3,7.48l3.642,3.194L2.872,15.406a.886.886,0,0,0,1.32.959L8.348,13.88,12.5,16.365a.887.887,0,0,0,1.32-.959L12.75,10.675l3.642-3.194a.888.888,0,0,0,.26-.943Zm0,0",
      transform: "translate(0 -0.491)",
      fill: color
    })
  });
};

/* harmony default export */ const star_icon = (StarIcon);
;// CONCATENATED MODULE: ./src/components/icons/quote-icon.tsx



const QuoteIcon = ({
  color = '#efefef',
  width = '24px',
  height = '18px',
  className = ''
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 24.194 18",
    className: className,
    children: /*#__PURE__*/jsx_runtime_.jsx("g", {
      "data-name": "Group 3264",
      transform: "translate(0 0)",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("g", {
        "data-name": "Group 3263",
        children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
          "data-name": "Path 3140",
          d: "M228.223,57.633l-.776-3.715c-5.589.267-9.463,2.687-9.463,9.806v8.194h9.764v-10.3h-3.7C224.05,59.335,225.427,57.992,228.223,57.633Z",
          transform: "translate(-204.029 -53.918)",
          fill: color
        }), /*#__PURE__*/jsx_runtime_.jsx("path", {
          "data-name": "Path 3141",
          d: "M10.239,57.633l-.776-3.715C3.874,54.185,0,56.605,0,63.724v8.194H9.764v-10.3h-3.7C6.064,59.335,7.441,57.992,10.239,57.633Z",
          transform: "translate(0 -53.918)",
          fill: color
        })]
      })
    })
  });
};

/* harmony default export */ const quote_icon = (QuoteIcon);
;// CONCATENATED MODULE: ./src/components/common/testimonial-card.tsx






const TestimonialCard = ({
  item
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "bg-gray-200 rounded-md p-6 md:p-8 lg:p-6 xl:p-8 transition duration-300 ease-in-out mx-auto md:mx-0",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-[90px]",
      children: /*#__PURE__*/jsx_runtime_.jsx("img", {
        src: item.avatar.src,
        alt: item.name,
        className: "rounded-full border-[5px] border-white shadow-avatar"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(ui_text/* default */.Z, {
      variant: "mediumHeading",
      className: "2xl:text-2xl mt-4 xl:mt-7",
      children: item.name
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "inline-grid grid-cols-5 gap-1.5 mt-3 lg:mt-5",
      children: [Array.from({
        length: item.rating
      }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(star_icon, {}, idx)), Array.from({
        length: 5 - item.rating
      }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(star_icon, {
        color: "#e6e6e6"
      }, idx))]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_text/* default */.Z, {
      className: "text-sm sm:leading-7 lg:text-base lg:leading-[1.625rem] mt-5 xl:mt-7",
      children: [/*#__PURE__*/jsx_runtime_.jsx(quote_icon, {
        className: "mb-3 xl:mb-4"
      }), item.text]
    })]
  });
};

/* harmony default export */ const testimonial_card = (TestimonialCard);
// EXTERNAL MODULE: ./src/components/common/section-header.tsx
var section_header = __webpack_require__(7125);
// EXTERNAL MODULE: ./src/components/ui/carousel/carousel.tsx
var carousel = __webpack_require__(4365);
;// CONCATENATED MODULE: ./src/data/static/testimonial.ts
const testimonials = [{
  id: 1,
  avatar: {
    src: '/assets/images/testimonials/1.png',
    width: 420,
    height: 420
  },
  rating: 4,
  name: 'Muffeez',
  text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.'
}, {
  id: 2,
  avatar: {
    src: '/assets/images/testimonials/1.png',
    width: 420,
    height: 420
  },
  rating: 3,
  name: 'Abbass',
  text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.'
}, {
  id: 3,
  avatar: {
    src: '/assets/images/testimonials/1.png',
    width: 420,
    height: 420
  },
  rating: 5,
  name: 'Muddasar',
  text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.'
}, {
  id: 4,
  avatar: {
    src: '/assets/images/testimonials/1.png',
    width: 420,
    height: 420
  },
  rating: 5,
  name: 'Chicatchi',
  text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.'
} //   {
//     id: 5,
//     avatar: {
//       src: '/assets/images/testimonials/5.jpg',
//       width: 420,
//       height: 420,
//     },
//     rating: 5,
//     name: 'Marvel Blu',
//     text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.',
//   },
//   {
//     id: 6,
//     avatar: {
//       src: '/assets/images/testimonials/2.jpg',
//       width: 420,
//       height: 420,
//     },
//     rating: 4,
//     name: 'Jiniya Snow',
//     text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex.',
//   },
];
// EXTERNAL MODULE: external "swiper/react"
var react_ = __webpack_require__(2156);
;// CONCATENATED MODULE: ./src/containers/testimonial-carousel.tsx







const breakpoints = {
  "1720": {
    slidesPerView: 4
  },
  "1366": {
    slidesPerView: 3
  },
  "1025": {
    slidesPerView: 3
  },
  "768": {
    slidesPerView: 2
  },
  "0": {
    slidesPerView: 1
  }
};

const TestimonialCarousel = ({
  sectionHeading,
  className = "mb-10 md:mb-12 xl:mb-14 md:pb-1 xl:pb-0"
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `heightFull ${className}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx(section_header/* default */.Z, {
      sectionHeading: sectionHeading
    }), /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
      autoplay: {
        delay: 4000
      },
      breakpoints: breakpoints,
      className: "testimonial-carousel",
      buttonClassName: "hidden",
      scrollbar: {
        draggable: true,
        hide: false
      },
      children: testimonials === null || testimonials === void 0 ? void 0 : testimonials.map(testimonial => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
        children: /*#__PURE__*/jsx_runtime_.jsx(testimonial_card, {
          item: testimonial
        })
      }, `testimonial--key-${testimonial.id}`))
    })]
  });
};

/* harmony default export */ const testimonial_carousel = (TestimonialCarousel);

/***/ })

};
;