"use strict";
exports.id = 2937;
exports.ids = [2937];
exports.modules = {

/***/ 1123:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5038);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4365);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2156);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1103);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);





const breakpoints = {
  "0": {
    slidesPerView: 2
  }
};

const BannerSliderBlock = ({
  className = "mb-12 md:mb-14 xl:mb-16",
  data
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    className: `${className} mx-auto max-w-[1920px] overflow-hidden`,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: "-mx-32 sm:-mx-44 lg:-mx-60 xl:-mx-72 2xl:-mx-80",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
        breakpoints: breakpoints,
        centeredSlides: true,
        pagination: {
          clickable: true
        },
        paginationVariant: "circle",
        buttonClassName: "hidden",
        children: data.map(banner => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
          className: "px-1.5 md:px-2.5 xl:px-3.5",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
            data: banner,
            effectActive: true,
            href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_3__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${banner.slug}`
          })
        }, `banner--key${banner.id}`))
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerSliderBlock);

/***/ }),

/***/ 6845:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5038);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7125);
/* harmony import */ var _components_product_product_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(135);
/* harmony import */ var _components_ui_loaders_product_card_small_list_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2813);
/* harmony import */ var _framework_products_products_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2317);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5013);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1103);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5278);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_404_not_found_item__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6857);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);














const BannerWithProducts = ({
  sectionHeading,
  categorySlug,
  variant = "default",
  className = "mb-12 md:mb-14 xl:mb-16",
  style = "default",
  limit = 9,
  data
}) => {
  var _siteSettings$homePag, _products$data$length, _products$data, _products$data2;

  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)();
  const onSellingSettings = _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings */ .U === null || _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings */ .U === void 0 ? void 0 : (_siteSettings$homePag = _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings.homePageBlocks */ .U.homePageBlocks) === null || _siteSettings$homePag === void 0 ? void 0 : _siteSettings$homePag.onSaleSettings;
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,_framework_products_products_query__WEBPACK_IMPORTED_MODULE_4__/* .useProductsQuery */ .kN)({
    limit,
    tags: onSellingSettings === null || onSellingSettings === void 0 ? void 0 : onSellingSettings.slug
  });

  if (!loading && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_9___default()(products === null || products === void 0 ? void 0 : products.data)) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_404_not_found_item__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
      text: t("text-no-on-selling-products-found")
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      sectionHeading: sectionHeading,
      categorySlug: categorySlug
    }), error ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)("div", {
      className: "grid grid-cols-4 gap-3 lg:gap-5 xl:gap-7",
      children: [variant === "reverse" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
        data: data[1],
        href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${data[1].slug}`,
        className: `hidden 3xl:block ${style === "modern" ? "3xl:col-span-2 3xl:row-span-2" : ""}`,
        effectActive: true,
        classNameInner: `${style === "modern" ? "h-auto" : ""}`
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
        data: data[0],
        href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${data[0].slug}`,
        className: `hidden 3xl:block ${style === "modern" ? "3xl:col-span-2 3xl:row-span-2" : ""}`,
        effectActive: true,
        classNameInner: `${style === "modern" ? "h-auto" : ""}`
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("div", {
        className: `col-span-full ${style === "modern" ? "xl:grid-cols-2 3xl:col-span-2" : "3xl:col-span-3 xl:grid-cols-3"} grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-5 xl:gap-7 ${variant === "reverse" ? "row-span-full" : ""}`,
        children: loading ? Array.from({
          length: (_products$data$length = products === null || products === void 0 ? void 0 : (_products$data = products.data) === null || _products$data === void 0 ? void 0 : _products$data.length) !== null && _products$data$length !== void 0 ? _products$data$length : 4
        }).map((_, idx) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_ui_loaders_product_card_small_list_loader__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
          uniqueKey: `on-selling-${idx}`
        }, idx)) : products === null || products === void 0 ? void 0 : (_products$data2 = products.data) === null || _products$data2 === void 0 ? void 0 : _products$data2.map(product => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_product_product_card__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
          product: product,
          imgWidth: 176,
          imgHeight: 176,
          variant: "listSmall"
        }, `product--key${product.id}`))
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerWithProducts);

/***/ })

};
;