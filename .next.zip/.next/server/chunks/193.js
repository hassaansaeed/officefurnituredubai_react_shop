"use strict";
exports.id = 193;
exports.ids = [193];
exports.modules = {

/***/ 5530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ subscription)
});

// EXTERNAL MODULE: ./src/components/ui/text.tsx
var ui_text = __webpack_require__(4068);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "react-mailchimp-subscribe"
var external_react_mailchimp_subscribe_ = __webpack_require__(182);
var external_react_mailchimp_subscribe_default = /*#__PURE__*/__webpack_require__.n(external_react_mailchimp_subscribe_);
// EXTERNAL MODULE: ./src/components/ui/input.tsx
var input = __webpack_require__(4271);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
// EXTERNAL MODULE: external "react-hook-form"
var external_react_hook_form_ = __webpack_require__(2662);
// EXTERNAL MODULE: external "@hookform/resolvers/yup"
var yup_ = __webpack_require__(2166);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(9440);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/common/mailchimp-form.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












const defaultValues = {
  subscribe_email: ""
}; // Yup validation

const subscriptionFormSchema = external_yup_.object().shape({
  subscribe_email: external_yup_.string().email("forms:email-error").required("forms:email-required")
});

const CustomForm = ({
  status,
  message,
  onValidated,
  layout
}) => {
  var _errors$subscribe_ema;

  const {
    register,
    handleSubmit,
    reset,
    formState: {
      errors
    }
  } = (0,external_react_hook_form_.useForm)({
    defaultValues,
    resolver: (0,yup_.yupResolver)(subscriptionFormSchema)
  });
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    closeModal
  } = (0,ui_context/* useUI */.l8)();
  const {
    0: responseMessage,
    1: setResponseMessage
  } = (0,external_react_.useState)("");
  (0,external_react_.useEffect)(() => {
    setResponseMessage(message); // Disappear message after 2 second

    const interval = setInterval(() => {
      setResponseMessage("");
    }, 3000);
    return () => {
      clearInterval(interval);
    };
  }, [message]);

  async function onSubmit(input) {
    await onValidated({
      EMAIL: input.subscribe_email
    }); // Reset the form

    reset({
      subscribe_email: ""
    }); // If layout newsletter then close the model

    if (layout === "newsletter") {
      closeModal();
    }
  } // Generate layout className


  const layoutClassName = _objectSpread({}, layout === "newsletter" ? {
    formClassName: "pt-8 sm:pt-10 md:pt-14 mb-1 sm:mb-0",
    divClassName: "",
    inputClassName: "px-4 lg:px-7 h-12 lg:h-14 text-center bg-gray-50",
    buttonClassName: "w-full h-12 lg:h-14 mt-3 sm:mt-4",
    buttonTextClassName: "lg:py-0.5"
  } : {
    formClassName: "flex-shrink-0 w-full sm:w-96 md:w-[545px] z-10 relative",
    divClassName: "flex flex-col sm:flex-row items-start justify-end",
    inputClassName: "px-4 lg:px-7 h-12 lg:h-14 text-center ltr:sm:text-left rtl:sm:text-right bg-white",
    buttonClassName: "mt-3 sm:mt-0 w-full sm:w-auto ltr:sm:ml-2 rtl:sm:mr-2 md:h-full flex-shrink-0",
    buttonTextClassName: "lg:py-0.5"
  });

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
    onSubmit: handleSubmit(onSubmit),
    className: layoutClassName.formClassName,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: layoutClassName.divClassName,
      children: [/*#__PURE__*/jsx_runtime_.jsx(input/* default */.Z, _objectSpread(_objectSpread({
        placeholderKey: "forms:placeholder-email-subscribe",
        type: "email",
        variant: "solid",
        className: "w-full",
        inputClassName: layoutClassName.inputClassName
      }, register("subscribe_email")), {}, {
        errorKey: (_errors$subscribe_ema = errors.subscribe_email) === null || _errors$subscribe_ema === void 0 ? void 0 : _errors$subscribe_ema.message
      })), /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
        className: layoutClassName.buttonClassName,
        loading: status === "sending",
        children: /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: layoutClassName.buttonTextClassName,
          children: t(`common:button-subscribe`)
        })
      })]
    }), status === "success" && /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "my-2 text-xs text-green-600" // @ts-ignore
      ,
      dangerouslySetInnerHTML: {
        __html: responseMessage
      }
    }), status === "error" && /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "my-2 text-xs text-red-500" // @ts-ignore
      ,
      dangerouslySetInnerHTML: {
        __html: responseMessage
      }
    })]
  });
};

const MailchimpForm = ({
  layout = "newsletter"
}) => {
  const url = process.env.NEXT_PUBLIC_MAILCHIMP_URL;
  return /*#__PURE__*/jsx_runtime_.jsx((external_react_mailchimp_subscribe_default()), {
    url: url,
    render: ({
      subscribe,
      status,
      message
    }) => /*#__PURE__*/jsx_runtime_.jsx(CustomForm, {
      status: status,
      message: message,
      layout: layout,
      onValidated: formData => subscribe(formData)
    })
  });
};

/* harmony default export */ const mailchimp_form = (MailchimpForm);
// EXTERNAL MODULE: ./src/utils/get-direction.ts
var get_direction = __webpack_require__(1727);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
;// CONCATENATED MODULE: ./src/components/common/subscription.tsx









const Subscription = ({
  className = "px-5 sm:px-8 md:px-16 2xl:px-24",
  variant = "default"
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    locale
  } = (0,router_.useRouter)();
  const dir = (0,get_direction/* getDirection */.M)(locale);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `${className} flex flex-col justify-center xl:justify-between items-center rounded-lg bg-gray-200 py-10 md:py-14 lg:py-16 ${variant === "default" ? "xl:flex-row" : ""}`,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `-mt-1.5 lg:-mt-2 xl:-mt-0.5 text-center ltr:xl:text-left rtl:xl:text-right ${variant === "default" ? "mb-7 md:mb-8 lg:mb-9 xl:mb-0" : "mb-7  z-10 relative"}`,
      children: [/*#__PURE__*/jsx_runtime_.jsx(ui_text/* default */.Z, {
        variant: "mediumHeading",
        className: "mb-2 md:mb-2.5 lg:mb-3 xl:mb-3.5",
        children: t(`common:text-subscribe-heading`)
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-body text-xs md:text-sm leading-6 md:leading-7",
        children: t(`common:text-subscribe-description`)
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(mailchimp_form, {
      layout: "subscribe"
    }), variant === "modern" ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      style: {
        backgroundImage: dir === 'rtl' ? 'url(/assets/images/subscription-bg-reverse.png)' : 'url(/assets/images/subscription-bg.png)'
      },
      className: `hidden z-0 xl:block bg-no-repeat ${dir === 'rtl' ? 'bg-left 2xl:-left-12 3xl:left-0' : 'bg-right xl:-right-24 2xl:-right-20 3xl:right-0'} bg-contain xl:bg-cover 3xl:bg-contain absolute h-full w-full top-0`
    }) : ""]
  });
};

/* harmony default export */ const subscription = (Subscription);

/***/ }),

/***/ 9637:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_flash_sale_block)
});

// EXTERNAL MODULE: ./src/components/common/section-header.tsx
var section_header = __webpack_require__(7125);
// EXTERNAL MODULE: ./src/components/product/product-card.tsx
var product_card = __webpack_require__(135);
// EXTERNAL MODULE: external "react-content-loader"
var external_react_content_loader_ = __webpack_require__(9081);
var external_react_content_loader_default = /*#__PURE__*/__webpack_require__.n(external_react_content_loader_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/loaders/product-card-grid-loader.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ProductCardGridLoader = props => /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_content_loader_default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 320,
  height: 440,
  viewBox: "0 0 320 440",
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "345",
    rx: "3",
    ry: "3",
    width: "180",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "377",
    rx: "3",
    ry: "3",
    width: "280",
    height: "6"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "416",
    rx: "3",
    ry: "3",
    width: "80",
    height: "10"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "320",
    height: "320"
  })]
}));

/* harmony default export */ const product_card_grid_loader = (ProductCardGridLoader);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: ./src/settings/site.settings.tsx + 6 modules
var site_settings = __webpack_require__(5278);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/404/not-found-item.tsx
var not_found_item = __webpack_require__(6857);
// EXTERNAL MODULE: ./src/components/ui/carousel/carousel.tsx
var carousel = __webpack_require__(4365);
// EXTERNAL MODULE: external "swiper/react"
var react_ = __webpack_require__(2156);
;// CONCATENATED MODULE: ./src/containers/product-flash-sale-block.tsx














const breakpoints = {
  "1500": {
    slidesPerView: 5,
    spaceBetween: 28
  },
  "1025": {
    slidesPerView: 4,
    spaceBetween: 20
  },
  "768": {
    slidesPerView: 3,
    spaceBetween: 20
  },
  "480": {
    slidesPerView: 3,
    spaceBetween: 12
  },
  "0": {
    slidesPerView: 2,
    spaceBetween: 12
  }
};

const ProductsFlashSaleBlock = ({
  sectionHeading = "text-flash-sale",
  className = "mb-12 md:mb-14 xl:mb-16",
  variant = "default",
  limit = 10
}) => {
  var _siteSettings$homePag, _products$data, _products$data2, _products$data3;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const flashSellSettings = site_settings/* siteSettings */.U === null || site_settings/* siteSettings */.U === void 0 ? void 0 : (_siteSettings$homePag = site_settings/* siteSettings.homePageBlocks */.U.homePageBlocks) === null || _siteSettings$homePag === void 0 ? void 0 : _siteSettings$homePag.flashSale;
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,products_query/* useProductsQuery */.kN)({
    limit,
    tags: flashSellSettings === null || flashSellSettings === void 0 ? void 0 : flashSellSettings.slug
  });

  if (!loading && isEmpty_default()(products === null || products === void 0 ? void 0 : products.data)) {
    return /*#__PURE__*/jsx_runtime_.jsx(not_found_item/* default */.Z, {
      text: t("text-no-flash-products-found")
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `${className} ${variant === "default" ? "border border-gray-300 rounded-md pt-5 md:pt-6 lg:pt-7 pb-5 lg:pb-7 px-4 md:px-5 lg:px-7" : ""}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-between items-center flex-wrap mb-5 md:mb-6",
      children: /*#__PURE__*/jsx_runtime_.jsx(section_header/* default */.Z, {
        sectionHeading: sectionHeading,
        className: "mb-0"
      })
    }), error ? /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `${variant === "default" ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-5 gap-x-3 md:gap-x-5 xl:gap-x-7 gap-y-4 lg:gap-y-5 xl:lg:gap-y-6 2xl:gap-y-8" : "block"}`,
      children: loading && products !== null && products !== void 0 && (_products$data = products.data) !== null && _products$data !== void 0 && _products$data.length ? Array.from({
        length: 10
      }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(product_card_grid_loader, {
        uniqueKey: `flash-sale-${idx}`
      }, idx)) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: variant === "default" ? products === null || products === void 0 ? void 0 : (_products$data2 = products.data) === null || _products$data2 === void 0 ? void 0 : _products$data2.map(product => /*#__PURE__*/jsx_runtime_.jsx(product_card/* default */.Z, {
          product: product,
          imgWidth: 324,
          imgHeight: 324,
          variant: "gridSlim"
        }, `product--key${product.id}`)) : /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
          breakpoints: breakpoints,
          buttonClassName: "-mt-8 md:-mt-10",
          autoplay: {
            delay: 3500
          },
          children: products === null || products === void 0 ? void 0 : (_products$data3 = products.data) === null || _products$data3 === void 0 ? void 0 : _products$data3.map(product => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
            children: /*#__PURE__*/jsx_runtime_.jsx(product_card/* default */.Z, {
              product: product,
              imgWidth: 324,
              imgHeight: 324,
              variant: "gridSlim"
            }, `product--key${product.id}`)
          }, `product--key-${product.id}`))
        })
      })
    })]
  });
};

/* harmony default export */ const product_flash_sale_block = (ProductsFlashSaleBlock);

/***/ }),

/***/ 1403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ products_featured)
});

// EXTERNAL MODULE: ./src/components/common/section-header.tsx
var section_header = __webpack_require__(7125);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: ./src/lib/use-price.ts
var use_price = __webpack_require__(7259);
// EXTERNAL MODULE: ./src/contexts/settings.context.tsx
var settings_context = __webpack_require__(3792);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/product/product-overlay-card.tsx








const ProductOverlayCard = ({
  product,
  index,
  variant = "left",
  imgLoading = "lazy"
}) => {
  var _product$image$origin, _product$image;

  // const size =
  //   (variant === "center" && index === 1) || (variant === "left" && index === 0)
  //     ? 620
  //     : 260;
  // const classes =
  //   (variant === "center" && index === 1) || (variant === "left" && index === 0)
  //     ? "row-span-full lg:row-span-2 col-span-full lg:col-span-2"
  //     : "col-span-2 lg:col-span-1";
  let size = 260;
  let classes;
  let indexes = [2, 3];

  if (variant === "left" && index === 0) {
    classes = "row-span-full lg:row-span-2 col-span-full lg:col-span-2";
    size = 620;
  } else if (variant === "center" && index === 1) {
    classes = "row-span-full lg:row-span-2 col-span-full lg:col-span-2";
    size = 620;
  } else if (variant === "combined") {
    if (index === 0) {
      classes = "col-span-2 lg:row-span-2 col-span-full lg:col-span-2";
      size = 620;
    } else if (index === 2) {
      classes = `col-span-2 lg:col-start-4 lg:col-end-5 lg:row-start-1 lg:row-end-3`;
      size = 620;
    } else {
      classes = "col-span-2 lg:col-span-1";
    }
  } else if (variant === "fashion") {
    if (indexes.includes(index)) {
      classes = "lg:grid lg:grid-cols-4 sm:col-span-2";
    } else {
      classes = `sm:col-span-2 lg:col-span-1`;
    }
  } else {
    classes = "col-span-2 lg:col-span-1";
  }

  const {
    openModal,
    setModalView,
    setModalData
  } = (0,ui_context/* useUI */.l8)();
  const settings = (0,settings_context/* useSettings */.rV)();
  const {
    price,
    basePrice,
    discount
  } = (0,use_price/* default */.ZP)({
    amount: product.sale_price ? product.sale_price : product.price,
    baseAmount: product.sale_price
  });
  const {
    price: minPrice
  } = (0,use_price/* default */.ZP)({
    amount: product.min_price
  });
  const {
    price: maxPrice
  } = (0,use_price/* default */.ZP)({
    amount: product.max_price
  });

  function handlePopupView() {
    setModalData(product.slug);
    setModalView("PRODUCT_VIEW");
    return openModal();
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    onClick: handlePopupView,
    className: `${classes} cursor-pointer group flex flex-col bg-gray-200 rounded-md relative items-center justify-between overflow-hidden`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `flex justify-center items-center p-4 h-full 3xl:min-h-[330px] ${indexes.includes(index) && variant === "fashion" ? "lg:col-span-2" : ""}`,
      title: product === null || product === void 0 ? void 0 : product.name,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: (_product$image$origin = product === null || product === void 0 ? void 0 : (_product$image = product.image) === null || _product$image === void 0 ? void 0 : _product$image.original) !== null && _product$image$origin !== void 0 ? _product$image$origin : settings.product.placeholderImage("featured"),
        width: size,
        height: size,
        loading: imgLoading,
        alt: (product === null || product === void 0 ? void 0 : product.name) || "Product Image",
        className: "object-cover transition duration-500 ease-in-out transform group-hover:scale-110"
      })
    }), discount && /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "absolute top-3.5 md:top-5 3xl:top-7 ltr:left-3.5 rtl:right-3.5 ltr:md:left-5 ltr:3xl:left-7 rtl:md:right-5 rtl:3xl:right-7 bg-heading text-white text-10px md:text-sm leading-5 rounded-md inline-block px-2 xl:px-3 pt-0.5 pb-1",
      children: discount
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `flex flex-col w-full px-4 md:px-5 3xl:px-7 pb-4 md:pb-5 3xl:pb-7 md:justify-between md:items-center md:flex-row ${indexes.includes(index) && variant === "fashion" ? "lg:col-span-2 lg:flex-col lg:justify-start lg:items-start" : "2xl:flex-row lg:items-start 2xl:items-center lg:flex-col"}`,
      title: product === null || product === void 0 ? void 0 : product.name,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `${indexes.includes(index) && variant === "fashion" ? "lg:pb-4 2xl:pb-8 ltr:md:pr-2 rtl:md:pl-2" : "ltr:md:pr-2 ltr:lg:pr-0 ltr:2xl:pr-2 rtl:md:pl-2 rtl:lg:pl-0 rtl:2xl:pl-2"} overflow-hidden`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "text-heading font-semibold text-sm md:text-base xl:text-lg mb-1 truncate",
          children: product === null || product === void 0 ? void 0 : product.name
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-body text-xs md:text-[13px] xl:text-sm leading-normal xl:leading-relaxed truncate max-w-[250px] lg:max-w-[190px]",
          children: product === null || product === void 0 ? void 0 : product.description
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `flex-shrink-0 flex flex-row-reverse md:flex-col lg:flex-row-reverse 2xl:flex-col justify-end mt-2 md:-mt-0.5 lg:mt-2 2xl:-mt-0.5 ${indexes.includes(index) && variant === "fashion" ? "" : "items-center md:items-end lg:items-start 2xl:items-end ltr:md:text-right rtl:md:text-left ltr:lg:text-left rtl:lg:text-right ltr:xl:text-right rtl:xl:text-left"}`,
        children: product.product_type === "variable" ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "text-heading font-segoe font-semibold text-base xl:text-xl 3xl:text-2xl 3xl:mt-0.5 ltr:pr-2 ltr:md:pr-0 ltr:lg:pr-2 ltr:2xl:pr-0 rtl:pl-2 rtl:md:pl-0 rtl:lg:pl-2 rtl:2xl:pl-0",
          children: [minPrice, " - ", maxPrice]
        }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [discount && /*#__PURE__*/jsx_runtime_.jsx("del", {
            className: "text-sm md:text-base lg:text-sm xl:text-base 3xl:text-lg",
            children: price
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-heading font-segoe font-semibold text-base xl:text-xl 3xl:text-2xl 3xl:mt-0.5 ltr:pr-2 ltr:md:pr-0 ltr:lg:pr-2 ltr:2xl:pr-0 rtl:pl-2 rtl:md:pl-0 rtl:lg:pl-2 rtl:2xl:pl-0",
            children: basePrice ? basePrice : price
          })]
        })
      })]
    })]
  });
};

/* harmony default export */ const product_overlay_card = (ProductOverlayCard);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: ./src/components/ui/loaders/spinner/spinner.tsx
var spinner = __webpack_require__(9204);
// EXTERNAL MODULE: ./src/settings/site.settings.tsx + 6 modules
var site_settings = __webpack_require__(5278);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/404/not-found-item.tsx
var not_found_item = __webpack_require__(6857);
;// CONCATENATED MODULE: ./src/containers/products-featured.tsx













const ProductsFeatured = ({
  sectionHeading,
  categorySlug,
  className = "mb-12 md:mb-14 xl:mb-16",
  variant = "left",
  limit = 5
}) => {
  var _siteSettings$homePag, _products$data;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const featuredProductsSettings = site_settings/* siteSettings */.U === null || site_settings/* siteSettings */.U === void 0 ? void 0 : (_siteSettings$homePag = site_settings/* siteSettings.homePageBlocks */.U.homePageBlocks) === null || _siteSettings$homePag === void 0 ? void 0 : _siteSettings$homePag.featuredProducts;
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,products_query/* useProductsQuery */.kN)({
    limit,
    tags: featuredProductsSettings === null || featuredProductsSettings === void 0 ? void 0 : featuredProductsSettings.slug
  });

  if (!loading && isEmpty_default()(products === null || products === void 0 ? void 0 : products.data)) {
    return /*#__PURE__*/jsx_runtime_.jsx(not_found_item/* default */.Z, {
      text: t("text-no-featured-products-found")
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/jsx_runtime_.jsx(section_header/* default */.Z, {
      sectionHeading: sectionHeading,
      categorySlug: categorySlug
    }), error && /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
      message: error.message
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "grid grid-cols-4 grid-rows-2 gap-3 md:gap-5 xl:gap-7",
      children: loading ? /*#__PURE__*/jsx_runtime_.jsx(spinner/* default */.Z, {
        showText: false
      }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: products === null || products === void 0 ? void 0 : (_products$data = products.data) === null || _products$data === void 0 ? void 0 : _products$data.map((product, idx) => /*#__PURE__*/jsx_runtime_.jsx(product_overlay_card, {
          product: product,
          variant: variant,
          index: idx
        }, `product--key${product.id}`))
      })
    })]
  });
};

/* harmony default export */ const products_featured = (ProductsFeatured);

/***/ })

};
;