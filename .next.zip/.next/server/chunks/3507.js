"use strict";
exports.id = 3507;
exports.ids = [3507];
exports.modules = {

/***/ 5927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lib_use_price__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7259);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8579);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lib_placeholders__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9742);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const ItemCard = ({
  item,
  notAvailable
}) => {
  var _item$image;

  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
  const {
    price
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_0__/* .default */ .ZP)({
    amount: item.itemTotal
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex justify-between items-center py-2.5"),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: "w-[60px] h-[60px] ltr:mr-4 rtl:ml-4 rounded-md overflow-hidden flex-shrink-0",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__.default, {
        src: (_item$image = item === null || item === void 0 ? void 0 : item.image) !== null && _item$image !== void 0 ? _item$image : _lib_placeholders__WEBPACK_IMPORTED_MODULE_4__/* .productPlaceholderThumbnail */ .Y4,
        width: 60,
        height: 60,
        quality: 100,
        className: "bg-gray-100 object-cover"
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("p", {
      className: "flex items-center justify-between text-base ltr:pr-1.5 ltr:pl-1.5 ltr:mr-auto rtl:ml-auto",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("span", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-sm", notAvailable ? "text-red-500" : "text-body"),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
          className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-sm font-bold", notAvailable ? "text-red-500" : "text-heading"),
          children: item.quantity
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
          className: "mx-2",
          children: "x"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
          children: item.name
        }), " | ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
          children: item.unit
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
      className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-sm font-semibold ", notAvailable ? "text-red-500" : "text-heading"),
      children: !notAvailable ? price : t("text-unavailable")
    })]
  }, item.id);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ItemCard);

/***/ }),

/***/ 9688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ ItemInfoRow)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const ItemInfoRow = ({
  title,
  value
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
  className: "flex justify-between px-6 py-5 border-t border-gray-100",
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
    className: "text-sm text-body",
    children: title
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
    className: "text-sm font-semibold text-heading",
    children: value
  })]
});

/***/ }),

/***/ 482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




const EmptyCart = ({
  width = 190.502,
  height = 209.011,
  className
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 190.502 209.011",
    className: className,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("g", {
      id: "Group_2903",
      "data-name": "Group 2903",
      transform: "translate(-1551.657 -392.09)",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("ellipse", {
        id: "Ellipse_26",
        "data-name": "Ellipse 26",
        cx: "95.251",
        cy: "22.48",
        rx: "95.251",
        ry: "22.48",
        transform: "translate(1551.657 556.141)",
        fill: "#ddd"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
        id: "Rectangle_516",
        "data-name": "Rectangle 516",
        width: "166.331",
        height: "172.367",
        rx: "18.611",
        transform: "translate(1563.742 410.583)",
        fill: "#bc8d55"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
        id: "Rectangle_517",
        "data-name": "Rectangle 517",
        width: "166.331",
        height: "50.227",
        rx: "14.953",
        transform: "translate(1563.742 392.09)",
        fill: "#986e42"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("g", {
        id: "Group_2903-2",
        "data-name": "Group 2903",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
          id: "Path_2724",
          "data-name": "Path 2724",
          d: "M1571.7,393.834a16.08,16.08,0,0,0-7.946,14.066v21.636A16.08,16.08,0,0,0,1571.7,443.6c8.253-5.689,13.59-14.717,13.59-24.884S1579.949,399.523,1571.7,393.834Z",
          fill: "#bc8d55"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
          id: "Path_2725",
          "data-name": "Path 2725",
          d: "M1722.119,443.6a16.08,16.08,0,0,0,7.946-14.066V407.9a16.08,16.08,0,0,0-7.946-14.066c-8.253,5.689-13.59,14.717-13.59,24.884S1713.866,437.913,1722.119,443.6Z",
          fill: "#bc8d55"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("g", {
        id: "Group_2905",
        "data-name": "Group 2905",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("g", {
          id: "Group_2904",
          "data-name": "Group 2904",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
            id: "Path_2726",
            "data-name": "Path 2726",
            d: "M1604.4,481.467a7.229,7.229,0,1,0,7.229,7.229A7.238,7.238,0,0,0,1604.4,481.467Z",
            fill: "#212121"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
            id: "Path_2727",
            "data-name": "Path 2727",
            d: "M1684.382,481.467a7.229,7.229,0,1,0,7.231,7.229A7.24,7.24,0,0,0,1684.382,481.467Z",
            fill: "#212121"
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
          id: "Path_2728",
          "data-name": "Path 2728",
          d: "M1618.752,548.288a357.614,357.614,0,0,0,61.226-16.174c4.1-1.484,2.334-8.09-1.817-6.59a357.615,357.615,0,0,1-61.226,16.174c-4.326.741-2.492,7.328,1.817,6.59Z",
          fill: "#212121"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
          id: "Path_2729",
          "data-name": "Path 2729",
          d: "M1589.056,483.262h37.009c4.4,0,4.405-6.834,0-6.834h-37.009c-4.4,0-4.4,6.834,0,6.834Z",
          fill: "#212121"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("path", {
          id: "Path_2730",
          "data-name": "Path 2730",
          d: "M1667.75,483.262h37.009c4.4,0,4.4-6.834,0-6.834H1667.75c-4.4,0-4.405,6.834,0,6.834Z",
          fill: "#212121"
        })]
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmptyCart);

/***/ }),

/***/ 784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const ValidationError = ({
  message
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
    className: "my-2 text-sm text-left text-red-500",
    children: message
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ValidationError);

/***/ }),

/***/ 7035:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ formatOrderedProduct)
/* harmony export */ });
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function formatOrderedProduct(product) {
  return _objectSpread(_objectSpread({
    product_id: product !== null && product !== void 0 && product.productId ? product.productId : product.id
  }, product !== null && product !== void 0 && product.variationId ? {
    variation_option_id: product.variationId
  } : {}), {}, {
    order_quantity: product.quantity,
    unit_price: product.price,
    subtotal: product.itemTotal
  });
}

/***/ })

};
;