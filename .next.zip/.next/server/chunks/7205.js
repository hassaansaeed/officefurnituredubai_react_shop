"use strict";
exports.id = 7205;
exports.ids = [7205];
exports.modules = {

/***/ 7205:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ address_form)
});

// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
// EXTERNAL MODULE: ./src/components/ui/input.tsx
var input = __webpack_require__(4271);
// EXTERNAL MODULE: ./src/components/ui/label.tsx
var label = __webpack_require__(2357);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/radiobox.tsx
const _excluded = ["labelKey"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const RadioBox = /*#__PURE__*/external_react_default().forwardRef((_ref, ref) => {
  let {
    labelKey
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("forms");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
    className: "group flex items-center text-heading text-sm cursor-pointer",
    children: [/*#__PURE__*/jsx_runtime_.jsx("input", _objectSpread({
      type: "radio",
      className: "form-radio w-5 h-5 border border-gray-300 text-heading rounded-full cursor-pointer transition duration-500 ease-in-out focus:ring-offset-0 hover:border-heading focus:outline-none focus:ring-0 focus-visible:outline-none checked:bg-heading",
      ref: ref
    }, rest)), /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "ltr:ml-2 rtl:mr-2 text-sm text-heading relative",
      children: t(`${labelKey}`)
    })]
  });
});
// EXTERNAL MODULE: ./src/components/ui/text-area.tsx
var text_area = __webpack_require__(1876);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(9440);
// EXTERNAL MODULE: ./src/framework/rest/utils/constants.ts
var constants = __webpack_require__(3749);
// EXTERNAL MODULE: external "@hookform/resolvers/yup"
var yup_ = __webpack_require__(2166);
// EXTERNAL MODULE: external "react-hook-form"
var external_react_hook_form_ = __webpack_require__(2662);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: ./src/framework/rest/customer/customer.query.ts
var customer_query = __webpack_require__(799);
;// CONCATENATED MODULE: ./src/components/address/address-form.tsx
function address_form_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function address_form_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { address_form_ownKeys(Object(source), true).forEach(function (key) { address_form_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { address_form_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function address_form_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















const addressSchema = external_yup_.object().shape({
  type: external_yup_.string().oneOf([constants/* AddressType.Billing */.D.Billing, constants/* AddressType.Shipping */.D.Shipping]).required("error-type-required"),
  title: external_yup_.string().required("error-title-required"),
  address: external_yup_.object().shape({
    country: external_yup_.string().required("error-country-required"),
    city: external_yup_.string().required("error-city-required"),
    state: external_yup_.string().required("error-state-required"),
    zip: external_yup_.string().required("error-zip-required"),
    street_address: external_yup_.string().required("error-street-required")
  })
});

const AddressForm = ({
  data
}) => {
  var _address$title, _address$type, _errors$title, _errors$address, _errors$address$count, _errors$address2, _errors$address2$city, _errors$address3, _errors$address3$stat, _errors$address4, _errors$address4$zip, _errors$address5, _errors$address5$stre;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    address,
    type,
    customerId
  } = data;
  const {
    mutate: updateProfile
  } = (0,customer_query/* useUpdateCustomerMutation */.o)();
  const {
    closeModal
  } = (0,ui_context/* useUI */.l8)();

  function onSubmit(values) {
    const formattedInput = {
      id: address === null || address === void 0 ? void 0 : address.id,
      customer_id: customerId,
      title: values.title,
      type: values.type,
      address: address_form_objectSpread(address_form_objectSpread({}, (address === null || address === void 0 ? void 0 : address.id) && {
        id: address.id
      }), values.address)
    };
    updateProfile({
      id: customerId,
      address: [formattedInput]
    });
    closeModal();
  }

  const {
    register,
    handleSubmit,
    formState: {
      errors
    }
  } = (0,external_react_hook_form_.useForm)({
    resolver: (0,yup_.yupResolver)(addressSchema),
    shouldUnregister: true,
    defaultValues: address_form_objectSpread({
      title: (_address$title = address === null || address === void 0 ? void 0 : address.title) !== null && _address$title !== void 0 ? _address$title : "",
      type: (_address$type = address === null || address === void 0 ? void 0 : address.type) !== null && _address$type !== void 0 ? _address$type : type
    }, (address === null || address === void 0 ? void 0 : address.address) && address)
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "p-5 sm:p-8 md:rounded-xl min-h-screen md:min-h-0 bg-white",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
      className: "text-heading font-semibold text-lg text-center mb-4 sm:mb-6",
      children: address ? t("text-update-address") : t("text-add-new-address")
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      onSubmit: handleSubmit(onSubmit),
      className: "grid grid-cols-2 gap-5 h-full",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/jsx_runtime_.jsx(label/* default */.Z, {
          children: t("text-type")
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "space-x-4 rtl:space-x-reverse flex items-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx(RadioBox, address_form_objectSpread(address_form_objectSpread({
            id: "billing"
          }, register("type")), {}, {
            type: "radio",
            value: constants/* AddressType.Billing */.D.Billing,
            labelKey: t("text-billing")
          })), /*#__PURE__*/jsx_runtime_.jsx(RadioBox, address_form_objectSpread(address_form_objectSpread({
            id: "shipping"
          }, register("type")), {}, {
            type: "radio",
            value: constants/* AddressType.Shipping */.D.Shipping,
            labelKey: t("text-shipping")
          }))]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(input/* default */.Z, address_form_objectSpread(address_form_objectSpread({
        labelKey: t("text-title")
      }, register("title")), {}, {
        errorKey: t((_errors$title = errors.title) === null || _errors$title === void 0 ? void 0 : _errors$title.message),
        variant: "outline",
        className: "col-span-2"
      })), /*#__PURE__*/jsx_runtime_.jsx(input/* default */.Z, address_form_objectSpread(address_form_objectSpread({
        labelKey: t("text-country")
      }, register("address.country")), {}, {
        errorKey: t((_errors$address = errors.address) === null || _errors$address === void 0 ? void 0 : (_errors$address$count = _errors$address.country) === null || _errors$address$count === void 0 ? void 0 : _errors$address$count.message),
        variant: "outline"
      })), /*#__PURE__*/jsx_runtime_.jsx(input/* default */.Z, address_form_objectSpread(address_form_objectSpread({
        labelKey: t("text-city")
      }, register("address.city")), {}, {
        errorKey: t((_errors$address2 = errors.address) === null || _errors$address2 === void 0 ? void 0 : (_errors$address2$city = _errors$address2.city) === null || _errors$address2$city === void 0 ? void 0 : _errors$address2$city.message),
        variant: "outline"
      })), /*#__PURE__*/jsx_runtime_.jsx(input/* default */.Z, address_form_objectSpread(address_form_objectSpread({
        labelKey: t("text-state")
      }, register("address.state")), {}, {
        errorKey: t((_errors$address3 = errors.address) === null || _errors$address3 === void 0 ? void 0 : (_errors$address3$stat = _errors$address3.state) === null || _errors$address3$stat === void 0 ? void 0 : _errors$address3$stat.message),
        variant: "outline"
      })), /*#__PURE__*/jsx_runtime_.jsx(input/* default */.Z, address_form_objectSpread(address_form_objectSpread({
        labelKey: t("text-zip")
      }, register("address.zip")), {}, {
        errorKey: t((_errors$address4 = errors.address) === null || _errors$address4 === void 0 ? void 0 : (_errors$address4$zip = _errors$address4.zip) === null || _errors$address4$zip === void 0 ? void 0 : _errors$address4$zip.message),
        variant: "outline"
      })), /*#__PURE__*/jsx_runtime_.jsx(text_area/* default */.Z, address_form_objectSpread(address_form_objectSpread({
        labelKey: t("text-street-address")
      }, register("address.street_address")), {}, {
        errorKey: t((_errors$address5 = errors.address) === null || _errors$address5 === void 0 ? void 0 : (_errors$address5$stre = _errors$address5.street_address) === null || _errors$address5$stre === void 0 ? void 0 : _errors$address5$stre.message),
        variant: "outline",
        className: "col-span-2"
      })), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_button/* default */.Z, {
        className: "w-full col-span-2",
        children: [address ? t("text-update") : t("text-save"), " ", t("text-address")]
      })]
    })]
  });
};

/* harmony default export */ const address_form = (AddressForm);

/***/ }),

/***/ 3749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ AddressType)
/* harmony export */ });
let AddressType;

(function (AddressType) {
  AddressType["Billing"] = "billing";
  AddressType["Shipping"] = "shipping";
})(AddressType || (AddressType = {}));

/***/ })

};
;