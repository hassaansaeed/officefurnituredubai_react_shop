"use strict";
exports.id = 7267;
exports.ids = [7267];
exports.modules = {

/***/ 6857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const NotFoundItem = ({
  text
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
  className: "shadow-lg rounded border border-gray-300 p-5 mb-12 md:mb-14 xl:mb-16",
  children: text
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotFoundItem);

/***/ }),

/***/ 5038:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1420);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8579);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3396);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);







function getImage(deviceWidth, imgObj) {
  return deviceWidth < 480 ? imgObj.mobile : imgObj.desktop;
}

const BannerCard = ({
  data,
  className,
  variant = "rounded",
  effectActive = false,
  classNameInner,
  href
}) => {
  const {
    width
  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__/* .useWindowSize */ .i)();
  const {
    title,
    image
  } = data;
  const selectedImage = getImage(width, image);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("mx-auto", className),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      href: href,
      className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("h-full group flex justify-center relative overflow-hidden", classNameInner),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__.default, {
        src: selectedImage.url,
        width: selectedImage.width,
        height: selectedImage.height,
        alt: title,
        quality: 100,
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("bg-gray-300 object-cover w-full", {
          "rounded-md": variant === "rounded"
        })
      }), effectActive && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "absolute top-0 -left-full h-full w-1/2 z-5 block transform -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-40 group-hover:animate-shine"
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerCard);

/***/ }),

/***/ 3765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1420);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8579);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4068);
/* harmony import */ var _react_icons_all_files_fa_FaLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3903);
/* harmony import */ var _react_icons_all_files_fa_FaLink__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_react_icons_all_files_fa_FaLink__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);





 // import { filterBrandImages } from "@lib/filter-brands";





const Card = ({
  item,
  variant = "circle",
  // size = "small",
  effectActive = false,
  effectPosition = "imageOnly",
  href,
  image
}) => {
  var _image$original;

  const {
    name,
    products_count
  } = item !== null && item !== void 0 ? item : {};
  const imageSize = variant === "circle" && 180 || variant === "rounded" && 198 || variant === "modern" && 99 || variant === "elegant" && 48;
  let size = "small";

  if (variant === "circle" || variant === "elegant") {
    size = "small";
  } else if (variant === "rounded") {
    size = "medium";
  } else if (variant === "modern") {
    size = "big";
  } else {
    size = "small";
  }

  const placeholderImage = `/assets/placeholder/card-${size}.svg`;
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)("common"); // const image = item?.image?.original ?? filterBrandImages(item?.images, "slider-layout")?.image?.[0]?.original ?? placeholderImage;

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
    href: href,
    className: `group flex justify-center ${variant === "elegant" ? "text-left rounded-lg px-6 lg:px-8 pt-7 lg:pt-10 pb-5 lg:pb-8 bg-gray-200" : "text-center"} flex-col relative ${variant === "modern" ? "lg:h-60 md:h-48 h-44 w-full bg-gray-200 rounded-md" : ""}`,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
      className: `relative inline-flex ${variant === "elegant" ? "" : " mx-auto "} ${["rounded", "modern", "elegant"].includes(variant) && "rounded-md" || variant === "circle" && "rounded-full"} ${variant !== "modern" ? " mb-3.5 md:mb-4 lg:mb-5 xl:mb-6" : " xl:mb-8 md:mb-4"}`,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
        className: "flex",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__.default, {
          src: (_image$original = image === null || image === void 0 ? void 0 : image.original) !== null && _image$original !== void 0 ? _image$original : placeholderImage,
          alt: name || t("text-card-thumbnail"),
          width: imageSize,
          height: imageSize,
          quality: 100,
          className: `${(["rounded", "modern", "elegant"].includes(variant) ? "rounded-md" : "") || variant === "circle" && "rounded-full"} ${["elegant", "modern"].includes(variant) ? "object-contain" : "object-cover bg-gray-300"}`
        })
      }), effectActive === true && effectPosition === "imageOnly" && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
          className: `absolute top-0 left-0 bg-black w-full h-full opacity-0 transition-opacity duration-300 group-hover:opacity-30 ${["rounded", "modern", "elegant"].includes(variant) && "rounded-md" || variant === "circle" && "rounded-full"}`
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
          className: "absolute top-0 left-0 h-full w-full flex items-center justify-center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_react_icons_all_files_fa_FaLink__WEBPACK_IMPORTED_MODULE_3__.FaLink, {
            className: "text-white text-base sm:text-xl lg:text-2xl xl:text-3xl transform opacity-0 scale-0 transition-all duration-300 ease-in-out group-hover:opacity-100 group-hover:scale-100"
          })
        })]
      })]
    }), variant === "modern" ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      variant: "heading",
      className: "text-heading text-sm md:text-base xl:text-lg font-semibold capitalize absolute text-center bottom-4 sm:bottom-5 md:bottom-6 xl:bottom-8 inset-x-0 z-10",
      children: name
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      variant: "heading",
      className: "capitalize",
      children: name
    }), variant === "elegant" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_components_ui_text__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      className: "text-body text-sm sm:leading-6 leading-7 pb-0.5 truncate",
      children: [products_count, " ", products_count > 1 || products_count === 0 ? t("text-products") : t("text-product")]
    }) : "", effectActive === true && effectPosition === "fullBody" && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
        className: `absolute top-0 left-0 bg-black w-full h-full opacity-0 transition-opacity duration-300 group-hover:opacity-30 ${["rounded", "modern", "elegant"].includes(variant) && "rounded-md" || variant === "circle" && "rounded-full"}`
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
        className: "absolute top-0 left-0 h-full w-full flex items-center justify-center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_react_icons_all_files_fa_FaLink__WEBPACK_IMPORTED_MODULE_3__.FaLink, {
          className: "text-white text-base sm:text-xl lg:text-2xl xl:text-3xl transform opacity-0 scale-0 transition-all duration-300 ease-in-out group-hover:opacity-100 group-hover:scale-100"
        })
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);

/***/ }),

/***/ 7125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4068);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1420);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const SectionHeader = ({
  sectionHeading = "text-section-title",
  categorySlug,
  className = "pb-0.5 mb-4 md:mb-5 lg:mb-6 2xl:mb-7 3xl:mb-8"
}) => {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: `flex items-center justify-between -mt-2 lg:-mt-2.5 ${className}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      variant: "mediumHeading",
      children: t(`${sectionHeading}`)
    }), categorySlug && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_components_ui_link__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      href: categorySlug,
      className: "text-xs lg:text-sm xl:text-base text-heading mt-0.5 lg:mt-1",
      children: t("text-see-all-product")
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionHeader);

/***/ }),

/***/ 4584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NewArrivalsProductFeed)
/* harmony export */ });
/* harmony import */ var _containers_products_block__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1402);
/* harmony import */ var _framework_products_products_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2317);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_404_not_found_item__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6857);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);






function NewArrivalsProductFeed() {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,_framework_products_products_query__WEBPACK_IMPORTED_MODULE_1__/* .useProductsQuery */ .kN)({
    limit: 10,
    orderBy: "created_at",
    sortedBy: "DESC"
  });

  if (!loading && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(products === null || products === void 0 ? void 0 : products.data)) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_404_not_found_item__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
      text: t("text-no-products-found")
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_containers_products_block__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
    sectionHeading: "text-new-arrivals",
    products: products === null || products === void 0 ? void 0 : products.data,
    loading: loading,
    error: error === null || error === void 0 ? void 0 : error.message,
    uniqueKey: "new-arrivals"
  });
}

/***/ }),

/***/ 1802:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9081);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const CardRoundedLoader = props => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)((react_content_loader__WEBPACK_IMPORTED_MODULE_0___default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 197,
  height: 249,
  viewBox: "0 0 197 249",
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
    x: "34",
    y: "230",
    rx: "3",
    ry: "3",
    width: "110",
    height: "10"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "197",
    height: "197"
  })]
}));

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardRoundedLoader);

/***/ }),

/***/ 1402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7125);
/* harmony import */ var _components_product_product_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(135);
/* harmony import */ var _components_ui_loaders_product_feed_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4636);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5013);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const ProductsBlock = ({
  sectionHeading,
  categorySlug,
  className = "mb-9 md:mb-9 lg:mb-10 xl:mb-12",
  products,
  loading,
  error,
  uniqueKey
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      sectionHeading: sectionHeading,
      categorySlug: categorySlug
    }), error ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
      message: error
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-5 gap-x-3 md:gap-x-5 xl:gap-x-7 gap-y-3 xl:gap-y-5 2xl:gap-y-8",
      children: loading && !(products !== null && products !== void 0 && products.length) ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_loaders_product_feed_loader__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
        limit: 10,
        uniqueKey: uniqueKey
      }) : products === null || products === void 0 ? void 0 : products.map(product => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_product_product_card__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
        product: product,
        imgWidth: 340,
        imgHeight: 440,
        variant: "grid"
      }, `product--key${product.id}`))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsBlock);

/***/ }),

/***/ 5941:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fq": () => (/* binding */ masonryBanner),
/* harmony export */   "cU": () => (/* binding */ gridBanner),
/* harmony export */   "q6": () => (/* binding */ promotionBanner),
/* harmony export */   "b8": () => (/* binding */ modernDemoBanner),
/* harmony export */   "Im": () => (/* binding */ modernDemoProductBanner),
/* harmony export */   "gS": () => (/* binding */ standardDemoBanner),
/* harmony export */   "RW": () => (/* binding */ standardDemoHeroBanner),
/* harmony export */   "bF": () => (/* binding */ standardDemoPromotionBanner),
/* harmony export */   "rb": () => (/* binding */ minimalDemoBanner),
/* harmony export */   "qv": () => (/* binding */ minimalDemoHeroBanner),
/* harmony export */   "VW": () => (/* binding */ vintageDemoProductBanner),
/* harmony export */   "G5": () => (/* binding */ vintageDemoBanner),
/* harmony export */   "ik": () => (/* binding */ vintageDemoGridBanner),
/* harmony export */   "s5": () => (/* binding */ classicDemoBanner),
/* harmony export */   "lD": () => (/* binding */ classicDemoProductBanner),
/* harmony export */   "gY": () => (/* binding */ classicDemoBannerTwo),
/* harmony export */   "bp": () => (/* binding */ classicDemoBannerThree),
/* harmony export */   "uf": () => (/* binding */ homeElegantHeroSlider),
/* harmony export */   "og": () => (/* binding */ elegantBannerDataThree),
/* harmony export */   "hn": () => (/* binding */ elegantHomeBanner),
/* harmony export */   "MH": () => (/* binding */ homeRefinedHeroBanner),
/* harmony export */   "rd": () => (/* binding */ saleBannerWithProducts),
/* harmony export */   "R3": () => (/* binding */ bannerDataFour),
/* harmony export */   "f9": () => (/* binding */ bannerDataFourMobile),
/* harmony export */   "iy": () => (/* binding */ homeEightWinterBanner),
/* harmony export */   "wj": () => (/* binding */ homeEightCoupons),
/* harmony export */   "vO": () => (/* binding */ fashionHomeHeroGridSlider),
/* harmony export */   "Zp": () => (/* binding */ fashionSaleBannerWithProducts),
/* harmony export */   "W_": () => (/* binding */ fashionSaleBannerData),
/* harmony export */   "JS": () => (/* binding */ fashionSaleBannerDataGallery)
/* harmony export */ });
/* unused harmony exports trendyDemoHeroBanner, saleBannerGrid, homeTrendyCoupons, homeTrendyProductWithBanner */
// Common data for all demo
const masonryBanner = [{
  id: 1,
  title: "Men's Collection",
  slug: "mens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-1.jpg",
      width: 470,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-1.jpg",
      width: 1078,
      height: 425
    }
  },
  type: "medium"
}, {
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-2.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-2.jpg",
      width: 425,
      height: 425
    }
  },
  type: "small"
}, {
  id: 3,
  title: "Dress Women",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-3.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-3.jpg",
      width: 425,
      height: 425
    }
  },
  type: "small"
}, {
  id: 4,
  title: "Exclusive Sunglasses",
  slug: "exclusive-sunglasses",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-4.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-4.jpg",
      width: 425,
      height: 425
    }
  },
  type: "small"
}, {
  id: 5,
  title: "Product Coupons",
  slug: "product-coupons",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-5.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-5.jpg",
      width: 425,
      height: 425
    }
  },
  type: "small"
}, {
  id: 6,
  title: "New Backpack",
  slug: "new-backpack",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-6.jpg",
      width: 470,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-6.jpg",
      width: 1078,
      height: 425
    }
  },
  type: "medium"
}];
const gridBanner = [{
  id: 1,
  title: "Women T-Shirts Collection",
  slug: "mens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/banner-mobile-1.jpg",
      width: 450,
      height: 140
    },
    desktop: {
      url: "/assets/images/banner/grid/banner-1.jpg",
      width: 885,
      height: 430
    }
  },
  type: "small"
}, {
  id: 2,
  title: "Women Jins Collection",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/banner-mobile-2.jpg",
      width: 450,
      height: 140
    },
    desktop: {
      url: "/assets/images/banner/grid/banner-2.jpg",
      width: 885,
      height: 430
    }
  },
  type: "small"
}, {
  id: 3,
  title: "New Backpack",
  slug: "new-backpack",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/banner-mobile-3.jpg",
      width: 450,
      height: 140
    },
    desktop: {
      url: "/assets/images/banner/grid/banner-3.jpg",
      width: 1800,
      height: 430
    }
  },
  type: "large"
}];
const promotionBanner = [{
  id: 1,
  title: "Travel Baggage",
  slug: "new-backpack",
  image: {
    mobile: {
      url: "/assets/images/banner/slider/mobile/banner-1.jpg",
      width: 450,
      height: 180
    },
    desktop: {
      url: "/assets/images/banner/slider/banner-1.jpg",
      width: 1440,
      height: 570
    }
  },
  type: "small"
}, {
  id: 2,
  title: "Women's Collection",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/slider/mobile/banner-2.jpg",
      width: 450,
      height: 180
    },
    desktop: {
      url: "/assets/images/banner/slider/banner-2.png",
      width: 1440,
      height: 570
    }
  },
  type: "small"
}, {
  id: 3,
  title: "Winter Collection",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/slider/mobile/banner-3.jpg",
      width: 450,
      height: 180
    },
    desktop: {
      url: "/assets/images/banner/slider/banner-3.jpg",
      width: 1440,
      height: 570
    }
  },
  type: "small"
}]; // Demo One -> Modern Demo

const modernDemoBanner = [{
  id: 1,
  title: "Winter Collection of Kid Items",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-3.jpg",
      width: 450,
      height: 180
    },
    desktop: {
      url: "/assets/images/banner/banner-3.jpg",
      width: 1800,
      height: 570
    }
  }
}, {
  id: 2,
  title: "Offer Off Everything",
  slug: "winter-offer",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-4.jpg",
      width: 450,
      height: 130
    },
    desktop: {
      url: "/assets/images/banner/banner-4.jpg",
      width: 1800,
      height: 420
    }
  }
}];
const modernDemoProductBanner = [{
  id: 1,
  title: "Sale Offer",
  slug: "flash-sale",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-sale-offer.jpg",
      width: 430,
      height: 600
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer.jpg",
      width: 430,
      height: 600
    }
  }
}, {
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-sale-offer-reverse.jpg",
      width: 430,
      height: 600
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer-reverse.jpg",
      width: 430,
      height: 600
    }
  }
}]; // Demo Two -> Standard Demo

const standardDemoBanner = {
  id: 1,
  title: "Holiday Offers",
  slug: "winter-offer",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-1.jpg",
      width: 450,
      height: 120
    },
    desktop: {
      url: "/assets/images/banner/banner-1.jpg",
      width: 1800,
      height: 270
    }
  }
};
const standardDemoHeroBanner = [{
  id: 1,
  title: "winter collection",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/banner-mobile-1.jpg",
      width: 480,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/banner-1.jpg",
      width: 1800,
      height: 800
    }
  }
}, {
  id: 2,
  title: "gift collection",
  slug: "gift-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/banner-mobile-2.jpg",
      width: 480,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/banner-2.jpg",
      width: 1800,
      height: 800
    }
  }
}, {
  id: 3,
  title: "party collection",
  slug: "gift-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/banner-mobile-3.jpg",
      width: 480,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/banner-3.jpg",
      width: 1800,
      height: 800
    }
  }
}];
const standardDemoPromotionBanner = [{
  id: 1,
  title: "Men's Collection",
  slug: "mens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/small/banner-mobile-1.jpg",
      width: 450,
      height: 150
    },
    desktop: {
      url: "/assets/images/banner/small/banner-1.jpg",
      width: 580,
      height: 360
    }
  }
}, {
  id: 2,
  title: "Women's Collection",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/small/banner-mobile-2.jpg",
      width: 450,
      height: 150
    },
    desktop: {
      url: "/assets/images/banner/small/banner-2.jpg",
      width: 580,
      height: 360
    }
  }
}, {
  id: 3,
  title: "Kid's Collection",
  slug: "kids-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/small/banner-mobile-3.jpg",
      width: 450,
      height: 150
    },
    desktop: {
      url: "/assets/images/banner/small/banner-3.jpg",
      width: 580,
      height: 360
    }
  }
}]; // Demo Three -> Minimal Demo

const minimalDemoBanner = {
  id: 1,
  title: "Holiday Offers",
  slug: "winter-offer",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-1.jpg",
      width: 450,
      height: 120
    },
    desktop: {
      url: "/assets/images/banner/banner-1.jpg",
      width: 1800,
      height: 270
    }
  }
};
const minimalDemoHeroBanner = [{
  id: 1,
  title: "winter collection",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/two/banner-mobile-1.jpg",
      width: 450,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/two/banner-1.jpg",
      width: 1450,
      height: 800
    }
  }
}, {
  id: 2,
  title: "gift collection",
  slug: "gift-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/two/banner-mobile-2.jpg",
      width: 450,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/two/banner-2.jpg",
      width: 1450,
      height: 800
    }
  }
}, {
  id: 3,
  title: "party collection",
  slug: "gift-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/two/banner-mobile-3.jpg",
      width: 450,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/two/banner-3.jpg",
      width: 1450,
      height: 800
    }
  }
}]; // Demo Four -> Vintage Demo

const vintageDemoProductBanner = [{
  id: 1,
  title: "Sale Offer",
  slug: "flash-sale",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-sale-offer.jpg",
      width: 430,
      height: 600
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer.jpg",
      width: 430,
      height: 600
    }
  }
}, {
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-sale-offer-reverse.jpg",
      width: 430,
      height: 600
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer-reverse.jpg",
      width: 430,
      height: 600
    }
  }
}];
const vintageDemoBanner = [{
  id: 1,
  title: "New Backpack",
  slug: "new-backpack",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-6.png",
      width: 450,
      height: 180
    },
    desktop: {
      url: "/assets/images/banner/banner-6.jpg",
      width: 1800,
      height: 570
    }
  }
}, {
  id: 2,
  title: "Men's Collection",
  slug: "mens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-5.png",
      width: 480,
      height: 180
    },
    desktop: {
      url: "/assets/images/banner/banner-5.jpg",
      width: 1800,
      height: 570
    }
  }
}, {
  id: 3,
  title: "Offer Off Everything",
  slug: "winter-offer",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-4.jpg",
      width: 450,
      height: 130
    },
    desktop: {
      url: "/assets/images/banner/banner-4.jpg",
      width: 1800,
      height: 420
    }
  }
}];
const vintageDemoGridBanner = [{
  id: 1,
  title: "On Selected Items",
  slug: "on-sale",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/small/banner-mobile-1.jpg",
      width: 470,
      height: 190
    },
    desktop: {
      url: "/assets/images/banner/grid/small/banner-1.jpg",
      width: 980,
      height: 340
    }
  },
  type: "large"
}, {
  id: 2,
  title: "Casual Top",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/small/banner-mobile-2.jpg",
      width: 232,
      height: 190
    },
    desktop: {
      url: "/assets/images/banner/grid/small/banner-2.jpg",
      width: 480,
      height: 340
    }
  },
  type: "small"
}, {
  id: 3,
  title: "Branded Top",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/small/banner-mobile-3.jpg",
      width: 232,
      height: 190
    },
    desktop: {
      url: "/assets/images/banner/grid/small/banner-3.jpg",
      width: 480,
      height: 340
    }
  },
  type: "small"
}]; // Demo Five -> Classic Demo

const classicDemoBanner = [{
  id: 1,
  title: "Men's Collection",
  slug: "mens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-1.jpg",
      width: 470,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-1.jpg",
      width: 1078,
      height: 425
    }
  },
  type: "medium"
}, {
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-2.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-2.jpg",
      width: 425,
      height: 425
    }
  },
  type: "small"
}, {
  id: 3,
  title: "Dress Women",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-3.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-3.jpg",
      width: 425,
      height: 425
    }
  },
  type: "small"
}];
const classicDemoProductBanner = [{
  id: 1,
  title: "Sale Offer",
  slug: "flash-sale",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-sale-offer.jpg",
      width: 430,
      height: 600
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer.jpg",
      width: 430,
      height: 600
    }
  }
}, {
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-sale-offer-reverse.jpg",
      width: 430,
      height: 600
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer-reverse.jpg",
      width: 430,
      height: 600
    }
  }
}];
const classicDemoBannerTwo = [{
  id: 1,
  title: "Exclusive Sunglasses",
  slug: "exclusive-sunglasses",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-4.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-4.jpg",
      width: 425,
      height: 425
    }
  },
  type: "small"
}, {
  id: 2,
  title: "Product Coupons",
  slug: "product-coupons",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-5.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-5.jpg",
      width: 425,
      height: 425
    }
  },
  type: "small"
}, {
  id: 3,
  title: "New Backpack",
  slug: "new-backpack",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-6.jpg",
      width: 470,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-6.jpg",
      width: 1078,
      height: 425
    }
  },
  type: "medium"
}];
const classicDemoBannerThree = {
  id: 1,
  title: "Winter Collection of Kid Items",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-3.jpg",
      width: 450,
      height: 180
    },
    desktop: {
      url: "/assets/images/banner/banner-3.jpg",
      width: 1800,
      height: 570
    }
  }
};
const trendyDemoHeroBanner = [{
  id: 1,
  title: "winter collection",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/trendy/mobile/banner-1.jpg",
      width: 480,
      height: 275
    },
    desktop: {
      url: "/assets/images/banner/trendy/desktop/banner-1.jpg",
      width: 1800,
      height: 800
    }
  }
}, {
  id: 2,
  title: "gift collection",
  slug: "gift-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/trendy/mobile/banner-2.jpg",
      width: 480,
      height: 275
    },
    desktop: {
      url: "/assets/images/banner/trendy/desktop/banner-2.jpg",
      width: 1800,
      height: 800
    }
  }
}, {
  id: 3,
  title: "party collection",
  slug: "gift-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/trendy/mobile/banner-3.jpg",
      width: 480,
      height: 275
    },
    desktop: {
      url: "/assets/images/banner/trendy/desktop/banner-3.jpg",
      width: 1800,
      height: 800
    }
  }
}];
const saleBannerGrid = [{
  id: 1,
  title: "25% Discount on Selected Items",
  slug: "t-shirts-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/banner-mobile-4.jpg",
      width: 690,
      height: 360
    },
    desktop: {
      url: "/assets/images/banner/grid/banner-4.png",
      width: 885,
      height: 430
    }
  }
}, {
  id: 2,
  title: "30% Discount on Kids Items",
  slug: "jins-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/banner-mobile-5.jpg",
      width: 690,
      height: 360
    },
    desktop: {
      url: "/assets/images/banner/grid/banner-5.png",
      width: 885,
      height: 430
    }
  }
}];
const homeTrendyCoupons = [{
  id: 1,
  title: "We picked every item with care you must try",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-7.jpg",
      width: 690,
      height: 300
    },
    desktop: {
      url: "/assets/images/banner/banner-7.jpg",
      width: 1800,
      height: 800
    }
  }
}];
const homeTrendyProductWithBanner = [{
  id: 1,
  title: "We picked every item with care you must try",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-7.jpg",
      width: 690,
      height: 300
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer-half.jpg",
      width: 1800,
      height: 800
    }
  }
}, {
  id: 2,
  title: "We picked every item with care you must try",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-7.jpg",
      width: 690,
      height: 300
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer-half.jpg",
      width: 1800,
      height: 800
    }
  }
}];
const homeElegantHeroSlider = [{
  id: 1,
  title: "We picked every item with care you must try",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/banner-mobile-7.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/banner-7.jpg",
      width: 1920,
      height: 900
    }
  }
}, {
  id: 2,
  title: "We picked every item with care you must try",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/banner-mobile-8.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/banner-8.jpg",
      width: 1920,
      height: 900
    }
  }
}, {
  id: 3,
  title: "We picked every item with care you must try",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/banner-mobile-9.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/banner-9.jpg",
      width: 1920,
      height: 900
    }
  }
}];
const elegantBannerDataThree = [{
  id: 1,
  title: "Men's Collection",
  slug: "mens-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-7.jpg",
      width: 470,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-7.jpg",
      width: 980,
      height: 403
    }
  },
  type: "medium"
}, {
  id: 2,
  title: "New Kid's",
  slug: "new-kid's",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-8.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-8.jpg",
      width: 403,
      height: 403
    }
  },
  type: "small"
}, {
  id: 3,
  title: "Dress Women",
  slug: "dress-women",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-9.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-9.jpg",
      width: 403,
      height: 403
    }
  },
  type: "small"
}];
const elegantHomeBanner = {
  id: 1,
  title: "Winter Collection of Kid Items",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-8.jpg",
      width: 900,
      height: 540
    },
    desktop: {
      url: "/assets/images/banner/banner-8.jpg",
      width: 1800,
      height: 620
    }
  }
};
const homeRefinedHeroBanner = [{
  id: 1,
  title: "winter collection",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/two/banner-mobile-4.jpg",
      width: 450,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/two/banner-4.jpg",
      width: 1450,
      height: 800
    }
  }
}, {
  id: 2,
  title: "gift collection",
  slug: "gift-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/two/banner-mobile-2.jpg",
      width: 450,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/two/banner-2.jpg",
      width: 1450,
      height: 800
    }
  }
}, {
  id: 3,
  title: "party collection",
  slug: "party-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/two/banner-mobile-3.jpg",
      width: 450,
      height: 275
    },
    desktop: {
      url: "/assets/images/hero/two/banner-3.jpg",
      width: 1450,
      height: 800
    }
  }
}];
const saleBannerWithProducts = [{
  id: 1,
  title: "Sale Offer",
  slug: "sale-offer",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-sale-offer-half-mobile.jpg",
      width: 900,
      height: 400
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer-half.jpg",
      width: 1770,
      height: 780
    }
  }
}, {
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-sale-offer-half-mobile.jpg",
      width: 1770,
      height: 780
    },
    desktop: {
      url: "/assets/images/banner/banner-sale-offer-half.jpg",
      width: 1770,
      height: 780
    }
  }
}];
const bannerDataFour = [{
  id: 1,
  title: "Exclusive Sunglasses",
  slug: "exclusive-sunglasses",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-10.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-10.jpg",
      width: 403,
      height: 403
    }
  },
  type: "small"
}, {
  id: 2,
  title: "Summer Collection",
  slug: "summer-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-11.jpg",
      width: 470,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-11.jpg",
      width: 976,
      height: 403
    }
  },
  type: "medium"
}, {
  id: 3,
  title: "Dress Women",
  slug: "dress-women",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-9.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-9.jpg",
      width: 403,
      height: 403
    }
  },
  type: "small"
}];
const bannerDataFourMobile = [{
  id: 1,
  title: "Exclusive Sunglasses",
  slug: "exclusive-sunglasses",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-10.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-10.jpg",
      width: 403,
      height: 403
    }
  },
  type: "small"
}, {
  id: 2,
  title: "Dress Women",
  slug: "dress-women",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-9.jpg",
      width: 232,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-9.jpg",
      width: 403,
      height: 403
    }
  },
  type: "small"
}, {
  id: 3,
  title: "Summer Collection",
  slug: "summer-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/masonry/banner-mobile-11.jpg",
      width: 470,
      height: 232
    },
    desktop: {
      url: "/assets/images/banner/masonry/banner-11.jpg",
      width: 976,
      height: 403
    }
  },
  type: "medium"
}];
const homeEightWinterBanner = {
  id: 1,
  title: "Winter Clearance Sale",
  slug: "winter-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-10.jpg",
      width: 900,
      height: 420
    },
    desktop: {
      url: "/assets/images/banner/banner-10.jpg",
      width: 1800,
      height: 620
    }
  }
};
const homeEightCoupons = {
  id: 1,
  title: "20% OFF EVERYTHING",
  slug: "gift-collection",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-9.jpg",
      width: 900,
      height: 300
    },
    desktop: {
      url: "/assets/images/banner/banner-9.jpg",
      width: 1800,
      height: 480
    }
  }
};
const fashionHomeHeroGridSlider = [{
  id: 1,
  title: "Men's Collection",
  slug: "mens-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/small/banner-1.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/small/banner-1.jpg",
      width: 592,
      height: 770
    }
  }
}, {
  id: 2,
  title: "Kid's Collection",
  slug: "kids-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/small/banner-2.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/small/banner-2.jpg",
      width: 592,
      height: 770
    }
  }
}, {
  id: 3,
  title: "Women's Collection",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/small/banner-3.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/small/banner-3.jpg",
      width: 592,
      height: 770
    }
  }
}, {
  id: 4,
  title: "Men's Collection",
  slug: "mens-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/small/banner-1.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/small/banner-1.jpg",
      width: 592,
      height: 770
    }
  }
}, {
  id: 5,
  title: "Kid's Collection",
  slug: "kids-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/small/banner-2.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/small/banner-2.jpg",
      width: 592,
      height: 770
    }
  }
}, {
  id: 6,
  title: "Women's Collection",
  slug: "womens-collection",
  image: {
    mobile: {
      url: "/assets/images/hero/small/banner-3.jpg",
      width: 690,
      height: 480
    },
    desktop: {
      url: "/assets/images/hero/small/banner-3.jpg",
      width: 592,
      height: 770
    }
  }
}];
const fashionSaleBannerWithProducts = [{
  id: 1,
  title: "Sale Offer",
  slug: "sale-offer",
  image: {
    mobile: {
      url: "/assets/images/banner/fashion-sale-banner-1.png",
      width: 900,
      height: 400
    },
    desktop: {
      url: "/assets/images/banner/fashion-sale-banner-1.png",
      width: 1770,
      height: 780
    }
  }
}, {
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/fashion-sale-banner-2.png",
      width: 1770,
      height: 780
    },
    desktop: {
      url: "/assets/images/banner/fashion-sale-banner-2.png",
      width: 1770,
      height: 780
    }
  }
}];
const fashionSaleBannerData = [{
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/fashion-demo-banner.png",
      width: 1800,
      height: 621
    },
    desktop: {
      url: "/assets/images/banner/fashion-demo-banner.png",
      width: 1800,
      height: 621
    }
  }
}];
const fashionSaleBannerDataGallery = [{
  id: 1,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/banner-fashion-1.png",
      width: 592,
      height: 403
    },
    desktop: {
      url: "/assets/images/banner/grid/banner-fashion-1.png",
      width: 592,
      height: 403
    }
  }
}, {
  id: 2,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/banner-fashion-2.png",
      width: 592,
      height: 403
    },
    desktop: {
      url: "/assets/images/banner/grid/banner-fashion-2.png",
      width: 592,
      height: 403
    }
  }
}, {
  id: 3,
  title: "New Sports",
  slug: "new-sports",
  image: {
    mobile: {
      url: "/assets/images/banner/grid/banner-fashion-3.png",
      width: 592,
      height: 403
    },
    desktop: {
      url: "/assets/images/banner/grid/banner-fashion-3.png",
      width: 592,
      height: 403
    }
  }
}];

/***/ }),

/***/ 7640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ filterBrands),
/* harmony export */   "z": () => (/* binding */ filterBrandImages)
/* harmony export */ });
/**
 * Helper methods to filter brands
 *
 * @param brands
 * @param layout
 */
const filterBrands = (brands, layout) => {
  if (!brands) {
    return [];
  }

  const filterBrands = [];
  brands === null || brands === void 0 ? void 0 : brands.map(brand => {
    var _brand$images;

    brand === null || brand === void 0 ? void 0 : (_brand$images = brand.images) === null || _brand$images === void 0 ? void 0 : _brand$images.map(image => {
      if (image.key === layout) {
        filterBrands.push(brand);
        return false;
      }
    });
  });
  return filterBrands;
};
const filterBrandImages = (images, layout) => {
  return images === null || images === void 0 ? void 0 : images.find(image => image.key === layout);
};

/***/ }),

/***/ 7122:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ getCategoryTypeImage)
/* harmony export */ });
const getCategoryTypeImage = (category, variant = "image") => {
  const {
    image
  } = category;
  if (!(image !== null && image !== void 0 && image.length)) return null;

  if (variant === "vector" && (image === null || image === void 0 ? void 0 : image.length) > 1) {
    return image[1];
  }

  return image[0];
};

/***/ })

};
;