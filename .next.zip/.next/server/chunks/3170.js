"use strict";
exports.id = 3170;
exports.ids = [3170];
exports.modules = {

/***/ 6203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Search)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react-content-loader"
var external_react_content_loader_ = __webpack_require__(9081);
var external_react_content_loader_default = /*#__PURE__*/__webpack_require__.n(external_react_content_loader_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/loaders/search-result-loader.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const SearchResultLoader = props => /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_content_loader_default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 846,
  height: 96,
  viewBox: "0 0 846 96",
  backgroundColor: "#f3f3f3",
  foregroundColor: "#eaeaea",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "118",
    y: "31",
    rx: "3",
    ry: "3",
    width: "120",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "118",
    y: "59",
    rx: "3",
    ry: "3",
    width: "80",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "96",
    height: "96"
  })]
}));

/* harmony default export */ const search_result_loader = (SearchResultLoader);
// EXTERNAL MODULE: ./src/components/ui/image.tsx
var ui_image = __webpack_require__(6126);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: ./src/components/icons/search-icon.tsx
var search_icon = __webpack_require__(8244);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "@react-icons/all-files/io5/IoCloseOutline"
var IoCloseOutline_ = __webpack_require__(6545);
;// CONCATENATED MODULE: ./src/components/common/search-box.tsx
const _excluded = ["className", "onSubmit", "onClear"];

function search_box_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function search_box_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { search_box_ownKeys(Object(source), true).forEach(function (key) { search_box_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { search_box_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function search_box_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }







const SearchBox = /*#__PURE__*/external_react_default().forwardRef((_ref, ref) => {
  let {
    className,
    onSubmit,
    onClear
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("forms");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
    className: "relative ltr:pr-12 rtl:pl-12 ltr:md:pr-14 rtl:md:pl-14 bg-white overflow-hidden rounded-md w-full",
    noValidate: true,
    role: "search",
    onSubmit: onSubmit,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("label", {
      htmlFor: "search",
      className: "flex items-center py-0.5",
      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "w-12 md:w-14 h-full flex flex-shrink-0 justify-center items-center cursor-pointer focus:outline-none",
        children: /*#__PURE__*/jsx_runtime_.jsx(search_icon/* default */.Z, {
          color: "text-heading",
          className: "w-4 h-4"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("input", search_box_objectSpread({
        id: "search",
        className: "text-heading outline-none w-full h-12 lg:h-14 placeholder-gray-400 text-sm lg:text-base",
        placeholder: t("placeholder-search"),
        "aria-label": "Search",
        autoComplete: "off",
        ref: ref
      }, rest))]
    }), /*#__PURE__*/jsx_runtime_.jsx("button", {
      type: "button",
      className: "outline-none text-2xl md:text-3xl text-gray-400 absolute top-0 ltr:right-0 rtl:left-0 w-12 md:w-14 h-full flex items-center justify-center transition duration-200 ease-in-out hover:text-heading focus:outline-none",
      onClick: onClear,
      children: /*#__PURE__*/jsx_runtime_.jsx(IoCloseOutline_.IoCloseOutline, {
        className: "w-6 h-6"
      })
    })]
  });
});
/* harmony default export */ const search_box = (SearchBox);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: external "body-scroll-lock"
var external_body_scroll_lock_ = __webpack_require__(8023);
// EXTERNAL MODULE: ./src/components/common/scrollbar.tsx
var scrollbar = __webpack_require__(7654);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: ./src/lib/use-price.ts
var use_price = __webpack_require__(7259);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/product/product-variant-price.tsx
var product_variant_price = __webpack_require__(7615);
// EXTERNAL MODULE: ./src/framework/rest/utils/get-variations.ts
var get_variations = __webpack_require__(2347);
;// CONCATENATED MODULE: ./src/components/common/search-product.tsx












const SearchProduct = ({
  item
}) => {
  var _item$image$original, _item$image;

  const {
    price,
    basePrice
  } = (0,use_price/* default */.ZP)({
    amount: item !== null && item !== void 0 && item.sale_price ? item === null || item === void 0 ? void 0 : item.sale_price : item === null || item === void 0 ? void 0 : item.price,
    baseAmount: item === null || item === void 0 ? void 0 : item.price
  });
  const variations = (0,get_variations/* getVariations */.y)(item === null || item === void 0 ? void 0 : item.variations);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
    href: `${routes/* ROUTES.PRODUCT */.Z.PRODUCT}/${item === null || item === void 0 ? void 0 : item.slug}`,
    className: "group w-full h-auto flex justify-start items-center",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "relative flex w-16 md:w-24 h-16 md:h-24 rounded-md overflow-hidden bg-gray-200 flex-shrink-0 cursor-pointer ltr:mr-4 rtl:ml-4",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: (_item$image$original = item === null || item === void 0 ? void 0 : (_item$image = item.image) === null || _item$image === void 0 ? void 0 : _item$image.original) !== null && _item$image$original !== void 0 ? _item$image$original : "/assets/placeholder/search-product.svg",
        width: 96,
        height: 96,
        loading: "eager",
        alt: item.name || "Product Image",
        className: "bg-gray-200 object-cover"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col w-full overflow-hidden",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: "truncate text-sm text-heading mb-2",
        children: item.name
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-heading font-semibold text-sm",
        children: !isEmpty_default()(variations) ? /*#__PURE__*/jsx_runtime_.jsx(product_variant_price/* default */.Z, {
          minPrice: item.min_price,
          maxPrice: item.max_price,
          basePriceClassName: "text-heading font-semibold text-sm",
          discountPriceClassName: "ltr:pl-2 rtl:pr-2 text-gray-400 font-normal"
        }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "text-heading font-semibold text-sm",
            children: [price, basePrice && /*#__PURE__*/jsx_runtime_.jsx("del", {
              className: "ltr:pl-2 rtl:pr-2 text-gray-400 font-normal",
              children: basePrice
            })]
          })
        })
      })]
    })]
  });
};

/* harmony default export */ const search_product = (SearchProduct);
// EXTERNAL MODULE: ./src/assets/not-found.svg
var not_found = __webpack_require__(8392);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
;// CONCATENATED MODULE: ./src/components/common/search.tsx


















function Search() {
  var _data$pages$, _data$pages$2, _data$pages, _data$pages$3, _data$pages$3$paginat;

  const router = (0,router_.useRouter)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    displaySearch,
    closeSearch
  } = (0,ui_context/* useUI */.l8)();
  const [searchText, setSearchText] = external_react_default().useState("");
  const {
    data,
    isLoading: loading
  } = (0,products_query/* useProductsInfiniteQuery */.Ue)({
    text: searchText,
    limit: 4
  });

  function handleSearch(e) {
    e.preventDefault();
  }

  function handleAutoSearch(e) {
    setSearchText(e.currentTarget.value);
  }

  function clear() {
    if (searchText) {
      setSearchText("");
    } else {
      setSearchText("");
      closeSearch();
    }
  }

  function handleOnLoadMore() {
    // Clear Search
    setSearchText("");
    closeSearch(); // Redirect to search page

    router.push(`${routes/* ROUTES.SEARCH */.Z.SEARCH}?q=${searchText}`);
  }

  const ref = (0,external_react_.useRef)(null);
  (0,external_react_.useEffect)(() => {
    if (ref.current) {
      if (displaySearch) {
        (0,external_body_scroll_lock_.disableBodyScroll)(ref.current);
      } else {
        (0,external_body_scroll_lock_.enableBodyScroll)(ref.current);
      }
    }

    return () => {
      (0,external_body_scroll_lock_.clearAllBodyScrollLocks)();
    };
  }, [displaySearch]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    ref: ref,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: external_classnames_default()("overlay", {
        open: displaySearch
      }),
      role: "button",
      onClick: closeSearch
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: external_classnames_default()("drawer-search relative hidden top-0 z-30 opacity-0 invisible transition duration-300 ease-in-out left-1/2 px-4 w-full md:w-[730px] lg:w-[930px]", {
        open: displaySearch
      }),
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "w-full flex flex-col justify-center",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-shrink-0 mt-3.5 lg:mt-4 w-full",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex flex-col mx-auto mb-1.5 w-full ",
            children: /*#__PURE__*/jsx_runtime_.jsx(search_box, {
              onSubmit: handleSearch,
              onChange: handleAutoSearch,
              name: "search",
              value: searchText,
              onClear: clear,
              ref: input => input && input.focus()
            })
          }), searchText && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "bg-white flex flex-col rounded-md overflow-hidden h-full max-h-64vh",
            children: /*#__PURE__*/jsx_runtime_.jsx(scrollbar/* default */.Z, {
              className: "os-host-flexbox",
              children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "h-full",
                children: loading ? Array.from({
                  length: 4
                }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "p-4 md:p-5 border-b order-gray-150 last:border-b-0",
                  children: /*#__PURE__*/jsx_runtime_.jsx(search_result_loader, {
                    uniqueKey: `top-search-${idx}`
                  })
                }, idx)) : data !== null && data !== void 0 && (_data$pages$ = data.pages[0]) !== null && _data$pages$ !== void 0 && _data$pages$.data.length ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                  children: [data === null || data === void 0 ? void 0 : (_data$pages$2 = data.pages[0]) === null || _data$pages$2 === void 0 ? void 0 : _data$pages$2.data.map((item, index) => /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "p-4 md:p-5 border-b border-gray-150 relative last:border-b-0",
                    onClick: closeSearch,
                    children: /*#__PURE__*/jsx_runtime_.jsx(search_product, {
                      item: item
                    }, index)
                  }, item === null || item === void 0 ? void 0 : item.id)), (data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : (_data$pages$3 = _data$pages[0]) === null || _data$pages$3 === void 0 ? void 0 : (_data$pages$3$paginat = _data$pages$3.paginatorInfo) === null || _data$pages$3$paginat === void 0 ? void 0 : _data$pages$3$paginat.total) > 4 && /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: "w-full overflow-hidden border-t border-gray-150",
                    children: /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
                      variant: "custom",
                      onClick: handleOnLoadMore,
                      className: "w-full block text-sm md:text-base text-center px-4 py-3 lg:py-3.5 bg-gray-200 text-heading text-opacity-80 transition hover:text-opacity-100",
                      children: t("text-load-more-products")
                    })
                  })]
                }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "w-full h-full px-5 md:px-10 mb-4 md:pb-6 pt-8 md:pt-12 flex items-center justify-center",
                  children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: " flex items-center justify-center max-w-[520px]",
                    children: /*#__PURE__*/jsx_runtime_.jsx(ui_image/* Image */.E, {
                      src: not_found/* default */.Z,
                      alt: t("text-no-result-found"),
                      className: "object-contain"
                    })
                  })
                })
              })
            })
          })]
        })
      })
    })]
  });
}

/***/ }),

/***/ 8244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const SearchIcon = ({
  color = "currentColor",
  width = "17px",
  height = "18px",
  className = "md:w-4 xl:w-5 md:h-4 xl:h-5"
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 18.942 20",
    className: className,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
      d: "M381.768,385.4l3.583,3.576c.186.186.378.366.552.562a.993.993,0,1,1-1.429,1.375c-1.208-1.186-2.422-2.368-3.585-3.6a1.026,1.026,0,0,0-1.473-.246,8.343,8.343,0,1,1-3.671-15.785,8.369,8.369,0,0,1,6.663,13.262C382.229,384.815,382.025,385.063,381.768,385.4Zm-6.152.579a6.342,6.342,0,1,0-6.306-6.355A6.305,6.305,0,0,0,375.615,385.983Z",
      transform: "translate(-367.297 -371.285)",
      fill: color,
      fillRule: "evenodd"
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchIcon);

/***/ }),

/***/ 7855:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports FacebookIcon, InstagramIcon, TwitterIcon, YouTubeIcon */
/* harmony import */ var _react_icons_all_files_io5_IoLogoInstagram__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4341);
/* harmony import */ var _react_icons_all_files_io5_IoLogoInstagram__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_react_icons_all_files_io5_IoLogoInstagram__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _react_icons_all_files_io5_IoLogoFacebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9199);
/* harmony import */ var _react_icons_all_files_io5_IoLogoFacebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_react_icons_all_files_io5_IoLogoFacebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_icons_all_files_io5_IoLogoTwitter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2243);
/* harmony import */ var _react_icons_all_files_io5_IoLogoTwitter__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_icons_all_files_io5_IoLogoTwitter__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _react_icons_all_files_io5_IoLogoYoutube__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3391);
/* harmony import */ var _react_icons_all_files_io5_IoLogoYoutube__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_react_icons_all_files_io5_IoLogoYoutube__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);





const FacebookIcon = () => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_react_icons_all_files_io5_IoLogoFacebook__WEBPACK_IMPORTED_MODULE_1__.IoLogoFacebook, {});
const InstagramIcon = () => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_react_icons_all_files_io5_IoLogoInstagram__WEBPACK_IMPORTED_MODULE_0__.IoLogoInstagram, {});
const TwitterIcon = () => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_react_icons_all_files_io5_IoLogoTwitter__WEBPACK_IMPORTED_MODULE_2__.IoLogoTwitter, {});
const YouTubeIcon = () => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_react_icons_all_files_io5_IoLogoYoutube__WEBPACK_IMPORTED_MODULE_3__.IoLogoYoutube, {});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  FacebookIcon,
  InstagramIcon,
  TwitterIcon,
  YouTubeIcon
});

/***/ }),

/***/ 9308:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer_footer)
});

// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ../node_modules/next/link.js
var next_link = __webpack_require__(9894);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/widgets/widget-link.tsx





const WidgetLink = ({
  className,
  data
}) => {
  const {
    widgetTitle,
    lists
  } = data;
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("footer");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `${className}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
      className: "text-heading text-sm md:text-base xl:text-lg font-semibold mb-5 2xl:mb-6 3xl:mb-7",
      children: t(`${widgetTitle}`)
    }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
      className: "text-xs md:text-[13px] lg:text-sm text-body flex flex-col space-y-3 lg:space-y-3.5",
      children: lists.map(list => /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
        className: "flex items-baseline",
        children: [list.icon && /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ltr:mr-3 rtl:ml-3 relative top-0.5 lg:top-1 text-sm lg:text-base",
          children: list.icon
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: list.path ? list.path : "#!",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: "transition-colors duration-200 hover:text-black",
            children: t(`${list.title}`)
          })
        })]
      }, `widget-list--key${list.id}`))
    })]
  });
};

/* harmony default export */ const widget_link = (WidgetLink);
// EXTERNAL MODULE: ./src/contexts/settings.context.tsx
var settings_context = __webpack_require__(3792);
// EXTERNAL MODULE: ./src/components/icons/social-icon.tsx
var social_icon = __webpack_require__(7855);
// EXTERNAL MODULE: ./src/lib/get-icon.tsx
var get_icon = __webpack_require__(8473);
;// CONCATENATED MODULE: ./src/components/widgets/widget-social.tsx








const WidgetSocial = () => {
  var _settings$contactDeta;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const settings = (0,settings_context/* useSettings */.rV)();
  const socials = settings === null || settings === void 0 ? void 0 : (_settings$contactDeta = settings.contactDetails) === null || _settings$contactDeta === void 0 ? void 0 : _settings$contactDeta.socials;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
      className: "text-heading text-sm md:text-base xl:text-lg font-semibold mb-5 2xl:mb-6 3xl:mb-7",
      children: t(`footer:widget-title-social`)
    }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
      className: "text-xs md:text-[13px] lg:text-sm text-body flex flex-col space-y-3 lg:space-y-3.5",
      children: socials === null || socials === void 0 ? void 0 : socials.map((social, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
        className: "flex items-baseline",
        children: [social.icon && /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ltr:mr-3 rtl:ml-3 relative top-0.5 lg:top-1 text-sm lg:text-base",
          children: (0,get_icon/* getIcon */.q)({
            iconList: social_icon/* default */.ZP,
            iconName: social === null || social === void 0 ? void 0 : social.icon
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: social.url ? social.url : "#!",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: "transition-colors duration-200 hover:text-black",
            children: social !== null && social !== void 0 && social.label ? social === null || social === void 0 ? void 0 : social.label : social === null || social === void 0 ? void 0 : social.url
          })
        })]
      }, `widget-list--key${index}`))
    })]
  });
};

/* harmony default export */ const widget_social = (WidgetSocial);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
;// CONCATENATED MODULE: ./src/components/widgets/widget-contact.tsx







const WidgetContact = () => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const settings = (0,settings_context/* useSettings */.rV)();
  const contactDetails = settings === null || settings === void 0 ? void 0 : settings.contactDetails;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
      className: "text-heading text-sm md:text-base xl:text-lg font-semibold mb-5 2xl:mb-6 3xl:mb-7",
      children: t(`text-contact`)
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
      className: "text-xs md:text-[13px] lg:text-sm text-body flex flex-col space-y-3 lg:space-y-3.5",
      children: [(routes/* ROUTES */.Z === null || routes/* ROUTES */.Z === void 0 ? void 0 : routes/* ROUTES.CONTACT */.Z.CONTACT) && /*#__PURE__*/jsx_runtime_.jsx("li", {
        className: "flex items-baseline",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: routes/* ROUTES.CONTACT */.Z.CONTACT,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: "transition-colors duration-200 hover:text-black",
            children: t(`text-page-contact-us`)
          })
        })
      }), (contactDetails === null || contactDetails === void 0 ? void 0 : contactDetails.email) && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
        className: "flex items-baseline",
        children: [t("text-email"), ": ", contactDetails.email]
      }), (contactDetails === null || contactDetails === void 0 ? void 0 : contactDetails.website) && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
        className: "flex items-baseline",
        children: [t("text-website"), ":", /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: contactDetails.website,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: "transition-colors duration-200 hover:text-black ml-1",
            children: contactDetails.website
          })
        })]
      })]
    })]
  });
};

/* harmony default export */ const widget_contact = (WidgetContact);
;// CONCATENATED MODULE: ./src/components/layout/footer/widgets.tsx







const Widgets = ({
  widgets
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(container/* default */.Z, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-5 md:gap-9 lg:gap-x-8 xl:gap-5  pb-9 md:pb-14 lg:pb-16 2xl:pb-20 3xl:pb-24 lg:mb-0.5 2xl:mb-0 3xl:-mb-1",
      children: [/*#__PURE__*/jsx_runtime_.jsx(widget_social, {}), /*#__PURE__*/jsx_runtime_.jsx(widget_contact, {}), widgets.map((widget, index) => /*#__PURE__*/jsx_runtime_.jsx(widget_link, {
        data: widget
      }, `widget-link-${index}`))]
    })
  });
};

/* harmony default export */ const widgets = (Widgets);
// EXTERNAL MODULE: ./src/settings/site.settings.tsx + 6 modules
var site_settings = __webpack_require__(5278);
;// CONCATENATED MODULE: ./src/components/layout/footer/copyright.tsx





const year = new Date().getFullYear();

const Copyright = ({
  payment
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('footer');
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "border-t border-gray-300 pt-5 pb-16 sm:pb-20 md:pb-5 mb-2 sm:mb-0",
    children: /*#__PURE__*/jsx_runtime_.jsx(container/* default */.Z, {
      className: "flex flex-col-reverse md:flex-row text-center md:justify-between",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
        className: "text-body text-xs md:text-[13px] lg:text-sm leading-6",
        children: [t('text-copyright'), " \xA9 ", year, "\xA0", /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: "font-semibold text-gray-700 transition-colors duration-200 ease-in-out hover:text-body",
          href: site_settings/* siteSettings.author.websiteUrl */.U.author.websiteUrl,
          children: site_settings/* siteSettings.author.name */.U.author.name
        }), "\xA0 ", t('text-all-rights-reserved')]
      })
    })
  });
};

/* harmony default export */ const copyright = (Copyright);
;// CONCATENATED MODULE: ./src/components/layout/footer/data.tsx
const footer = {
  widgets: [{
    id: 3,
    widgetTitle: "widget-title-about",
    lists: [{
      id: 1,
      title: "link-support-center",
      path: "/"
    }, {
      id: 2,
      title: "link-customer-support",
      path: "/"
    }, {
      id: 3,
      title: "link-about-us",
      path: "/"
    }, {
      id: 4,
      title: "link-copyright",
      path: "/"
    }]
  }, {
    id: 4,
    widgetTitle: "widget-title-customer-care",
    lists: [{
      id: 1,
      title: "link-faq",
      path: "/faq"
    }, {
      id: 2,
      title: "link-shipping",
      path: "/"
    }, {
      id: 3,
      title: "link-exchanges",
      path: "/"
    }]
  }, {
    id: 5,
    widgetTitle: "widget-title-our-information",
    lists: [{
      id: 1,
      title: "link-privacy",
      path: "/privacy"
    }, {
      id: 2,
      title: "link-terms",
      path: "/terms"
    }, {
      id: 3,
      title: "link-return-policy",
      path: "/privacy"
    }, {
      id: 4,
      title: "link-site-map",
      path: "/"
    }]
  }, {
    id: 3,
    widgetTitle: 'widget-title-community',
    lists: [{
      id: 1,
      title: 'link-announcements',
      path: '/'
    }, {
      id: 2,
      title: 'link-answer-center',
      path: '/'
    }, {
      id: 3,
      title: 'link-discussion-boards',
      path: '/'
    }, {
      id: 4,
      title: 'link-giving-works',
      path: '/'
    }]
  }],
  payment: [{
    id: 1,
    path: "/",
    image: "/assets/images/payment/mastercard.png",
    name: "payment-master-card",
    width: 34,
    height: 20
  }, {
    id: 2,
    path: "/",
    image: "/assets/images/payment/visa.png",
    name: "payment-visa",
    width: 50,
    height: 20
  }, {
    id: 3,
    path: "/",
    image: "/assets/images/payment/paypal.png",
    name: "payment-paypal",
    width: 76,
    height: 20
  }, {
    id: 4,
    path: "/",
    image: "/assets/images/payment/jcb.png",
    name: "payment-jcb",
    width: 26,
    height: 20
  }, {
    id: 5,
    path: "/",
    image: "/assets/images/payment/skrill.png",
    name: "payment-skrill",
    width: 39,
    height: 20
  }]
};
;// CONCATENATED MODULE: ./src/components/layout/footer/footer.tsx





const {
  widgets: footer_widgets,
  payment
} = footer;

const Footer = () => /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
  className: "border-b-4 border-heading mt-9 md:mt-11 lg:mt-16 3xl:mt-20 pt-2.5 lg:pt-0 2xl:pt-2",
  children: [/*#__PURE__*/jsx_runtime_.jsx(widgets, {
    widgets: footer_widgets
  }), /*#__PURE__*/jsx_runtime_.jsx(copyright, {
    payment: payment
  })]
});

/* harmony default export */ const footer_footer = (Footer);

/***/ }),

/***/ 1395:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ header)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/components/icons/search-icon.tsx
var search_icon = __webpack_require__(8244);
// EXTERNAL MODULE: ./src/components/ui/logo.tsx
var logo = __webpack_require__(4386);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
;// CONCATENATED MODULE: ./src/utils/add-active-scroll.ts

function addActiveScroll(ref, topOffset = 0) {
  (0,external_react_.useEffect)(() => {
    const element = ref === null || ref === void 0 ? void 0 : ref.current;

    const listener = () => {
      if (window.scrollY > topOffset) {
        element === null || element === void 0 ? void 0 : element.classList.add('is-scrolling');
      } else {
        element === null || element === void 0 ? void 0 : element.classList.remove('is-scrolling');
      }
    };

    document.addEventListener('scroll', listener);
    return () => {
      document.removeEventListener('scroll', listener);
    };
  }, []);
}
// EXTERNAL MODULE: ../node_modules/next/dynamic.js
var dynamic = __webpack_require__(5218);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "jotai"
var external_jotai_ = __webpack_require__(8250);
// EXTERNAL MODULE: ./src/store/authorization-atom.ts
var authorization_atom = __webpack_require__(8879);
// EXTERNAL MODULE: ./src/data/static/menus.ts
var menus = __webpack_require__(9038);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: external "@react-icons/all-files/fa/FaChevronDown"
var FaChevronDown_ = __webpack_require__(2731);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/mega-menu.tsx






const MegaMenu = ({
  columns
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("menu");
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "megaMenu shadow-header bg-gray-200 absolute ltr:-left-20 rtl:-right-20 ltr:xl:left-0 rtl:xl:right-0 opacity-0 invisible group-hover:opacity-100 group-hover:visible",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "grid grid-cols-5",
      children: columns === null || columns === void 0 ? void 0 : columns.map(column => {
        var _column$columnItems;

        return /*#__PURE__*/jsx_runtime_.jsx("ul", {
          className: "even:bg-gray-150 pb-7 2xl:pb-8 pt-6 2xl:pt-7",
          children: column === null || column === void 0 ? void 0 : (_column$columnItems = column.columnItems) === null || _column$columnItems === void 0 ? void 0 : _column$columnItems.map(columnItem => {
            var _columnItem$columnIte;

            return /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
              children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                className: "mb-1.5",
                children: /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
                  href: columnItem.path,
                  className: "block text-sm py-1.5 text-heading font-semibold px-5 xl:px-8 2xl:px-10 hover:text-heading hover:bg-gray-300",
                  children: t(columnItem.label)
                })
              }), columnItem === null || columnItem === void 0 ? void 0 : (_columnItem$columnIte = columnItem.columnItemItems) === null || _columnItem$columnIte === void 0 ? void 0 : _columnItem$columnIte.map(item => {
                var _columnItem$columnIte2;

                return /*#__PURE__*/jsx_runtime_.jsx("li", {
                  className: (columnItem === null || columnItem === void 0 ? void 0 : (_columnItem$columnIte2 = columnItem.columnItemItems) === null || _columnItem$columnIte2 === void 0 ? void 0 : _columnItem$columnIte2.length) === item.id ? "border-b border-gray-300 pb-3.5 mb-3" : "",
                  children: /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
                    href: item.path,
                    className: "text-body text-sm block py-1.5 px-5 xl:px-8 2xl:px-10 hover:text-heading hover:bg-gray-300",
                    children: t(item.label)
                  })
                }, item.id);
              })]
            }, columnItem.id);
          })
        }, column.id);
      })
    })
  });
};

/* harmony default export */ const mega_menu = (MegaMenu);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "@react-icons/all-files/io/IoIosArrowForward"
var IoIosArrowForward_ = __webpack_require__(7379);
;// CONCATENATED MODULE: ./src/components/ui/list-menu.tsx






const ListMenu = ({
  dept,
  data,
  hasSubMenu,
  menuIndex
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("menu");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
    className: "relative",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
      href: data.path,
      className: "flex items-center justify-between py-2 ltr:pl-5 rtl:pr-5 ltr:xl:pl-7 rtl:xl:pr-7 ltr:pr-3 ltr:xl:pr-3.5 rtl:pl-3 rtl:xl:pl-3.5 hover:text-heading hover:bg-gray-300",
      children: [t(data.label), data.subMenu && /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "text-sm mt-0.5 shrink-0",
        children: /*#__PURE__*/jsx_runtime_.jsx(IoIosArrowForward_.IoIosArrowForward, {
          className: "text-body transition duration-300 ease-in-out group-hover:text-black"
        })
      })]
    }), hasSubMenu && /*#__PURE__*/jsx_runtime_.jsx(SubMenu, {
      dept: dept,
      data: data.subMenu,
      menuIndex: menuIndex
    })]
  });
};

const SubMenu = ({
  dept,
  data,
  menuIndex
}) => {
  dept = dept + 1;
  return /*#__PURE__*/jsx_runtime_.jsx("ul", {
    className: "subMenuChild shadow-subMenu bg-gray-200 absolute z-0 ltr:right-full ltr:2xl:right-auto rtl:left-full rtl:2xl:left-auto ltr:2xl:left-full rtl:2xl:right-full opacity-0 invisible top-4 w-56 py-3",
    children: data === null || data === void 0 ? void 0 : data.map((menu, index) => {
      const menuName = `sidebar-submenu-${dept}-${menuIndex}-${index}`;
      return /*#__PURE__*/jsx_runtime_.jsx(ListMenu, {
        dept: dept,
        data: menu,
        hasSubMenu: menu.subMenu,
        menuName: menuName,
        menuIndex: index
      }, menuName);
    })
  });
};

/* harmony default export */ const list_menu = (ListMenu);
;// CONCATENATED MODULE: ./src/components/layout/header/header-menu.tsx










const HeaderMenu = ({
  data,
  className
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("menu");
  return /*#__PURE__*/jsx_runtime_.jsx("nav", {
    className: external_classnames_default()(`headerMenu flex w-full relative`, className),
    children: data === null || data === void 0 ? void 0 : data.map(item => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `menuItem group cursor-pointer py-7 ${item.subMenu ? "relative" : ""}`,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
        href: item.path,
        className: "inline-flex items-center text-sm xl:text-base text-heading px-3 xl:px-4 py-2 font-normal relative group-hover:text-black",
        children: [t(item.label), ((item === null || item === void 0 ? void 0 : item.columns) || item.subMenu) && /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "opacity-30 text-xs mt-1 xl:mt-0.5 w-4 flex justify-end",
          children: /*#__PURE__*/jsx_runtime_.jsx(FaChevronDown_.FaChevronDown, {
            className: "transition duration-300 ease-in-out transform group-hover:-rotate-180"
          })
        })]
      }), (item === null || item === void 0 ? void 0 : item.columns) && Array.isArray(item.columns) && /*#__PURE__*/jsx_runtime_.jsx(mega_menu, {
        columns: item.columns
      }), (item === null || item === void 0 ? void 0 : item.subMenu) && Array.isArray(item.subMenu) && /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "subMenu shadow-header bg-gray-200 absolute ltr:left-0 rtl:right-0 opacity-0 group-hover:opacity-100",
        children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
          className: "text-body text-sm py-5",
          children: item.subMenu.map((menu, index) => {
            const dept = 1;
            const menuName = `sidebar-menu-${dept}-${index}`;
            return /*#__PURE__*/jsx_runtime_.jsx(list_menu, {
              dept: dept,
              data: menu,
              hasSubMenu: menu.subMenu,
              menuName: menuName,
              menuIndex: index
            }, menuName);
          })
        })
      })]
    }, item.id))
  });
};

/* harmony default export */ const header_menu = (HeaderMenu);
;// CONCATENATED MODULE: ./src/components/layout/header/header.tsx















const AuthMenu = (0,dynamic.default)(() => __webpack_require__.e(/* import() */ 1316).then(__webpack_require__.bind(__webpack_require__, 1316)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(1316)],
    modules: ["../components/layout/header/header.tsx -> " + './auth-menu']
  }
});
const CartButton = (0,dynamic.default)(() => __webpack_require__.e(/* import() */ 9039).then(__webpack_require__.bind(__webpack_require__, 9039)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(9039)],
    modules: ["../components/layout/header/header.tsx -> " + '@components/cart/cart-button']
  }
});

const Header = ({
  variant = 'default'
}) => {
  const {
    openSidebar,
    setDrawerView,
    openSearch,
    openModal,
    setModalView
  } = (0,ui_context/* useUI */.l8)();
  const [isAuthorize] = (0,external_jotai_.useAtom)(authorization_atom/* authorizationAtom */.O);
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  const siteHeaderRef = (0,external_react_.useRef)();
  addActiveScroll(siteHeaderRef);

  function handleLogin() {
    setModalView('LOGIN_VIEW');
    return openModal();
  }

  function handleMobileMenu() {
    setDrawerView('MOBILE_MENU');
    return openSidebar();
  }

  return /*#__PURE__*/jsx_runtime_.jsx("header", {
    id: "siteHeader",
    ref: siteHeaderRef,
    className: "w-full h-16 sm:h-20 lg:h-24 relative z-20",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "innerSticky text-gray-700 body-font fixed bg-white w-full h-16 sm:h-20 lg:h-24 z-20 ltr:pl-4 ltr:lg:pl-6 ltr:pr-4 ltr:lg:pr-6 rtl:pr-4 rtl:lg:pr-6 rtl:pl-4 rtl:lg:pl-6 transition duration-200 ease-in-out",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-center mx-auto max-w-[1920px] h-full w-full",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          "aria-label": "Menu",
          className: `menuBtn md:flex ${variant !== 'modern' ? 'hidden lg:hidden px-5 2xl:px-7' : 'ltr:pr-7 rtl:pl-7 hidden md:block'} flex-col items-center justify-center flex-shrink-0 h-full outline-none focus:outline-none`,
          onClick: handleMobileMenu,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: "menuIcon",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "bar"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "bar"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "bar"
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(logo/* default */.Z, {}), variant !== 'modern' ? /*#__PURE__*/jsx_runtime_.jsx(header_menu, {
          data: menus/* menu */.G,
          className: "hidden lg:flex ltr:md:ml-6 ltr:xl:ml-10 rtl:md:mr-6 rtl:xl:mr-10"
        }) : '', /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "hidden md:flex justify-end items-center space-x-6 lg:space-x-5 xl:space-x-8 2xl:space-x-10 rtl:space-x-reverse ltr:ml-auto rtl:mr-auto flex-shrink-0",
          children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
            className: "flex items-center justify-center flex-shrink-0 h-auto relative focus:outline-none transform",
            onClick: openSearch,
            "aria-label": "search-button",
            children: /*#__PURE__*/jsx_runtime_.jsx(search_icon/* default */.Z, {})
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "-mt-0.5 flex-shrink-0",
            children: /*#__PURE__*/jsx_runtime_.jsx(AuthMenu, {
              isAuthorized: isAuthorize,
              href: routes/* ROUTES.ACCOUNT */.Z.ACCOUNT,
              className: "text-sm xl:text-base text-heading font-semibold",
              btnProps: {
                className: 'text-sm xl:text-base text-heading font-semibold focus:outline-none',
                children: t('text-sign-in'),
                onClick: handleLogin
              },
              children: t('text-page-my-account')
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(CartButton, {}), /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
            type: "button" //   loading={loading}
            //   disabled={loading}
            ,
            className: "h-11 md:h-12 w-full mt-1.5",
            onClick: () => window.location.href = 'http://localhost:3002',
            children: "Become Vendor"
          })]
        })]
      })
    })
  });
};

/* harmony default export */ const header = (Header);

/***/ }),

/***/ 6725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ mobile_navigation)
});

// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: ./src/components/icons/search-icon.tsx
var search_icon = __webpack_require__(8244);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/icons/user-icon.tsx


const UserIcon = ({
  color = "currentColor",
  width = "18px",
  height = "20px"
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 16.577 18.6",
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M-7722.37,2933a.63.63,0,0,1-.63-.63c0-4.424,2.837-6.862,7.989-6.862s7.989,2.438,7.989,6.862a.629.629,0,0,1-.63.63Zm.647-1.251h13.428c-.246-3.31-2.5-4.986-6.713-4.986s-6.471,1.673-6.714,4.986Zm2.564-12.518a4.1,4.1,0,0,1,1.172-3,4.1,4.1,0,0,1,2.979-1.229,4.1,4.1,0,0,1,2.979,1.229,4.1,4.1,0,0,1,1.171,3,4.341,4.341,0,0,1-4.149,4.5,4.344,4.344,0,0,1-4.16-4.5Zm1.251,0a3.1,3.1,0,0,0,2.9,3.254,3.094,3.094,0,0,0,2.9-3.253,2.878,2.878,0,0,0-.813-2.109,2.88,2.88,0,0,0-2.085-.872,2.843,2.843,0,0,0-2.1.856,2.841,2.841,0,0,0-.806,2.122Z",
      transform: "translate(7723.3 -2914.703)",
      fill: color,
      stroke: color,
      strokeWidth: "0.6"
    })
  });
};

/* harmony default export */ const user_icon = (UserIcon);
;// CONCATENATED MODULE: ./src/components/icons/menu-icon.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const MenuIcon = props => {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "22",
    height: "14",
    viewBox: "0 0 25.567 18"
  }, props), {}, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("g", {
      transform: "translate(-776 -462)",
      children: [/*#__PURE__*/jsx_runtime_.jsx("rect", {
        id: "Rectangle_941",
        "data-name": "Rectangle 941",
        width: "12.749",
        height: "2.499",
        rx: "1.25",
        transform: "translate(776 462)",
        fill: "currentColor"
      }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
        id: "Rectangle_942",
        "data-name": "Rectangle 942",
        width: "25.567",
        height: "2.499",
        rx: "1.25",
        transform: "translate(776 469.75)",
        fill: "currentColor"
      }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
        id: "Rectangle_943",
        "data-name": "Rectangle 943",
        width: "17.972",
        height: "2.499",
        rx: "1.25",
        transform: "translate(776 477.501)",
        fill: "currentColor"
      })]
    })
  }));
};

/* harmony default export */ const menu_icon = (MenuIcon);
;// CONCATENATED MODULE: ./src/components/icons/home-icon.tsx


const HomeIcon = ({
  color = "currentColor",
  width = "18px",
  height = "20px"
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: width,
    height: height,
    viewBox: "0 0 17.996 20.442",
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M48.187,7.823,39.851.182A.7.7,0,0,0,38.9.2L31.03,7.841a.7.7,0,0,0-.211.5V19.311a.694.694,0,0,0,.694.694H37.3A.694.694,0,0,0,38,19.311V14.217h3.242v5.095a.694.694,0,0,0,.694.694h5.789a.694.694,0,0,0,.694-.694V8.335a.7.7,0,0,0-.228-.512ZM47.023,18.617h-4.4V13.522a.694.694,0,0,0-.694-.694H37.3a.694.694,0,0,0-.694.694v5.095H32.2V8.63l7.192-6.98L47.02,8.642v9.975Z",
      transform: "translate(-30.619 0.236)",
      fill: color,
      stroke: color,
      strokeWidth: "0.4"
    })
  });
};

/* harmony default export */ const home_icon = (HomeIcon);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: ../node_modules/next/dynamic.js
var dynamic = __webpack_require__(5218);
// EXTERNAL MODULE: ./src/components/common/drawer/drawer.tsx
var drawer = __webpack_require__(5536);
// EXTERNAL MODULE: ./src/utils/get-direction.ts
var get_direction = __webpack_require__(1727);
// EXTERNAL MODULE: external "jotai"
var external_jotai_ = __webpack_require__(8250);
// EXTERNAL MODULE: ./src/store/authorization-atom.ts
var authorization_atom = __webpack_require__(8879);
;// CONCATENATED MODULE: ./src/components/layout/mobile-navigation/mobile-navigation.tsx
















const CartButton = (0,dynamic.default)(() => __webpack_require__.e(/* import() */ 9039).then(__webpack_require__.bind(__webpack_require__, 9039)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(9039)],
    modules: ["../components/layout/mobile-navigation/mobile-navigation.tsx -> " + '@components/cart/cart-button']
  }
});
const AuthMenu = (0,dynamic.default)(() => __webpack_require__.e(/* import() */ 1316).then(__webpack_require__.bind(__webpack_require__, 1316)), {
  ssr: false,
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(1316)],
    modules: ["../components/layout/mobile-navigation/mobile-navigation.tsx -> " + '@components/layout/header/auth-menu']
  }
});
const MobileMenu = (0,dynamic.default)(() => __webpack_require__.e(/* import() */ 4428).then(__webpack_require__.bind(__webpack_require__, 4428)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(4428)],
    modules: ["../components/layout/mobile-navigation/mobile-navigation.tsx -> " + '@components/layout/header/mobile-menu']
  }
});

const BottomNavigation = () => {
  const {
    openSidebar,
    closeSidebar,
    displaySidebar,
    setDrawerView,
    openSearch,
    openModal,
    setModalView
  } = (0,ui_context/* useUI */.l8)();
  const [isAuthorize] = (0,external_jotai_.useAtom)(authorization_atom/* authorizationAtom */.O);

  function handleLogin() {
    setModalView('LOGIN_VIEW');
    return openModal();
  }

  function handleMobileMenu() {
    setDrawerView('MOBILE_MENU');
    return openSidebar();
  }

  const {
    locale
  } = (0,router_.useRouter)();
  const dir = (0,get_direction/* getDirection */.M)(locale);
  const contentWrapperCSS = dir === 'ltr' ? {
    left: 0
  } : {
    right: 0
  };
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "md:hidden fixed z-10 bottom-0 flex items-center justify-between shadow-bottomNavigation text-gray-700 body-font bg-white w-full h-14 sm:h-16 px-4",
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        "aria-label": "Menu",
        className: "menuBtn flex flex-col items-center justify-center flex-shrink-0 outline-none focus:outline-none",
        onClick: handleMobileMenu,
        children: /*#__PURE__*/jsx_runtime_.jsx(menu_icon, {})
      }), /*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "flex items-center justify-center flex-shrink-0 h-auto relative focus:outline-none",
        onClick: openSearch,
        "aria-label": "search-button",
        children: /*#__PURE__*/jsx_runtime_.jsx(search_icon/* default */.Z, {})
      }), /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
        href: "/",
        className: "flex-shrink-0",
        children: /*#__PURE__*/jsx_runtime_.jsx(home_icon, {})
      }), /*#__PURE__*/jsx_runtime_.jsx(CartButton, {}), /*#__PURE__*/jsx_runtime_.jsx(AuthMenu, {
        isAuthorized: isAuthorize,
        href: routes/* ROUTES.ACCOUNT */.Z.ACCOUNT,
        className: "flex-shrink-0",
        btnProps: {
          className: 'flex-shrink-0 focus:outline-none',
          children: /*#__PURE__*/jsx_runtime_.jsx(user_icon, {}),
          onClick: handleLogin
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(user_icon, {})
      }), /*#__PURE__*/jsx_runtime_.jsx("a", {
        className: "flex items-center justify-center flex-shrink-0 h-auto relative focus:outline-none transform text-sm xl:text-base text-heading font-semibold " //   onClick={openSearch}
        ,
        href: "#",
        "aria-label": "search-button",
        children: "Become Vendor"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(drawer/* Drawer */.d, {
      placement: dir === 'rtl' ? 'right' : 'left',
      open: displaySidebar,
      onClose: closeSidebar,
      handler: false,
      showMask: true,
      level: null,
      contentWrapperStyle: contentWrapperCSS,
      children: /*#__PURE__*/jsx_runtime_.jsx(MobileMenu, {})
    })]
  });
};

/* harmony default export */ const mobile_navigation = (BottomNavigation);

/***/ }),

/***/ 8835:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const Container = ({
  children,
  className,
  el = "div",
  clean
}) => {
  const rootClassName = classnames__WEBPACK_IMPORTED_MODULE_0___default()(className, {
    "mx-auto max-w-[1920px] px-4 md:px-8 2xl:px-16": !clean
  });
  let Component = el;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(Component, {
    className: rootClassName,
    children: children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);

/***/ }),

/***/ 6126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* reexport safe */ next_image__WEBPACK_IMPORTED_MODULE_0__.default)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8579);


/***/ }),

/***/ 9038:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ menu),
/* harmony export */   "e": () => (/* binding */ mobileMenu)
/* harmony export */ });
const menu = [{
  id: 1,
  path: '/',
  label: 'Home' // subMenu: [
  //   // {
  //   //   id: 1,
  //   //   path: '/',
  //   //   label: 'menu-modern',
  //   // },
  //   {
  //     id: 2,
  //     path: '/standard',
  //     label: 'menu-standard',
  //   },
  //   {
  //     id: 3,
  //     path: '/minimal',
  //     label: 'menu-minimal',
  //   },
  //   {
  //     id: 4,
  //     path: '/vintage',
  //     label: 'menu-vintage',
  //   },
  //   {
  //     id: 5,
  //     path: '/classic',
  //     label: 'menu-classic',
  //   },
  //   {
  //     id: 6,
  //     path: '/trendy',
  //     label: 'menu-trendy',
  //   },
  //   {
  //     id: 7,
  //     path: '/elegant',
  //     label: 'menu-elegant',
  //   },
  //   {
  //     id: 8,
  //     path: '/refined',
  //     label: 'menu-refined',
  //   },
  //   {
  //     id: 9,
  //     path: '/fashion',
  //     label: 'menu-fashion',
  //   },
  // ],

}, {
  id: 2,
  path: '/search?category=men',
  label: 'menu-men-wear',
  columns: [{
    id: 1,
    columnItems: [{
      id: 1,
      path: '/search?category=men',
      label: 'menu-top-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=electronics',
        label: 'menu-electronics'
      }, {
        id: 2,
        path: '/search?category=men',
        label: 'menu-casual-shirts'
      }, {
        id: 3,
        path: '/search?category=men',
        label: 'menu-formal-shirts'
      }, {
        id: 4,
        path: '/search?category=men',
        label: 'menu-blazwers-coats'
      }, {
        id: 5,
        path: '/search?category=men',
        label: 'menu-suits'
      }, {
        id: 6,
        path: '/search?category=men',
        label: 'menu-jackets'
      }]
    }, {
      id: 2,
      path: '/search?category=men',
      label: 'menu-belt-scarves'
    }, {
      id: 3,
      path: '/search?category=men',
      label: 'menu-watches-wearables'
    }]
  }, {
    id: 2,
    columnItems: [{
      id: 1,
      path: '/search?category=men',
      label: 'menu-western-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=men',
        label: 'menu-dresses'
      }, {
        id: 2,
        path: '/search?category=men',
        label: 'menu-jumpsuits'
      }, {
        id: 3,
        path: '/search?category=men',
        label: 'menu-tops-shirts'
      }, {
        id: 4,
        path: '/search?category=men',
        label: 'menu-shorts-skirts'
      }, {
        id: 5,
        path: '/search?category=men',
        label: 'menu-shurgs'
      }, {
        id: 6,
        path: '/search?category=men',
        label: 'menu-blazers'
      }]
    }, {
      id: 2,
      path: '/search?category=men',
      label: 'menu-plus-size'
    }, {
      id: 3,
      path: '/search?category=men',
      label: 'menu-sunglasses-frames'
    }]
  }, {
    id: 3,
    columnItems: [{
      id: 1,
      path: '/search?category=sneakers',
      label: 'menu-footwear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=sneakers',
        label: 'menu-flats'
      }, {
        id: 2,
        path: '/search?category=sneakers',
        label: 'menu-casual-shoes'
      }, {
        id: 3,
        path: '/search?category=sneakers',
        label: 'menu-heels'
      }, {
        id: 4,
        path: '/search?category=sneakers',
        label: 'menu-boots'
      }]
    }, {
      id: 2,
      path: '/search?category=sports',
      label: 'menu-sports-active-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=sports',
        label: 'menu-clothing'
      }, {
        id: 2,
        path: '/search?category=sports',
        label: 'menu-footwear'
      }, {
        id: 3,
        path: '/search?category=sports',
        label: 'menu-sports-accessories'
      }]
    }]
  }, {
    id: 4,
    columnItems: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-lingerie-sleepwear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-bra'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-briefs'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-sleepwear'
      }]
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-belt-scarves',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-makeup'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-skincare'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-premium-beauty'
      }, {
        id: 4,
        path: '/search?category=women',
        label: 'menu-lipsticks'
      }]
    }]
  }, {
    id: 5,
    columnItems: [{
      id: 1,
      path: '/search?category=watch',
      label: 'menu-gadgets',
      columnItemItems: [{
        id: 1,
        path: '/search?category=watch',
        label: 'menu-smart-wearables'
      }, {
        id: 2,
        path: '/search?category=watch',
        label: 'menu-headphones'
      }]
    }, {
      id: 2,
      path: '/search?category=watch',
      label: 'menu-jewellers',
      columnItemItems: [{
        id: 1,
        path: '/search?category=watch',
        label: 'menu-fashion-jewellers'
      }, {
        id: 2,
        path: '/search?category=watch',
        label: 'menu-fine-jewellers'
      }]
    }, {
      id: 3,
      path: '/search?category=bags',
      label: 'menu-backpacks'
    }, {
      id: 4,
      path: '/search?category=bags',
      label: 'menu-handbags-wallets'
    }]
  }]
}, {
  id: 3,
  path: '/search?category=women',
  label: 'menu-women-wear',
  columns: [{
    id: 1,
    columnItems: [{
      id: 1,
      path: '/search?category=bags',
      label: 'menu-gadgets',
      columnItemItems: [{
        id: 1,
        path: '/search?category=watch',
        label: 'menu-smart-wearables'
      }, {
        id: 2,
        path: '/search?category=sports',
        label: 'menu-headphones'
      }]
    }, {
      id: 2,
      path: '/search?category=watch',
      label: 'menu-jewellers',
      columnItemItems: [{
        id: 1,
        path: '/search?category=watch',
        label: 'menu-fashion-jewellers'
      }, {
        id: 2,
        path: '/search?category=watch',
        label: 'menu-fine-jewellers'
      }]
    }, {
      id: 3,
      path: '/search?category=bags',
      label: 'menu-backpacks'
    }, {
      id: 4,
      path: '/search?category=watch',
      label: 'menu-handbags-wallets'
    }]
  }, {
    id: 2,
    columnItems: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-top-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-t-shirt'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-casual-shirts'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-formal-shirts'
      }, {
        id: 4,
        path: '/search?category=women',
        label: 'menu-blazwers-coats'
      }, {
        id: 5,
        path: '/search?category=women',
        label: 'menu-suits'
      }, {
        id: 6,
        path: '/search?category=women',
        label: 'menu-jackets'
      }]
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-belt-scarves'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-watches-wearables'
    }]
  }, {
    id: 3,
    columnItems: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-footwear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-flats'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-casual-shoes'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-heels'
      }, {
        id: 4,
        path: '/search?category=women',
        label: 'menu-boots'
      }]
    }, {
      id: 2,
      path: '/search?category=sneakers',
      label: 'menu-sports-active-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=sneakers',
        label: 'menu-clothing'
      }, {
        id: 2,
        path: '/search?category=sneakers',
        label: 'menu-footwear'
      }, {
        id: 3,
        path: '/search?category=sneakers',
        label: 'menu-sports-accessories'
      }]
    }]
  }, {
    id: 4,
    columnItems: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-western-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-dresses'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-jumpsuits'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-tops-shirts'
      }, {
        id: 4,
        path: '/search?category=women',
        label: 'menu-shorts-skirts'
      }, {
        id: 5,
        path: '/search?category=women',
        label: 'menu-shurgs'
      }, {
        id: 6,
        path: '/search?category=women',
        label: 'menu-blazers'
      }]
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-plus-size'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-sunglasses-frames'
    }]
  }, {
    id: 5,
    columnItems: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-lingerie-sleepwear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-bra'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-briefs'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-sleepwear'
      }]
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-belt-scarves',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-makeup'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-skincare'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-premium-beauty'
      }, {
        id: 4,
        path: '/search?category=women',
        label: 'menu-lipsticks'
      }]
    }]
  }]
}, {
  id: 4,
  path: '/search?category=men',
  label: 'menu-casual-wear',
  columns: [{
    id: 1,
    columnItems: [{
      id: 1,
      path: '/search?category=watch',
      label: 'menu-gadgets',
      columnItemItems: [{
        id: 1,
        path: '/search?category=watch',
        label: 'menu-smart-wearables'
      }, {
        id: 2,
        path: '/search?category=sports',
        label: 'menu-headphones'
      }]
    }, {
      id: 2,
      path: '/search?category=watch',
      label: 'menu-jewellers',
      columnItemItems: [{
        id: 1,
        path: '/search?category=watch',
        label: 'menu-fashion-jewellers'
      }, {
        id: 2,
        path: '/search?category=watch',
        label: 'menu-fine-jewellers'
      }]
    }, {
      id: 3,
      path: '/search?category=bags',
      label: 'menu-backpacks'
    }, {
      id: 4,
      path: '/search?category=bags',
      label: 'menu-handbags-wallets'
    }]
  }, {
    id: 2,
    columnItems: [{
      id: 1,
      path: '/search?category=men',
      label: 'menu-top-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=men',
        label: 'menu-t-shirt'
      }, {
        id: 2,
        path: '/search?category=men',
        label: 'menu-casual-shirts'
      }, {
        id: 3,
        path: '/search?category=men',
        label: 'menu-formal-shirts'
      }, {
        id: 4,
        path: '/search?category=men',
        label: 'menu-blazwers-coats'
      }, {
        id: 5,
        path: '/search?category=men',
        label: 'menu-suits'
      }, {
        id: 6,
        path: '/search?category=men',
        label: 'menu-jackets'
      }]
    }, {
      id: 2,
      path: '/search?category=men',
      label: 'menu-belt-scarves'
    }, {
      id: 3,
      path: '/search?category=watch',
      label: 'menu-watches-wearables'
    }]
  }, {
    id: 3,
    columnItems: [{
      id: 1,
      path: '/search?category=sneakers',
      label: 'menu-footwear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=sneakers',
        label: 'menu-flats'
      }, {
        id: 2,
        path: '/search?category=sneakers',
        label: 'menu-casual-shoes'
      }, {
        id: 3,
        path: '/search?category=sneakers',
        label: 'menu-heels'
      }, {
        id: 4,
        path: '/search?category=sneakers',
        label: 'menu-boots'
      }]
    }, {
      id: 2,
      path: '/search?category=men',
      label: 'menu-sports-active-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=men',
        label: 'menu-clothing'
      }, {
        id: 2,
        path: '/search?category=men',
        label: 'menu-footwear'
      }, {
        id: 3,
        path: '/search?category=sports',
        label: 'menu-sports-accessories'
      }]
    }]
  }, {
    id: 4,
    columnItems: [{
      id: 1,
      path: '/search?category=men',
      label: 'menu-western-wear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=men',
        label: 'menu-dresses'
      }, {
        id: 2,
        path: '/search?category=men',
        label: 'menu-jumpsuits'
      }, {
        id: 3,
        path: '/search?category=men',
        label: 'menu-tops-shirts'
      }, {
        id: 4,
        path: '/search?category=men',
        label: 'menu-shorts-skirts'
      }, {
        id: 5,
        path: '/search?category=men',
        label: 'menu-shurgs'
      }, {
        id: 6,
        path: '/search?category=men',
        label: 'menu-blazers'
      }]
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-plus-size'
    }, {
      id: 3,
      path: '/search?category=sunglass',
      label: 'menu-sunglasses-frames'
    }]
  }, {
    id: 5,
    columnItems: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-lingerie-sleepwear',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-bra'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-briefs'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-sleepwear'
      }]
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-belt-scarves',
      columnItemItems: [{
        id: 1,
        path: '/search?category=women',
        label: 'menu-makeup'
      }, {
        id: 2,
        path: '/search?category=women',
        label: 'menu-skincare'
      }, {
        id: 3,
        path: '/search?category=women',
        label: 'menu-premium-beauty'
      }, {
        id: 4,
        path: '/search?category=women',
        label: 'menu-lipsticks'
      }]
    }]
  }]
}, // {
//   id: 5,
//   path: '/search',
//   label: 'menu-search',
// },
{
  id: 6,
  path: '/shops',
  label: 'menu-shops'
} // {
//   id: 7,
//   path: '/',
//   label: 'menu-pages',
//   subMenu: [
//     {
//       id: 1,
//       path: '/',
//       label: 'menu-users',
//       subMenu: [
//         {
//           id: 1,
//           path: '/my-account',
//           label: 'menu-my-account',
//         },
//         {
//           id: 2,
//           path: '/signin',
//           label: 'menu-sign-in',
//         },
//         {
//           id: 3,
//           path: '/signup',
//           label: 'menu-sign-up',
//         },
//         {
//           id: 4,
//           path: '/forget-password',
//           label: 'menu-forget-password',
//         },
//       ],
//     },
//     {
//       id: 2,
//       path: '/faq',
//       label: 'menu-faq',
//     },
//     {
//       id: 3,
//       path: '/privacy',
//       label: 'menu-privacy-policy',
//     },
//     {
//       id: 4,
//       path: '/terms',
//       label: 'menu-terms-condition',
//     },
//     {
//       id: 5,
//       path: '/contact-us',
//       label: 'menu-contact-us',
//     },
//     {
//       id: 6,
//       path: '/checkout',
//       label: 'menu-checkout',
//     },
//     {
//       id: 7,
//       path: '/collections/on-sale',
//       label: 'menu-collection',
//     },
//     {
//       id: 8,
//       path: '/search',
//       label: 'menu-category',
//     },
//     {
//       id: 9,
//       path: '/my-account/orders',
//       label: 'menu-order',
//     },
//     {
//       id: 10,
//       path: '/404',
//       label: 'menu-404',
//     },
//   ],
// },
];
const mobileMenu = [{
  id: 1,
  path: '/',
  label: 'Home' // subMenu: [
  //   {
  //     id: 1,
  //     path: '/',
  //     label: 'menu-modern',
  //   },
  //   {
  //     id: 2,
  //     path: '/standard',
  //     label: 'menu-standard',
  //   },
  //   {
  //     id: 3,
  //     path: '/minimal',
  //     label: 'menu-minimal',
  //   },
  //   {
  //     id: 4,
  //     path: '/vintage',
  //     label: 'menu-vintage',
  //   },
  //   {
  //     id: 5,
  //     path: '/classic',
  //     label: 'menu-classic',
  //   },
  //   {
  //     id: 6,
  //     path: '/trendy',
  //     label: 'menu-trendy',
  //   },
  //   {
  //     id: 7,
  //     path: '/elegant',
  //     label: 'menu-elegant',
  //   },
  //   {
  //     id: 8,
  //     path: '/refined',
  //     label: 'menu-refined',
  //   },
  //   {
  //     id: 9,
  //     path: '/fashion',
  //     label: 'menu-fashion',
  //   },
  // ],

}, {
  id: 2,
  path: '/search?category=men',
  label: 'menu-men-wear',
  subMenu: [{
    id: 1,
    path: '/search?category=men',
    label: 'menu-top-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=men',
      label: 'menu-t-shirt'
    }, {
      id: 2,
      path: '//search?category=men',
      label: 'menu-casual-shirts'
    }, {
      id: 3,
      path: '/search?category=men',
      label: 'menu-formal-shirts'
    }, {
      id: 4,
      path: '/search?category=men',
      label: 'menu-blazwers-coats'
    }, {
      id: 5,
      path: '/search?category=men',
      label: 'menu-suits'
    }, {
      id: 6,
      path: '/search?category=men',
      label: 'menu-jackets'
    }]
  }, {
    id: 2,
    path: '/search?category=women',
    label: 'menu-belt-scarves'
  }, {
    id: 3,
    path: '/search?category=women',
    label: 'menu-watches-wearables'
  }, {
    id: 4,
    path: '/search?category=women',
    label: 'menu-western-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-dresses'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-jumpsuits'
    }, {
      id: 3,
      path: '/search?category=men',
      label: 'menu-tops-shirts'
    }, {
      id: 4,
      path: '/search?category=men',
      label: 'menu-shorts-skirts'
    }, {
      id: 5,
      path: '/search?category=men',
      label: 'menu-shurgs'
    }, {
      id: 6,
      path: '/search?category=men',
      label: 'menu-blazers'
    }]
  }, {
    id: 5,
    path: '/search?category=women',
    label: 'menu-plus-size'
  }, {
    id: 6,
    path: '/search?category=women',
    label: 'menu-sunglasses-frames'
  }, {
    id: 7,
    path: '/search?category=women',
    label: 'menu-footwear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-flats'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-casual-shoes'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-heels'
    }, {
      id: 4,
      path: '/search?category=women',
      label: 'menu-boots'
    }]
  }, {
    id: 8,
    path: '/search?category=women',
    label: 'menu-sports-active-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-clothing'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-footwear'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-sports-accessories'
    }]
  }, {
    id: 9,
    path: '/search?category=women',
    label: 'menu-lingerie-sleepwear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-bra'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-briefs'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-sleepwear'
    }]
  }, {
    id: 10,
    path: '/search?category=women',
    label: 'menu-belt-scarves',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-makeup'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-skincare'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-premium-beauty'
    }, {
      id: 4,
      path: '/search?category=women',
      label: 'menu-lipsticks'
    }]
  }, {
    id: 11,
    path: '/search?category=sports',
    label: 'menu-gadgets',
    subMenu: [{
      id: 1,
      path: '/search?category=sports',
      label: 'menu-smart-wearables'
    }, {
      id: 2,
      path: '/search?category=sports',
      label: 'menu-headphones'
    }]
  }, {
    id: 12,
    path: '/search?category=women',
    label: 'menu-jewellers',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-fashion-jewellers'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-fine-jewellers'
    }]
  }, {
    id: 13,
    path: '/search?category=bags',
    label: 'menu-backpacks'
  }, {
    id: 14,
    path: '/search?category=bags',
    label: 'menu-handbags-wallets'
  }]
}, {
  id: 3,
  path: '/search?category=women',
  label: 'menu-women-wear',
  subMenu: [{
    id: 1,
    path: '/search?category=men',
    label: 'menu-top-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-t-shirt'
    }, {
      id: 2,
      path: '//search?category=women',
      label: 'menu-casual-shirts'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-formal-shirts'
    }, {
      id: 4,
      path: '/search?category=women',
      label: 'menu-blazwers-coats'
    }, {
      id: 5,
      path: '/search?category=women',
      label: 'menu-suits'
    }, {
      id: 6,
      path: '/search?category=women',
      label: 'menu-jackets'
    }]
  }, {
    id: 2,
    path: '/search?category=women',
    label: 'menu-belt-scarves'
  }, {
    id: 3,
    path: '/search?category=women',
    label: 'menu-watches-wearables'
  }, {
    id: 4,
    path: '/search?category=women',
    label: 'menu-western-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-dresses'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-jumpsuits'
    }, {
      id: 3,
      path: '/search?category=men',
      label: 'menu-tops-shirts'
    }, {
      id: 4,
      path: '/search?category=men',
      label: 'menu-shorts-skirts'
    }, {
      id: 5,
      path: '/search?category=men',
      label: 'menu-shurgs'
    }, {
      id: 6,
      path: '/search?category=men',
      label: 'menu-blazers'
    }]
  }, {
    id: 5,
    path: '/search?category=women',
    label: 'menu-plus-size'
  }, {
    id: 6,
    path: '/search?category=women',
    label: 'menu-sunglasses-frames'
  }, {
    id: 7,
    path: '/search?category=women',
    label: 'menu-footwear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-flats'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-casual-shoes'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-heels'
    }, {
      id: 4,
      path: '/search?category=women',
      label: 'menu-boots'
    }]
  }, {
    id: 8,
    path: '/search?category=women',
    label: 'menu-sports-active-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-clothing'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-footwear'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-sports-accessories'
    }]
  }, {
    id: 9,
    path: '/search?category=women',
    label: 'menu-lingerie-sleepwear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-bra'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-briefs'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-sleepwear'
    }]
  }, {
    id: 10,
    path: '/search?category=women',
    label: 'menu-belt-scarves',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-makeup'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-skincare'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-premium-beauty'
    }, {
      id: 4,
      path: '/search?category=women',
      label: 'menu-lipsticks'
    }]
  }, {
    id: 11,
    path: '/search?category=sports',
    label: 'menu-gadgets',
    subMenu: [{
      id: 1,
      path: '/search?category=sports',
      label: 'menu-smart-wearables'
    }, {
      id: 2,
      path: '/search?category=sports',
      label: 'menu-headphones'
    }]
  }, {
    id: 12,
    path: '/search?category=women',
    label: 'menu-jewellers',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-fashion-jewellers'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-fine-jewellers'
    }]
  }, {
    id: 13,
    path: '/search?category=bags',
    label: 'menu-backpacks'
  }, {
    id: 14,
    path: '/search?category=bags',
    label: 'menu-handbags-wallets'
  }]
}, {
  id: 4,
  path: '/search?category=women',
  label: 'menu-casual-wear',
  subMenu: [{
    id: 1,
    path: '/search?category=men',
    label: 'menu-top-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=me',
      label: 'menu-t-shirt'
    }, {
      id: 2,
      path: '/search?category=me',
      label: 'menu-casual-shirts'
    }, {
      id: 3,
      path: '/search?category=me',
      label: 'menu-formal-shirts'
    }, {
      id: 4,
      path: '/search?category=me',
      label: 'menu-blazwers-coats'
    }, {
      id: 5,
      path: '/search?category=me',
      label: 'menu-suits'
    }, {
      id: 6,
      path: '/search?category=me',
      label: 'menu-jackets'
    }]
  }, {
    id: 2,
    path: '/search?category=women',
    label: 'menu-belt-scarves'
  }, {
    id: 3,
    path: '/search?category=women',
    label: 'menu-watches-wearables'
  }, {
    id: 4,
    path: '/search?category=women',
    label: 'menu-western-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-dresses'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-jumpsuits'
    }, {
      id: 3,
      path: '/search?category=men',
      label: 'menu-tops-shirts'
    }, {
      id: 4,
      path: '/search?category=men',
      label: 'menu-shorts-skirts'
    }, {
      id: 5,
      path: '/search?category=men',
      label: 'menu-shurgs'
    }, {
      id: 6,
      path: '/search?category=men',
      label: 'menu-blazers'
    }]
  }, {
    id: 5,
    path: '/search?category=women',
    label: 'menu-plus-size'
  }, {
    id: 6,
    path: '/search?category=women',
    label: 'menu-sunglasses-frames'
  }, {
    id: 7,
    path: '/search?category=women',
    label: 'menu-footwear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-flats'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-casual-shoes'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-heels'
    }, {
      id: 4,
      path: '/search?category=women',
      label: 'menu-boots'
    }]
  }, {
    id: 8,
    path: '/search?category=sports',
    label: 'menu-sports-active-wear',
    subMenu: [{
      id: 1,
      path: '/search?category=sports',
      label: 'menu-clothing'
    }, {
      id: 2,
      path: '/search?category=sports',
      label: 'menu-footwear'
    }, {
      id: 3,
      path: '/search?category=sports',
      label: 'menu-sports-accessories'
    }]
  }, {
    id: 9,
    path: '/search?category=women',
    label: 'menu-lingerie-sleepwear',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-bra'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-briefs'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-sleepwear'
    }]
  }, {
    id: 10,
    path: '/search?category=women',
    label: 'menu-belt-scarves',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-makeup'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-skincare'
    }, {
      id: 3,
      path: '/search?category=women',
      label: 'menu-premium-beauty'
    }, {
      id: 4,
      path: '/search?category=women',
      label: 'menu-lipsticks'
    }]
  }, {
    id: 11,
    path: '/search?category=sports',
    label: 'menu-gadgets',
    subMenu: [{
      id: 1,
      path: '/search?category=sports',
      label: 'menu-smart-wearables'
    }, {
      id: 2,
      path: '/search?category=sports',
      label: 'menu-headphones'
    }]
  }, {
    id: 12,
    path: '/search?category=women',
    label: 'menu-jewellers',
    subMenu: [{
      id: 1,
      path: '/search?category=women',
      label: 'menu-fashion-jewellers'
    }, {
      id: 2,
      path: '/search?category=women',
      label: 'menu-fine-jewellers'
    }]
  }, {
    id: 13,
    path: '/search?category=bags',
    label: 'menu-backpacks'
  }, {
    id: 14,
    path: '/search?category=bags',
    label: 'menu-handbags-wallets'
  }]
}, // {
//   id: 5,
//   path: '/search',
//   label: 'menu-search',
// },
{
  id: 6,
  path: '/shops',
  label: 'menu-shops'
} // {
//   id: 7,
//   path: '/',
//   label: 'menu-pages',
//   subMenu: [
//     {
//       id: 1,
//       path: '/',
//       label: 'menu-users',
//       subMenu: [
//         {
//           id: 1,
//           path: '/my-account',
//           label: 'menu-my-account',
//         },
//         {
//           id: 2,
//           path: '/signin',
//           label: 'menu-sign-in',
//         },
//         {
//           id: 3,
//           path: '/signup',
//           label: 'menu-sign-up',
//         },
//         {
//           id: 4,
//           path: '/forget-password',
//           label: 'menu-forget-password',
//         },
//       ],
//     },
//     {
//       id: 2,
//       path: '/faq',
//       label: 'menu-faq',
//     },
//     {
//       id: 3,
//       path: '/privacy',
//       label: 'menu-privacy-policy',
//     },
//     {
//       id: 4,
//       path: '/terms',
//       label: 'menu-terms-condition',
//     },
//     {
//       id: 5,
//       path: '/contact-us',
//       label: 'menu-contact-us',
//     },
//     {
//       id: 6,
//       path: '/checkout',
//       label: 'menu-checkout',
//     },
//     {
//       id: 7,
//       path: '/collections/on-sale',
//       label: 'menu-collection',
//     },
//     {
//       id: 8,
//       path: '/search',
//       label: 'menu-category',
//     },
//     {
//       id: 9,
//       path: '/my-account/orders',
//       label: 'menu-order',
//     },
//     {
//       id: 10,
//       path: '/404',
//       label: 'menu-404',
//     },
//   ],
// },
];

/***/ }),

/***/ 8473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ getIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
const _excluded = ["iconList", "iconName"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

const getIcon = _ref => {
  let {
    iconList,
    iconName
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const TagName = iconList[iconName];
  return !!TagName ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TagName, _objectSpread({}, rest)) : null;
};

/***/ }),

/***/ 8392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/src/assets/not-found.53810d025c85543305c9c8a9c08770a4.svg","height":493,"width":824});

/***/ })

};
;