exports.id = 3283;
exports.ids = [3283];
exports.modules = {

/***/ 5100:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ OrderView)
});

// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(8349);
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: ./src/lib/use-price.ts
var use_price = __webpack_require__(7259);
// EXTERNAL MODULE: ./src/lib/format-address.ts
var format_address = __webpack_require__(2528);
;// CONCATENATED MODULE: ./src/lib/format-string.tsx
function formatString(count, string) {
  if (!count) return `${count} ${string}`;
  return count > 1 ? `${count} ${string}s` : `${count} ${string}`;
}
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/badge.tsx




const Badge = ({
  className,
  color: colorOverride,
  textColor: textColorOverride,
  text,
  style
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const classes = {
    root: 'px-3 py-1 rounded-full text-sm',
    default: 'bg-heading',
    text: 'text-light'
  };
  return /*#__PURE__*/jsx_runtime_.jsx("span", {
    className: external_classnames_default()(classes.root, {
      [classes.default]: !colorOverride,
      [classes.text]: !textColorOverride
    }, colorOverride, textColorOverride, className),
    style: style,
    children: t(text)
  });
};

/* harmony default export */ const badge = (Badge);
// EXTERNAL MODULE: external "rc-table"
var external_rc_table_ = __webpack_require__(6356);
var external_rc_table_default = /*#__PURE__*/__webpack_require__.n(external_rc_table_);
;// CONCATENATED MODULE: ./src/components/ui/table.tsx


// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
;// CONCATENATED MODULE: ./src/lib/locals.tsx

const localeRTLList = ['ar', 'he'];
function useIsRTL() {
  const {
    locale
  } = (0,router_.useRouter)();

  if (locale && localeRTLList.includes(locale)) {
    return {
      isRTL: true,
      alignLeft: 'right',
      alignRight: 'left'
    };
  }

  return {
    isRTL: false,
    alignLeft: 'left',
    alignRight: 'right'
  };
}
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/components/ui/image.tsx
var ui_image = __webpack_require__(6126);
// EXTERNAL MODULE: ./src/lib/placeholders.tsx + 6 modules
var placeholders = __webpack_require__(9742);
;// CONCATENATED MODULE: ./src/components/orders/order-items.tsx










const OrderItemList = (_, record) => {
  var _record$pivot, _record$pivot2, _record$image$thumbna, _record$image;

  const {
    price
  } = (0,use_price/* default */.ZP)({
    amount: (_record$pivot = record.pivot) === null || _record$pivot === void 0 ? void 0 : _record$pivot.unit_price
  });
  let name = record.name;

  if (record !== null && record !== void 0 && (_record$pivot2 = record.pivot) !== null && _record$pivot2 !== void 0 && _record$pivot2.variation_option_id) {
    var _record$variation_opt;

    const variationTitle = record === null || record === void 0 ? void 0 : (_record$variation_opt = record.variation_options) === null || _record$variation_opt === void 0 ? void 0 : _record$variation_opt.find(vo => {
      var _record$pivot3;

      return (vo === null || vo === void 0 ? void 0 : vo.id) === (record === null || record === void 0 ? void 0 : (_record$pivot3 = record.pivot) === null || _record$pivot3 === void 0 ? void 0 : _record$pivot3.variation_option_id);
    })["title"];
    name = `${name} - ${variationTitle}`;
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex items-center",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-16 h-16 flex flex-shrink-0 rounded overflow-hidden relative",
      children: /*#__PURE__*/jsx_runtime_.jsx(ui_image/* Image */.E, {
        src: (_record$image$thumbna = (_record$image = record.image) === null || _record$image === void 0 ? void 0 : _record$image.thumbnail) !== null && _record$image$thumbna !== void 0 ? _record$image$thumbna : placeholders/* productPlaceholder */.Hb,
        alt: name,
        className: "w-full h-full object-cover bg-gray-200",
        layout: "fill"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col ltr:ml-4 rtl:mr-4 overflow-hidden",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex mb-2 text-body",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          className: "text-[15px] truncate inline-block overflow-hidden",
          children: [name, " x\xA0"]
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "text-[15px] text-heading font-semibold truncate inline-block overflow-hidden",
          children: record.unit
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "text-[15px] text-accent font-semibold mb-1 truncate inline-block overflow-hidden",
        children: price
      })]
    })]
  });
};

const OrderItems = ({
  products
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    alignLeft,
    alignRight
  } = useIsRTL();
  const orderTableColumns = (0,external_react_.useMemo)(() => [{
    title: /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "ltr:pl-20 rtl:pr-20 ltr:ml-2 rtl:mr-2",
      children: t("text-product")
    }),
    dataIndex: "",
    key: "items",
    align: alignLeft,
    width: 250,
    ellipsis: true,
    render: OrderItemList
  }, {
    title: t("text-quantity"),
    dataIndex: "pivot",
    key: "pivot",
    align: "center",
    width: 100,
    render: function renderQuantity(pivot) {
      return /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-[15px] md:text-base font-semibold text-heading",
        children: pivot.order_quantity
      });
    }
  }, {
    title: t("text-price"),
    dataIndex: "pivot",
    key: "price",
    align: "center",
    width: 100,
    render: function RenderPrice(pivot) {
      const {
        price
      } = (0,use_price/* default */.ZP)({
        amount: pivot.subtotal
      });
      return /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-[15px] md:text-base font-semibold text-heading",
        children: price
      });
    }
  }], [alignLeft, alignRight, t]);
  return /*#__PURE__*/jsx_runtime_.jsx((external_rc_table_default()) //@ts-ignore
  , {
    columns: orderTableColumns,
    data: products,
    rowKey: record => {
      var _record$pivot4;

      return (_record$pivot4 = record.pivot) !== null && _record$pivot4 !== void 0 && _record$pivot4.variation_option_id ? record.pivot.variation_option_id : record.created_at;
    },
    className: "orderDetailsTable w-full",
    scroll: {
      x: 350,
      y: 500
    }
  });
};
;// CONCATENATED MODULE: ./src/components/orders/suborder-items.tsx











const SuborderItems = ({
  items
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    alignLeft
  } = useIsRTL();
  const orderTableColumns = [{
    title: t("text-tracking-number"),
    dataIndex: "tracking_number",
    key: "tracking_number",
    align: alignLeft
  }, {
    title: t("text-date"),
    dataIndex: "date",
    key: "date",
    align: alignLeft,
    render: created_at => external_dayjs_default()(created_at).format("MMMM D, YYYY")
  }, {
    title: t("text-status"),
    dataIndex: "status",
    key: "status",
    align: alignLeft,
    render: function renderStatus(status) {
      return /*#__PURE__*/jsx_runtime_.jsx(badge, {
        text: status === null || status === void 0 ? void 0 : status.name,
        className: "font-semibold text-white"
      });
    }
  }, {
    title: t("text-item"),
    dataIndex: "products",
    key: "products",
    align: alignLeft,
    render: products => formatString(products === null || products === void 0 ? void 0 : products.length, t("text-item"))
  }, {
    title: t("text-total-price"),
    dataIndex: "paid_total",
    key: "paid_total",
    align: alignLeft,
    // width: 100,
    render: function TotalPrice(paid_total) {
      const {
        price
      } = (0,use_price/* default */.ZP)({
        amount: paid_total
      });
      return /*#__PURE__*/jsx_runtime_.jsx("p", {
        children: price
      });
    }
  }, {
    title: "",
    dataIndex: "tracking_number",
    key: "tracking_number",
    align: "center",
    // width: 100,
    render: function renderTrackingNumber(tracking_number) {
      return /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
        href: `${routes/* ROUTES.ORDERS */.Z.ORDERS}/${tracking_number}`,
        className: "inline-flex items-center justify-center flex-shrink-0 font-semibold leading-none outline-none transition duration-300 ease-in-out focus:outline-none focus:shadow text-heading underline hover:no-underline",
        children: t("text-view")
      });
    }
  }];
  return /*#__PURE__*/jsx_runtime_.jsx((external_rc_table_default()) //@ts-ignore
  , {
    columns: orderTableColumns,
    emptyText: t("table:empty-table-data") //@ts-ignore
    ,
    data: items,
    rowKey: "id",
    scroll: {
      x: 800
    },
    className: "subOrderTable w-full"
  });
};

/* harmony default export */ const suborder_items = (SuborderItems);
;// CONCATENATED MODULE: ./src/components/orders/order-view.tsx












function OrderView({
  order
}) {
  var _order$delivery_fee, _order$sales_tax, _order$discount, _order$status, _order$payment_gatewa, _order$products, _order$children;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const {
    price: total
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.paid_total
  });
  const {
    price: sub_total
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.amount
  });
  const {
    price: shipping_charge
  } = (0,use_price/* default */.ZP)({
    amount: (_order$delivery_fee = order === null || order === void 0 ? void 0 : order.delivery_fee) !== null && _order$delivery_fee !== void 0 ? _order$delivery_fee : 0
  });
  const {
    price: tax
  } = (0,use_price/* default */.ZP)({
    amount: (_order$sales_tax = order === null || order === void 0 ? void 0 : order.sales_tax) !== null && _order$sales_tax !== void 0 ? _order$sales_tax : 0
  });
  const {
    price: discount
  } = (0,use_price/* default */.ZP)({
    amount: (_order$discount = order === null || order === void 0 ? void 0 : order.discount) !== null && _order$discount !== void 0 ? _order$discount : 0
  });
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "max-w-[1280px] mx-auto mb-14 lg:mb-16",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full mx-auto shadow-sm",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col sm:flex-row items-center justify-between mb-6",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "mt-5 sm:mt-0 ltr:mr-auto rtl:ml-auto order-2 sm:order-1 text-heading font-semibold flex items-center",
          children: [t("text-status"), " :", /*#__PURE__*/jsx_runtime_.jsx(badge, {
            text: order === null || order === void 0 ? void 0 : (_order$status = order.status) === null || _order$status === void 0 ? void 0 : _order$status.name,
            className: "whitespace-nowrap bg-heading text-white font-semibold text-sm ltr:ml-2 rtl:mr-2"
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(ui_link/* default */.Z, {
          href: routes/* ROUTES.HOME */.Z.HOME,
          className: "inline-flex items-center text-heading order-1 sm:order-2 text-accent text-base font-semibold underline hover:no-underline",
          children: t("text-back-to-home")
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "grid gap-4 lg:gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-11",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "p-5 md:p-6 border border-gray-100 bg-gray-200 rounded-md shadow-sm",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            className: "mb-2 text-base text-heading font-semibold",
            children: t("text-order-number")
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-sm text-body",
            children: order === null || order === void 0 ? void 0 : order.tracking_number
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "p-5 md:p-6 border border-gray-100 bg-gray-200 rounded-md shadow-sm",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            className: "mb-2 text-base text-heading font-semibold",
            children: t("text-date")
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-sm text-body",
            children: external_dayjs_default()(order === null || order === void 0 ? void 0 : order.created_at).format("MMMM D, YYYY")
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "p-5 md:p-6 border border-gray-100 bg-gray-200 rounded-md shadow-sm",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            className: "mb-2 text-base text-heading font-semibold",
            children: t("text-total")
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-sm text-body",
            children: total
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "p-5 md:p-6 border border-gray-100 bg-gray-200 rounded-md shadow-sm",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            className: "mb-2 text-base text-heading font-semibold",
            children: t("text-payment-method")
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-sm text-body",
            children: (_order$payment_gatewa = order === null || order === void 0 ? void 0 : order.payment_gateway) !== null && _order$payment_gatewa !== void 0 ? _order$payment_gatewa : "N/A"
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col md:flex-row border border-gray-100 rounded-md",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full md:w-1/2 ltr:md:pr-3 rtl:md:pl-3 border-r px-5 lg:px-7 py-6 lg:py-7 xl:py-8 border-gray-100",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "text-lg lg:text-xl xl:text-2xl font-bold text-heading mb-5 lg:mb-6",
            children: t("text-total-amount")
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "space-y-4 lg:space-y-5",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-sub-total")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7",
                children: sub_total
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-shipping-charge")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7",
                children: shipping_charge
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-tax")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7",
                children: tax
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-discount")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7",
                children: discount
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-total")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7",
                children: total
              })]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full md:w-1/2 px-5 lg:px-7 py-6 lg:py-7 xl:py-8",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "text-lg lg:text-xl xl:text-2xl font-bold text-heading mb-5 lg:mb-6",
            children: t("text-order-details")
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "space-y-4 lg:space-y-5",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-total-item")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7 capitalize",
                children: formatString(order === null || order === void 0 ? void 0 : (_order$products = order.products) === null || _order$products === void 0 ? void 0 : _order$products.length, t("text-item"))
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-deliver-time")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7",
                children: order === null || order === void 0 ? void 0 : order.delivery_time
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-shipping-address")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7",
                children: (0,format_address/* formatAddress */.T)(order === null || order === void 0 ? void 0 : order.shipping_address)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "flex text-body text-sm lg:text-[15px] xl:text-base mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
                className: "w-1/2 md:w-4/12 ltr:pr-4 rtl:pl-4 text-heading font-semibold",
                children: t("text-billing-address")
              }), ":", /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "w-1/2 md:w-8/12 ltr:pl-7 rtl:pr-7",
                children: (0,format_address/* formatAddress */.T)(order === null || order === void 0 ? void 0 : order.billing_address)
              })]
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "mt-11",
        children: /*#__PURE__*/jsx_runtime_.jsx(OrderItems, {
          products: order === null || order === void 0 ? void 0 : order.products
        })
      }), order !== null && order !== void 0 && (_order$children = order.children) !== null && _order$children !== void 0 && _order$children.length ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "mt-11",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "text-lg lg:text-xl xl:text-2xl font-bold text-heading mb-3 lg:mb-5 xl:mb-6",
          children: t("text-sub-orders")
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex items-start mb-6",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "text-heading text-sm leading-6",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
                className: "font-bold",
                children: [t("text-note"), ":"]
              }), " ", t("text-message-sub-order")]
            })
          }), Array.isArray(order === null || order === void 0 ? void 0 : order.children) && (order === null || order === void 0 ? void 0 : order.children.length) && /*#__PURE__*/jsx_runtime_.jsx(suborder_items, {
            items: order === null || order === void 0 ? void 0 : order.children
          })]
        })]
      }) : null]
    })
  });
}

/***/ }),

/***/ 8883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _page_loader_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1381);
/* harmony import */ var _page_loader_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_page_loader_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);





const PageLoader = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_0___default()("w-full h-screen flex flex-col items-center justify-center"),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: "flex relative",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
        className: (_page_loader_module_css__WEBPACK_IMPORTED_MODULE_2___default().page_loader)
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
        className: "text-sm font-semibold text-body italic absolute top-1/2 -mt-2 w-full text-center",
        children: "Loading..."
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageLoader);

/***/ }),

/***/ 659:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ fetchSettings),
/* harmony export */   "n": () => (/* binding */ useSettingsQuery)
/* harmony export */ });
/* harmony import */ var _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3036);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);



const SettingsService = new _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__/* .CoreApi */ .z(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.SETTINGS */ .P.SETTINGS);
const fetchSettings = async () => {
  const {
    data
  } = await SettingsService.findAll();
  return {
    settings: data
  };
};
const useSettingsQuery = () => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.SETTINGS */ .P.SETTINGS, fetchSettings);
};

/***/ }),

/***/ 5983:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ getStaticPaths),
/* harmony export */   "b": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var _framework_settings_settings_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3295);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9475);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_query_hydration__WEBPACK_IMPORTED_MODULE_4__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const getStaticPaths = async () => {
  return {
    paths: [],
    fallback: true
  };
};
const getStaticProps = async ({
  locale
}) => {
  const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_3__.QueryClient({
    defaultOptions: {
      queries: {
        staleTime: Infinity
      }
    }
  });
  await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.SETTINGS */ .P.SETTINGS, _framework_settings_settings_query__WEBPACK_IMPORTED_MODULE_0__/* .fetchSettings */ .w);
  return {
    props: _objectSpread(_objectSpread({}, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
      dehydratedState: JSON.parse(JSON.stringify((0,react_query_hydration__WEBPACK_IMPORTED_MODULE_4__.dehydrate)(queryClient)))
    })
  };
};

/***/ }),

/***/ 1381:
/***/ ((module) => {

// Exports
module.exports = {
	"page_loader": "page-loader_page_loader__2Bj7D",
	"spin": "page-loader_spin__1ZvtZ",
	"heart-beat": "page-loader_heart-beat__389xr"
};


/***/ })

};
;