"use strict";
exports.id = 8147;
exports.ids = [8147];
exports.modules = {

/***/ 7615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lib_use_price__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7259);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);







const VariationPrice = ({
  selectedVariation,
  minPrice,
  maxPrice,
  basePriceClassName = "text-heading font-semibold text-base md:text-xl lg:text-2xl",
  discountPriceClassName = "font-segoe text-gray-400 text-base lg:text-xl ltr:pl-2.5 rtl:pr-2.5 -mt-0.5 md:mt-0"
}) => {
  const {
    price,
    basePrice
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_0__/* .default */ .ZP)(selectedVariation && {
    amount: selectedVariation.sale_price ? selectedVariation.sale_price : selectedVariation.price,
    baseAmount: selectedVariation.price
  });
  const {
    price: min_price
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_0__/* .default */ .ZP)({
    amount: minPrice
  });
  const {
    price: max_price
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_0__/* .default */ .ZP)({
    amount: maxPrice
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: basePriceClassName,
      children: !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_1___default()(selectedVariation) ? `${price}` : `${min_price} - ${max_price}`
    }), basePrice && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("del", {
      className: discountPriceClassName,
      children: basePrice
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VariationPrice);

/***/ }),

/***/ 2317:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ue": () => (/* binding */ useProductsInfiniteQuery),
/* harmony export */   "GU": () => (/* binding */ fetchInfiniteProducts),
/* harmony export */   "t2": () => (/* binding */ fetchProducts),
/* harmony export */   "kN": () => (/* binding */ useProductsQuery),
/* harmony export */   "MX": () => (/* binding */ fetchProduct),
/* harmony export */   "FA": () => (/* binding */ useProductQuery)
/* harmony export */ });
/* harmony import */ var _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3036);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var _framework_utils_data_mappers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9517);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_3__);
const _excluded = ["data"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const ProductService = new _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__/* .CoreApi */ .z(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS);

const fetchInfiniteProducts = async ({
  queryKey,
  pageParam
}) => {
  const params = queryKey[1];
  let fetchedData = {};

  if (pageParam) {
    const response = await ProductService.fetchUrl(pageParam);
    fetchedData = response.data;
  } else {
    const response = await ProductService.find(params);
    fetchedData = response.data;
  }

  const {
    data
  } = fetchedData,
        rest = _objectWithoutProperties(fetchedData, _excluded);

  return {
    data,
    paginatorInfo: (0,_framework_utils_data_mappers__WEBPACK_IMPORTED_MODULE_2__/* .mapPaginatorData */ .Q)(_objectSpread({}, rest))
  };
};

const useProductsInfiniteQuery = (params, options) => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_3__.useInfiniteQuery)([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS, params], fetchInfiniteProducts, _objectSpread(_objectSpread({}, options), {}, {
    getNextPageParam: ({
      paginatorInfo
    }) => paginatorInfo.nextPageUrl
  }));
};


const fetchProducts = async ({
  queryKey
}) => {
  const params = queryKey[1];
  const response = await ProductService.find(params);
  const fetchedData = response === null || response === void 0 ? void 0 : response.data;
  return {
    data: fetchedData === null || fetchedData === void 0 ? void 0 : fetchedData.data
  };
};
const useProductsQuery = options => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_3__.useQuery)([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS, options], fetchProducts);
};
const fetchProduct = async slug => {
  const {
    data
  } = await ProductService.findOne(slug);
  return data;
};
const useProductQuery = slug => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_3__.useQuery)([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS, slug], () => fetchProduct(slug));
};

/***/ }),

/***/ 9517:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ mapPaginatorData)
/* harmony export */ });
/* unused harmony export parseSearchString */
/* harmony import */ var camelcase_keys__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3687);
/* harmony import */ var camelcase_keys__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(camelcase_keys__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash_pickBy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4661);
/* harmony import */ var lodash_pickBy__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_pickBy__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const mapPaginatorData = obj => {
  const formattedValues = camelcase_keys__WEBPACK_IMPORTED_MODULE_0___default()(obj);
  return _objectSpread(_objectSpread({}, formattedValues), {}, {
    hasMorePages: formattedValues.lastPage !== formattedValues.currentPage
  });
};
const parseSearchString = values => {
  const parsedValues = pickBy(values);
  return Object.keys(parsedValues).map(k => {
    if (k === "type") {
      return `${k}.slug:${parsedValues[k]};`;
    }

    if (k === "category") {
      return `categories.slug:${parsedValues[k]};`;
    }

    return `${k}:${parsedValues[k]};`;
  }).join("").slice(0, -1);
};

/***/ }),

/***/ 2347:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ getVariations)
/* harmony export */ });
/* harmony import */ var lodash_groupBy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3089);
/* harmony import */ var lodash_groupBy__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_groupBy__WEBPACK_IMPORTED_MODULE_0__);

function getVariations(variations) {
  if (!variations) return {};
  return lodash_groupBy__WEBPACK_IMPORTED_MODULE_0___default()(variations, "attribute.slug");
}

/***/ })

};
;