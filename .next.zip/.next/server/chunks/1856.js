"use strict";
exports.id = 1856;
exports.ids = [1856];
exports.modules = {

/***/ 1856:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5038);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7125);
/* harmony import */ var _components_product_product_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(135);
/* harmony import */ var _components_ui_loaders_product_card_small_list_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2813);
/* harmony import */ var _framework_products_products_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2317);
/* harmony import */ var _data_static_banners__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5941);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5013);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1103);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5278);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);












const SaleBannerWithProducts = ({
  sectionHeading,
  categorySlug,
  variant = "default",
  className = "mb-12 md:mb-14 xl:mb-16",
  productVariant = "listSmall",
  imageHeight = 176,
  imageWidth = 176,
  limit = 4,
  bannerData = _data_static_banners__WEBPACK_IMPORTED_MODULE_5__/* .saleBannerWithProducts */ .rd
}) => {
  var _siteSettings$homePag, _data$data;

  const onSellingSettings = _settings_site_settings__WEBPACK_IMPORTED_MODULE_8__/* .siteSettings */ .U === null || _settings_site_settings__WEBPACK_IMPORTED_MODULE_8__/* .siteSettings */ .U === void 0 ? void 0 : (_siteSettings$homePag = _settings_site_settings__WEBPACK_IMPORTED_MODULE_8__/* .siteSettings.homePageBlocks */ .U.homePageBlocks) === null || _siteSettings$homePag === void 0 ? void 0 : _siteSettings$homePag.onSaleSettings;
  const {
    data,
    isLoading,
    error
  } = (0,_framework_products_products_query__WEBPACK_IMPORTED_MODULE_4__/* .useProductsQuery */ .kN)({
    limit,
    tags: onSellingSettings === null || onSellingSettings === void 0 ? void 0 : onSellingSettings.slug
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      sectionHeading: sectionHeading,
      categorySlug: categorySlug
    }), error ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: `grid grid-cols-1 ${variant === "fashion" ? "2xl:grid-cols-6 md:grid-cols-3 sm:grid-cols-2 xl:grid-cols-4" : "2xl:grid-cols-4 2xl:grid-rows-2 md:grid-cols-2"} gap-3 md:gap-6 lg:gap-5 xl:gap-7`,
      children: [variant === "fashion" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "sm:col-span-full sm:grid-cols-4 grid 2xl:col-span-2 2xl:row-span-2 order-2 md:gap-8 sm:gap-3",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
          data: bannerData[0],
          href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_7__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${bannerData[0].slug}`,
          effectActive: true,
          className: "sm:col-span-2 2xl:col-span-full"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
          data: bannerData[1],
          href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_7__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${bannerData[1].slug}`,
          effectActive: true,
          className: "sm:col-span-2 2xl:col-span-full"
        })]
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
        data: bannerData[0],
        href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_7__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${bannerData[0].slug}`,
        effectActive: true,
        className: "md:col-span-full 2xl:col-span-2 2xl:row-span-2 order-2"
      }), isLoading ? Array.from({
        length: 2
      }).map((_, idx) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_ui_loaders_product_card_small_list_loader__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
        uniqueKey: `on-selling-${idx}`
      }, idx)) : data === null || data === void 0 ? void 0 : (_data$data = data.data) === null || _data$data === void 0 ? void 0 : _data$data.map((product, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
        className: `${variant === "center" && index === 0 ? "2xl:order-0" : "2xl:order-2"}`,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_product_product_card__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
          product: product,
          imgWidth: imageHeight,
          imgHeight: imageWidth,
          variant: productVariant
        })
      }, `product--key${product.id}`))]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SaleBannerWithProducts);

/***/ })

};
;