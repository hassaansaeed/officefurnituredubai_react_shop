"use strict";
exports.id = 9755;
exports.ids = [9755];
exports.modules = {

/***/ 9755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ hero_with_category)
});

// EXTERNAL MODULE: ./src/components/common/banner-card.tsx
var banner_card = __webpack_require__(5038);
// EXTERNAL MODULE: ./src/components/common/category-list-card.tsx
var category_list_card = __webpack_require__(1648);
// EXTERNAL MODULE: ./src/components/ui/carousel/carousel.tsx
var carousel = __webpack_require__(4365);
// EXTERNAL MODULE: external "swiper/react"
var react_ = __webpack_require__(2156);
// EXTERNAL MODULE: ./src/framework/rest/category/categories.query.ts
var categories_query = __webpack_require__(4362);
// EXTERNAL MODULE: ./src/utils/use-window-size.ts
var use_window_size = __webpack_require__(3396);
// EXTERNAL MODULE: ./src/components/ui/loaders/category-list-card-loader.tsx
var category_list_card_loader = __webpack_require__(256);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/loaders/category-list-feed-loader.tsx




const CategoryListFeedLoader = ({
  limit = 7
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: Array.from({
      length: limit
    }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(category_list_card_loader/* default */.Z, {
      uniqueKey: `category-${idx}`
    }, idx))
  });
};

/* harmony default export */ const category_list_feed_loader = (CategoryListFeedLoader);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/404/not-found-item.tsx
var not_found_item = __webpack_require__(6857);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
;// CONCATENATED MODULE: ./src/containers/hero-with-category.tsx
















const categoryResponsive = {
  "1280": {
    slidesPerView: 4,
    spaceBetween: 28
  },
  "768": {
    slidesPerView: 3,
    spaceBetween: 24
  },
  "480": {
    slidesPerView: 2,
    spaceBetween: 20
  },
  "0": {
    slidesPerView: 1,
    spaceBetween: 12
  }
};

const HeroWithCategory = ({
  className = "mb-12 md:mb-14 xl:mb-16",
  data,
  paginationPosition = "center"
}) => {
  var _categories$data, _categories$data2, _categories$data3, _categories$data4;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    width
  } = (0,use_window_size/* useWindowSize */.i)();
  const {
    data: categories,
    isLoading: loading,
    error
  } = (0,categories_query/* useCategoriesQuery */.Ei)({
    limit: 10,
    parent: null
  });

  if (!loading && isEmpty_default()(categories === null || categories === void 0 ? void 0 : categories.data)) {
    return /*#__PURE__*/jsx_runtime_.jsx(not_found_item/* default */.Z, {
      text: t("text-no-categories-found")
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `grid grid-cols-1 2xl:grid-cols-5 gap-5 xl:gap-7 ${className}`,
    children: [error ? /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : width < 1500 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
        breakpoints: categoryResponsive,
        buttonSize: "small",
        children: loading && !(categories !== null && categories !== void 0 && (_categories$data = categories.data) !== null && _categories$data !== void 0 && _categories$data.length) ? Array.from({
          length: 8
        }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
          children: /*#__PURE__*/jsx_runtime_.jsx(category_list_card_loader/* default */.Z, {
            uniqueKey: `category-list-${idx}`
          })
        }, `category-list-${idx}`)) : categories === null || categories === void 0 ? void 0 : (_categories$data2 = categories.data) === null || _categories$data2 === void 0 ? void 0 : _categories$data2.map(category => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
          children: /*#__PURE__*/jsx_runtime_.jsx(category_list_card/* default */.Z, {
            category: category
          })
        }, `category--key${category.id}`))
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "ltr:2xl:-mr-14 rtl:2xl:-ml-14 grid grid-cols-1 gap-3",
      children: loading && !(categories !== null && categories !== void 0 && (_categories$data3 = categories.data) !== null && _categories$data3 !== void 0 && _categories$data3.length) ? /*#__PURE__*/jsx_runtime_.jsx(category_list_feed_loader, {
        limit: 8
      }) : categories === null || categories === void 0 ? void 0 : (_categories$data4 = categories.data) === null || _categories$data4 === void 0 ? void 0 : _categories$data4.slice(0, 8).map(category => /*#__PURE__*/jsx_runtime_.jsx(category_list_card/* default */.Z, {
        category: category
      }, `category--key${category.id}`))
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "heightFull col-span-full row-span-full 2xl:row-auto 2xl:col-span-4 ltr:2xl:ml-14 rtl:2xl:mr-14",
      children: /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
        pagination: {
          clickable: true
        },
        className: `-mx-0 pagination-${paginationPosition}`,
        buttonClassName: "hidden",
        children: data === null || data === void 0 ? void 0 : data.map(banner => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
          children: /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
            data: banner,
            href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banner.slug}`,
            className: "xl:h-full"
          })
        }, `banner--key${banner.id}`))
      })
    })]
  });
};

/* harmony default export */ const hero_with_category = (HeroWithCategory);

/***/ })

};
;