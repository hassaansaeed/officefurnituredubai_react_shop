"use strict";
exports.id = 5330;
exports.ids = [5330];
exports.modules = {

/***/ 7141:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ instagram)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@react-icons/all-files/fa/FaInstagram"
var FaInstagram_ = __webpack_require__(5818);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2376);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(2585);
;// CONCATENATED MODULE: ./src/framework/rest/instagram/instagram.query.ts


const INSTAGRAM_TOKEN = "";
const INSTAGRAM_URL = `https://graph.instagram.com/me/media?fields=id,caption,media_url,media_type,permalink&access_token=${INSTAGRAM_TOKEN}`;

const fetchInstagram = ({
  queryKey
}) => {
  const [_key, params] = queryKey;
  const {
    limit = 3
  } = params; // Check token available or not

  if (!INSTAGRAM_TOKEN) return [];
  const urlWithParams = `${INSTAGRAM_URL}&limit=${limit}`;
  return external_axios_default().get(urlWithParams).then(res => res === null || res === void 0 ? void 0 : res.data).then(data => data === null || data === void 0 ? void 0 : data.data);
};

function useInstagram(options) {
  return (0,external_react_query_.useQuery)([INSTAGRAM_URL, options], fetchInstagram, {
    // To Prevent Instagram Expire Request
    staleTime: 60 * 60 * 1000
  });
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/common/instagram.tsx








const Instagram = ({
  className = ""
}) => {
  const {
    data: instagramFeed,
    isLoading: loading
  } = useInstagram({
    limit: 6
  });
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: external_classnames_default()("grid grid-cols-3 md:grid-cols-6 gap-0.5 sm:gap-1 overflow-hidden rounded-md", className),
    children: !loading && (instagramFeed === null || instagramFeed === void 0 ? void 0 : instagramFeed.map(item => {
      var _item$media_url;

      return /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
        className: "group flex justify-center text-center relative",
        href: item === null || item === void 0 ? void 0 : item.permalink,
        target: "_blank",
        rel: "noreferrer",
        children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
          src: (_item$media_url = item === null || item === void 0 ? void 0 : item.media_url) !== null && _item$media_url !== void 0 ? _item$media_url : "/assets/placeholder/instagram.svg",
          alt: t(`${item === null || item === void 0 ? void 0 : item.caption}`) || t("text-instagram-thumbnail"),
          width: 300,
          height: 300,
          className: "bg-gray-300 object-cover"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "absolute top left bg-black w-full h-full opacity-0 transition-opacity duration-300 group-hover:opacity-50"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "absolute top left h-full w-full flex items-center justify-center",
          children: /*#__PURE__*/jsx_runtime_.jsx(FaInstagram_.FaInstagram, {
            className: "text-white text-base sm:text-xl md:text-3xl lg:text-5xl xl:text-6xl transform opacity-0 scale-400 transition-all duration-300 ease-in-out group-hover:opacity-100 group-hover:scale-100"
          })
        })]
      }, `instagram--key${item === null || item === void 0 ? void 0 : item.id}`);
    }))
  });
};

/* harmony default export */ const instagram = (Instagram);

/***/ }),

/***/ 2813:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9081);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ProductCardListSmallLoader = props => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)((react_content_loader__WEBPACK_IMPORTED_MODULE_0___default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 423,
  height: 176,
  viewBox: "0 0 423 176",
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
    x: "194",
    y: "50",
    rx: "3",
    ry: "3",
    width: "140",
    height: "8"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
    x: "194",
    y: "82",
    rx: "3",
    ry: "3",
    width: "200",
    height: "6"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
    x: "194",
    y: "119",
    rx: "3",
    ry: "3",
    width: "80",
    height: "10"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "176",
    height: "176"
  })]
}));

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCardListSmallLoader);

/***/ })

};
;